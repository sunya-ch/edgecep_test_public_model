import sys
sys.path.append(".")
import environ_set
import grpc
from concurrent import futures
import time

import os
import json

from google.protobuf import empty_pb2

from protoc_py import postman_pb2

from protoc_py import coordinator_pb2
from protoc_py import coordinator_pb2_grpc

from common.util import util
from common.syncdb import SynchronizedDB

import logging
logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

COORDINATOR_PORT = os.environ['COORDINATOR_PORT']
SYNC_DB = 'sync'
SERVICE = "COORDINATOR"

class InterCoordinator(coordinator_pb2_grpc.InterCoordinatorServicer):
    def __init__(self):
        table_name = SERVICE
        field_list = ['api', 'name', 'op', 'detail', 'hash', 'timestamp', 'ip', 'interface']
        type_list = ['text', 'text', 'text', 'text', 'text', 'real', 'text', 'text']
        key_index_list = [0, 1, 4]
        self.syncdb = SynchronizedDB(SYNC_DB, table_name, field_list, type_list, key_index_list)
        # self.syncdb._show_table()

    def Exists(self, request, context):
        return empty_pb2.Empty()

    def CommandIn(self, request, context):
        refered_ip = request.ip
        refered_interface = request.interface
        timestamp = util.current_timestamp()
        if not self.syncdb.exists([request.api, request.name, request.hash]):
            self.syncdb.insert( [ \
                                request.api, \
                                request.name, \
                                request.op, \
                                request.detail, \
                                request.hash, \
                                timestamp, \
                                refered_ip, \
                                refered_interface \
                                ] \
                                )
            logging.info("COORDINATOR-SAVE: op:{0} name:{1} hash:{2} time:{3}".format(request.op, request.name, request.hash,timestamp))
        return empty_pb2.Empty()

    def HashIn(self, request, context):
        in_dict = json.loads(request.hash_dict_str)
        self._handle_hash_compare(in_dict['function'], 'function', request.ip, request.interface)
        self._handle_hash_compare(in_dict['actor'], 'actor', request.ip, request.interface)
        self._handle_hash_compare(in_dict['recipe'], 'recipe', request.ip, request.interface)
        return empty_pb2.Empty()

    def _handle_hash_compare(self, in_dict, api, ip, interface):
        my_dict = util._get_state(api)
        diff_key = self._compute_different(in_dict, my_dict)
        logging.info("COORDINATOR-HASHCMP: diff-keys:{0}".format(diff_key))
        if len(diff_key) > 0:
            sorted_list = self.get_sorted_latest_command(api, diff_key, in_dict)
            commands = self.gen_command_iterator(api, sorted_list)
            util.call_other_postman(ip, 'Synchronize', commands, timeout=10)


    def get_sorted_latest_command(self, api, diff_key, in_dict):
        sorted_list = []
        for key in diff_key:
            if key in in_dict and not self.syncdb.exists([api, key, in_dict[key]]):
                logging.warning("COORDINATOR-HASHCMP: {0} not exists".format(key))
                #continue
            selected_rows = self.syncdb.select([0,1], [api.upper(), key],order_list=['timestamp'], limit=1)
            if len(selected_rows) == 0:
                print('no selected row')
                continue
            _, _, op, detail, hash, timestamp, _, _ = selected_rows[0]
            timestamp = float(timestamp)
            index = 0
            for  (_, _, _, prev_timestamp) in sorted_list:
                if timestamp > prev_timestamp:
                    index += 1
                    continue
            sorted_list.insert(index, (op, detail, hash, timestamp))
        return sorted_list


    def gen_command_iterator(self, api, sorted_list):
        for (op, detail, hash, timestamp) in sorted_list:
            yield postman_pb2.CommandMsg(api=api.upper(), op=op, detail=detail, hash=hash, timestamp=float(timestamp))

    def _compute_different(self, in_dict, my_dict):
        in_keys = in_dict.keys()
        my_keys = my_dict.keys()
        ## ADDED KEY
        diff_key = [x for x in in_keys if x not in my_keys]
        ## REMOVED KEY
        diff_key = diff_key + [x for x in my_keys if x not in in_keys]
        ## REPLACED KEY
        same_key = [x for x in in_keys if x in my_keys]
        for key in same_key:
            if in_dict[key] != my_dict[key]:
                diff_key.append(key)
        return diff_key

def grpc_start():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    coordinator_pb2_grpc.add_InterCoordinatorServicer_to_server(InterCoordinator(), server)
    server.add_insecure_port('[::]:{0}'.format(COORDINATOR_PORT))
    server.start()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        SERVICE = 'COORDINATOR'
        print('Coordinator: start {0} grpc server'.format(SERVICE))
        util.notify_postman(SERVICE)
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)
        util.notify_postman(SERVICE, active=False)

if __name__ == "__main__":
    while not util.redis_available():
        continue
    grpc_start()
