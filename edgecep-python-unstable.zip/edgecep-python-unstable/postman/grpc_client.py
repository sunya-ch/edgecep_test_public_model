import sys
import grpc
import os
import json

from protoc_py import processor_pb2
from protoc_py import processor_pb2_grpc

from protoc_py import coordinator_pb2
from protoc_py import coordinator_pb2_grpc

from protoc_py import actor_pb2
from protoc_py import actor_pb2_grpc

from protoc_py import pretrainer_pb2
from protoc_py import pretrainer_pb2_grpc

from protoc_py import learner_pb2
from protoc_py import learner_pb2_grpc

from protoc_py import labeler_pb2
from protoc_py import labeler_pb2_grpc

from protoc_py import common_pb2
from protoc_py import common_pb2_grpc

from google.protobuf import empty_pb2

# from grpc._channel import _Rendezvous

import math
from common.util import util

import os

import logging

SERVICES = ['COORDINATOR', 'ACTOR', 'LABELER', 'PRETRAINER', 'LEARNER', 'PROCESSOR']
GRPC_MODULE = [coordinator_pb2_grpc, actor_pb2_grpc, labeler_pb2_grpc, pretrainer_pb2_grpc, learner_pb2_grpc, processor_pb2_grpc]
NODE_NAME = os.environ['BALENA_DEVICE_UUID']
LEARN_TFLITE_PATH = os.environ['LEARN_TFLITE_PATH']
STRICT_PERIOD = int(os.environ['STRICT_PERIOD'])

def encode(str):
    return bytes(str,'UTF-8')

class GRPC_Client(object):
    def __init__(self, filterer, egress):
        self.filterer = filterer
        self.egress = egress
        self.PROCESSOR_PORT = os.environ['PROCESSOR_PORT']
        self.COORDINATOR_PORT = os.environ['COORDINATOR_PORT']
        self.ACTOR_PORT = os.environ['ACTOR_PORT']
        self.PRETRAINER_PORT = os.environ['PRETRAINER_PORT']
        self.LEARNER_PORT = os.environ['LEARNER_PORT']
        self.LABELER_PORT = os.environ['LABELER_PORT']


        self.service_state = {}
        self.init_state()

        logging.info("GRPCCLIENT-STATE: init:{0}".format(self.service_state))
        self.memo_stream_msg = {'TrainData': {},
                    'TFLITE': {}, 'Act': {}} # for larger-size data

    def init_state(self):
        for service in SERVICES:
            self.deactivate(service)
        for service in SERVICES:
            try:
                with grpc.insecure_channel(self._url(service)) as channel:
                    stub = self._stub(service, channel)
                    stub.Exists(empty_pb2.Empty())
                    self.activate(service)
            except:
                pass

    def _url(self, service):
        return 'localhost:{0}'.format(self._port(service))

    def _stub_name(self, service):
        return "Inter{0}{1}Stub".format(service[0], service[1:].lower())

    def _port(self, service):
        return getattr(self, "{0}_PORT".format(service))

    def _stub(self, service, channel):
        index = SERVICES.index(service)
        grpc_module = GRPC_MODULE[index]
        return getattr(grpc_module, self._stub_name(service))(channel)

    def exists(self, service):
        return self.service_state[service.upper()]

    def activate(self, service):
        self.service_state[service] = True
        logging.info('GRPCCLIENT-STATE: connect:{0}'.format(service))
        if service in ['ACTOR', 'LABELER']: # probe as subscriber
            self.service_probe('PROCESSOR', service)
        elif service == 'PROCESSOR': # probe for filter
            self.filter_probe() # probe as publisher (notify subscriber)
            for subscriber_service in ['ACTOR', 'LABELER', 'PRETRAINER']: # probe as publisher (notify subscriber)
                if self.service_state[subscriber_service]:
                    self.service_probe(service, subscriber_service)
        elif service == 'PRETRAINER':
            self.service_probe('PROCESSOR', service) # probe as subscriber
            if self.service_state['LEARNER']:
                self.service_probe(service, 'LEARNER') # probe as publisher (notify subscriber)
        elif service == 'LEARNER':
            self.service_probe('PRETRAINER', service) # probe as subscriber


    def deactivate(self, service):
        self.service_state[service] = False
        logging.info('GRPCCLIENT-STATE: disconnect:{0}'.format(service))


    def event_to_postman(event):
        chunklist = self._get_chunk_list(event)
        to_postman_iterator= util.gen_large_msg(chunklist)
        util.call_postman('NewEvent', to_postman_iterator)


    # def call_event_in(self, filtered_event):
    #     if self.service_state['PROCESSOR']:
    #         to_processor_iterator = util.gen_event_iterator(filtered_event)
    #         with grpc.insecure_channel('localhost:{0}'.format(self.PROCESSOR_PORT)) as channel:
    #             stub = processor_pb2_grpc.InterProcessorStub(channel)
    #             stub.EventIn(to_processor_iterator)

    def call_event_in(self, to_processor_iterator):
        if self.service_state['PROCESSOR']:
            logging.info('GRPCCLIENT-EVENT:')
            try:
                with grpc.insecure_channel('localhost:{0}'.format(self.PROCESSOR_PORT)) as channel:
                    stub = processor_pb2_grpc.InterProcessorStub(channel)
                    return stub.EventIn(to_processor_iterator)
            except:
                logging.warning('GRPCCLIENT-EVENT: CANNOT CALL EVENT IN, PASS')
                pass
        return common_pb2.ResponseMsg(success=False, msg="")

    def call_hash_in(self, hash, ip, interface):
        if self.service_state['COORDINATOR']:
            logging.info('GRPCCLIENT-HASH:')
            request = coordinator_pb2.HashMsg(hash_dict_str=json.dumps(hash), ip=ip, interface=interface)
            with grpc.insecure_channel('localhost:{0}'.format(self.COORDINATOR_PORT)) as channel:
                stub = coordinator_pb2_grpc.InterCoordinatorStub(channel)
                stub.HashIn(request)


    def call_command_in(self, api, name, op, detail, hash, timestamp, fromaddr, interface_name):
        if self.service_state['COORDINATOR']:
            logging.info('GRPCCLIENT-CMD:')
            detail_str = json.dumps(detail)
            request = coordinator_pb2.CommandMsg(api=api, name=name, op=op, detail=detail_str, hash=hash, timestamp=timestamp, ip=fromaddr, interface=interface_name)
            with grpc.insecure_channel('localhost:{0}'.format(self.COORDINATOR_PORT)) as channel:
                stub = coordinator_pb2_grpc.InterCoordinatorStub(channel)
                stub.CommandIn(request)

    def sync_function_recipe(self, api, key, add):
        request = self._create_sync_msg(api, key)
        for uppercase_service in ['PROCESSOR', 'PRETRAINER', 'LEARNER', 'LABELER']:
            if self.service_state[uppercase_service]:
                logging.info('GRPCCLIENT-SYNC: svc:{0}'.format(uppercase_service))
                with grpc.insecure_channel(self._url(uppercase_service)) as channel:
                    stub = self._stub(uppercase_service, channel)
                    # if uppercase_service == 'PROCESSOR':
                    #     stub = processor_pb2_grpc.InterProcessorStub(channel)
                    # elif uppercase_service == 'PRETRAINER':
                    #     stub = pretrainer_pb2_grpc.InterPretrainerStub(channel)
                    # elif uppercase_service == 'LEARNER':
                    #     stub = learner_pb2_grpc.InterLearnerStub(channel)
                    # elif uppercase_service == 'LABELER':
                    #     stub = labeler_pb2_grpc.InterLabelerStub(channel)
                    if add:
                        stub.SynchronizeAdd(request)
                    else:
                        stub.SynchronizeRevoke(request)

        if api == 'RECIPE':
            with grpc.insecure_channel('localhost:{0}'.format(self.ACTOR_PORT)) as channel:
                stub = actor_pb2_grpc.InterActorStub(channel)
                if add:
                    stubcall = getattr(stub, 'SynchronizeAdd')
                    self.filterer.add_recipe(key)
                else:
                    stubcall = getattr(stub, 'SynchronizeRevoke')
                    self.filterer.revoke_recipe(key)
                if self.service_state['ACTOR']:
                    stubcall(request)



    def get_actor_content(self):
        on_actor = []
        actors = util.get_actor()
        for actor in actors.keys():
            if actors.hget(actor, 'status') == 'on':
                on_actor.append(actor)
        return None if len(on_actor) == 0 else json.dumps(on_actor)

    def get_processor_content(self):
        return util.get_node_info().get('benchmark')

    def _gen_to_processor(self, processor_fwd, chunklist, time_at_filter, filterer):
        recipe_case_id_list_str = json.dumps(processor_fwd)
        for content in chunklist:
            yield self._processor_filtered_event(recipe_case_id_list_str, content, time_at_filter, filterer)

    # def _processor_filtered_event(self, recipe_case_id_list_str, content, time_at_filter, filterer):
    #     return processor_pb2.FilteredEventMsg(content=content,
    #                                           filterer=filterer,
    #                                           time_at_filter=time_at_filter,
    #                                           recipe_case_id_list=recipe_case_id_list_str)



    # def act_msg_in(self, obj_str, interface, fromaddr):
    #     obj = json.loads(obj_str)
    #     descriptor = obj['descriptor']
    #     service = 'Act'
    #     if self.service_state['ACTOR']:
    #         key, hash, total =  descriptor.split("/")
    #         content = obj['content']
    #         seq = obj['seq']
    #         total = int(total)
    #         if self._recv_chunk(service, hash, seq, total, content):
    #             # full_content = self._construct_content(self.memo_stream_msg['Act'][hash])
    #             chunklist = self.memo_stream_msg[service][hash] # arg
    #             request_iterator = util.gen_large_msg(chunklist)
    #             response = self.call_act(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'ACTOR', interface, fromaddr)

    def call_act(self, request_iterator, context):
        with grpc.insecure_channel('localhost:{0}'.format(self.ACTOR_PORT)) as channel:
            stub = actor_pb2_grpc.InterActorStub(channel)
            return stub.Act(request_iterator)

    # def learn_msg_in(self, service, obj_str, interface, fromaddr):
    #     if service == 'TrainData' and not (self.service_state['LABELER'] or self.service_state['PRETRAINER']):
    #         return None
    #     if service == 'LabeledData' and not self.service_state['PRETRAINER']:
    #         return None
    #     if service == 'PretrainData' and not self.service_state['LEARNER']:
    #         return None
    #     if service == 'TFLITE' and not self.service_state['PROCESSOR']:
    #         return None
    #
    #     obj = json.loads(obj_str)
    #     key = obj['descriptor']
    #     content = obj['content']
    #
    #     if service not in ['TrainData', 'TFLITE'] :
    #         getattr(self, "_handle_{0}".format(service))(key, content, interface, fromaddr)
    #     else:
    #         function_name, hash, total =  key.split("/")
    #         seq = obj['seq']
    #         total = int(total)
    #         if self._recv_chunk(service, hash, seq, total, content):
    #             chunklist = self.memo_stream_msg[service][hash]
    #             getattr(self, "_handle_{0}".format(service))(function_name, chunklist, fromaddr)

    def adv_msg_in(self, adv_str, interface, fromaddr):
        new_adv = json.loads(adv_str)
        type = new_adv["type"]
        device_name = new_adv["name"]
        if interface and device_name not in util.get_direct_cache().keys():
            self.egress.send_hey_to(fromaddr, interface)
        call_processor = False
        if type == 'module':
            call_processor = self.update_adv_db(new_adv, interface, fromaddr)
        elif interface != None and type =='processor':
            call_processor = True
        elif type == 'pretrainer':
            active_list = json.dumps(new_adv["namelist"])
            self._call_for_sub('PRETRAINER', 'LEARNER', active_list, interface, fromaddr)
            return common_pb2.ResponseMsg(success=True,msg="")

        if call_processor:
            self.call_processor_adv_in(adv_str, fromaddr, interface)

        if type == 'processor':
            active_list = json.dumps(new_adv["namelist"])
            self.filterer.processor_adv_in(new_adv, fromaddr, interface)
            for service in ['ACTOR', 'LABELER', 'PRETRAINER']:
                self._call_for_sub('PROCESSOR', service, active_list, interface, fromaddr)
                # for active mapper recipes
            return common_pb2.ResponseMsg(success=True,msg="")

        return common_pb2.ResponseMsg(success=True,msg="")

    def call_processor_adv_in(self, adv_str, fromaddr, interface):
        if self.service_state['PROCESSOR']:
            # for processor or model advertisement
            logging.info('GRPCCLIENT-ADV2PROCESSOR: adv:{0}'.format(adv_str))
            if interface is None:
                interface_name = ""
            else:
                interface_name = interface.name
            request = processor_pb2.AdvWithIPMsg(adv_str=adv_str, ip=fromaddr, interface=interface_name)
            with grpc.insecure_channel('localhost:{0}'.format(self.PROCESSOR_PORT)) as channel:
                stub = processor_pb2_grpc.InterProcessorStub(channel)
                response = stub.AdvIn(request)
                return response

    def update_adv_db(self, new_adv, interface, fromaddr):
        if interface is None:
            new_adv["size"] = 0 # own advertisement
        new_adv["timestamp"] = util.current_timestamp()
        key = new_adv["key"]
        advs = util.get_adv()
        # expired = util.current_timestamp() - STRICT_PERIOD # already set ex
        is_added  = False
        if key in advs.keys():
            prev_adv_value = util._compute_module_value(advs, key, 'accuracy', 'samples')
            new_adv_values = new_adv["accuracy"] * new_adv["samples"]
            # prev_timestamp = float(advs.hget(key, 'timestamp'))
            # if prev_timestamp < expired:
            #     logging.info('expired')
            #     is_added = True
            # elif prev_accuracy < new_adv_values:
            if prev_adv_value < new_adv_values:
                is_added = True
        else:
            # logging.info('adv never exists')
            is_added = True

        if is_added:
            logging.info('GRPCCLIENT-MODULE_IMPROVE: adv:{0} from:{1}'.format(new_adv, fromaddr))
            self._save_to_db(advs, new_adv, interface, fromaddr)
        return is_added

    def _save_to_db(self, advs, new_adv, interface, ip):
        key = new_adv["key"]
        del new_adv["key"]
        new_adv["ip"] = ip
        new_adv["interface"] = "" if interface is None else interface.name
        new_adv["samples"] = str(new_adv["samples"])
        new_adv["accuracy"] = str(new_adv["accuracy"])
        new_adv["size"] = str(new_adv["size"])
        ttl = math.ceil(util.current_timestamp() + STRICT_PERIOD)
        advs.hmset(key, new_adv)
        advs.expire(key, ttl)


    def _call_for_sub(self, publisher, service, active_recipe, interface, fromaddr):
        if self.service_state[service]:
            logging.info('GRPCCLIENT-ADV: recipes:{1} to(me):{0} from:{2}'.format(service, active_recipe,publisher))
            request = common_pb2.SimpleString(str=active_recipe)
            with grpc.insecure_channel(self._url(service)) as channel:
                stub = self._stub(service, channel)
                response = stub.AdvIn(request)
                namelist = response.msg
                if response.success == True:
                    if interface is None:
                        self.sub_in(publisher, namelist, "", "", NODE_NAME, service)
                    else:
                        obj = {'id': NODE_NAME, 'namelist': namelist, 'svc': service, 'publisher': publisher}
                        msg = "SUB {0}".format(json.dumps(obj))
                        self.egress.send_msg_to(msg, fromaddr, interface)

    def filter_probe(self):
        publisher = 'PROCESSOR'
        if self.service_state[publisher]:
            logging.info('GRPCCLIENT-PROBE: pub:PROCESSOR by:filter')
            success, msg = self.call_probe(publisher)
            if success:
                adv = json.loads(msg)
                try:
                    self.filterer.processor_adv_in(adv)
                except Exception as err:
                    logging.warning('GRPCCLIENT-PROBE: filter probe fail')

    def service_probe(self, publisher, service):
        try:
            if self.service_state[publisher]:
                logging.info('GRPCCLIENT-PROBE: pub:{0} by:{1}'.format(publisher, service))
                success, msg = self.call_probe(publisher)
                if success:
                    adv = json.loads(msg)
                    active_list = json.dumps(adv["namelist"])
                    self._call_for_sub(publisher, service, active_list, None, "")
        except Exception as err:
            logging.warning('GRPCCLIENT-PROBE: {0} probe to {1} fail'.format(service, publisher))

    def probe_in(self, publisher):
        if self.service_state[publisher]:
            logging.info('GRPCCLIENT-PROBE: pub:{0} by:HELLO'.format(publisher))
            success, msg = self.call_probe(publisher)
            if success:
                self.egress.broadcast(prefix="ADV", content=msg)

    def call_probe(self, publisher):
        if self.service_state[publisher]:
            with grpc.insecure_channel(self._url(publisher)) as channel:
                stub = self._stub(publisher, channel)
                response = stub.Probe(empty_pb2.Empty())
                return response.success, response.msg
        return False, None

    def probe_modules(self):
        logging.info('GRPCCLIENT-PROBE: pub:MODULES by:HELLO')
        names =  util.list_names(LEARN_TFLITE_PATH, 'stat')

        for name in names:
            path = util._learn_stat_path(name)
            stat_str = open(path, "r").read()
            obj = json.loads(stat_str)
            obj['type'] = 'module'
            obj['key'] = name
            adv_str = json.dumps(obj)
            self.adv_msg_in(adv_str, None, "")
            self.egress.broadcast(prefix='ADV', content=adv_str)
            logging.info(adv_str)

    def sub_in(self, publisher, namelist, interface_name, ip, id, svc): # PROCESSOR or PRETRAINER
        if self.service_state[publisher]:
            logging.info('GRPCCLIENT-SUB: recipes:{1} from({3}):{0} to:{2}'.format(svc, namelist, publisher,id))
            request = common_pb2.Subscription(name=namelist, interface=interface_name, ip=ip, id=id, svc=svc)
            with grpc.insecure_channel(self._url(publisher)) as channel:
                stub = self._stub(publisher, channel)
                stub.Subscribe(request)

    # def unsub_in(self, name, id, svc):
    #     if self.service_state['PROCESSOR']:
    #         request = processor_pb2.Subscription(name=name, interface="", ip="", id=id, svc=svc)
    #         with grpc.insecure_channel('localhost:{0}'.format(self.PROCESSOR_PORT)) as channel:
    #             stub = processor_pb2_grpc.InterProcessorStub(channel)
    #             stub.Unsubscribe(request)

    # def _handle_TrainData(self, key, chunklist, interface, fromaddr):
    #     response = common_pb2.ResponseMsg(success=False, msg='')
    #     request_iterator = util.gen_large_msg(chunklist)
    #     if self.service_state['LABELER']:
    #         with grpc.insecure_channel('localhost:{0}'.format(self.LABELER_PORT)) as channel:
    #             stub = labeler_pb2_grpc.InterLabelerStub(channel)
    #             response = stub.TrainDataIn(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'LABELER', interface, fromaddr)
    #     elif self.service_state['PRETRAINER']:
    #         with grpc.insecure_channel('localhost:{0}'.format(self.PRETRAINER_PORT)) as channel:
    #             stub = labeler_pb2_grpc.InterPretainerStub(channel)
    #             response = stub.TrainDataIn(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'PRETRAINER', interface, fromaddr)


    # def _handle_TrainData(self, key, chunklist, interface, fromaddr):
    #     response = common_pb2.ResponseMsg(success=False, msg='')
    #     request_iterator = util.gen_large_msg(chunklist)
    #     if self.service_state['LABELER']:
    #         with grpc.insecure_channel('localhost:{0}'.format(self.LABELER_PORT)) as channel:
    #             stub = labeler_pb2_grpc.InterLabelerStub(channel)
    #             response = stub.TrainDataIn(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'LABELER', interface, fromaddr)
    #     elif self.service_state['PRETRAINER']:
    #         with grpc.insecure_channel('localhost:{0}'.format(self.PRETRAINER_PORT)) as channel:
    #             stub = labeler_pb2_grpc.InterPretainerStub(channel)
    #             response = stub.TrainDataIn(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'PRETRAINER', interface, fromaddr)
    #
    # def _handle_LabeledData(self, key, content, interface, fromaddr):
    #     if self.service_state['PRETRAINER']
    #         request = self._create_constructed_msg(key, content, fromaddr)
    #         with grpc.insecure_channel('localhost:{0}'.format(self.PRETRAINER_PORT)) as channel:
    #             stub = pretrainer_pb2_grpc.InterPretrainerStub(channel)
    #             return stub.LabelIn(request)
    #     return common_pb2.ResponseMsg(success=False, msg='')
    #
    # def _handle_PretrainData(self, key, content, interface, fromaddr):
    #     request = self._create_constructed_msg(key, content, fromaddr)
    #     with grpc.insecure_channel('localhost:{0}'.format(self.LEARNER_PORT)) as channel:
    #         stub = learner_pb2_grpc.InterLearnerStub(channel)
    #         stub.PretrainIn(request)

    # def _handle_TrainData(self, key, chunklist, interface, fromaddr):
    #     response = common_pb2.ResponseMsg(success=False, msg='')
    #     request_iterator = util.gen_large_msg(chunklist)
    #     if self.service_state['LABELER']:
    #         with grpc.insecure_channel('localhost:{0}'.format(self.LABELER_PORT)) as channel:
    #             stub = labeler_pb2_grpc.InterLabelerStub(channel)
    #             response = stub.TrainDataIn(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'LABELER', interface, fromaddr)
    #     elif self.service_state['PRETRAINER']:
    #         with grpc.insecure_channel('localhost:{0}'.format(self.PRETRAINER_PORT)) as channel:
    #             stub = labeler_pb2_grpc.InterPretainerStub(channel)
    #             response = stub.TrainDataIn(request_iterator)
    #             if response.success == False:
    #                 self._send_unsub(key, 'PRETRAINER', interface, fromaddr)


    def _handle_TrainData(self, request_iterator, metadata, svc):
        if self.service_state[svc]:
            with grpc.insecure_channel(self._url(svc)) as channel:
                stub = self._stub(svc, channel)
                return stub.TrainDataIn(request_iterator, metadata=metadata)
        return False

    # def _handle_PretrainMsg(self, service, obj_str, interface, fromaddr):
    #     obj = json.loads(obj_str)
    #     request =  common_pb2.PretrainMsg(key=obj["key"], pretrain=obj["pretrain"], label=obj["label"], id=obj["id"])
    #     if service == 'LabeledData':
    #         self._handle_LabeledData(request)
    #     elif service == 'PretrainData':
    #         self._handle_PretrainData(request)

    def _handle_LabeledData(self, request):
        if self.service_state['PRETRAINER']:
            with grpc.insecure_channel('localhost:{0}'.format(self.PRETRAINER_PORT)) as channel:
                stub = pretrainer_pb2_grpc.InterPretrainerStub(channel)
                return stub.LabelIn(request)
        return empty_pb2.Empty()

    def _update_LabeledData(self, request):
        if self.service_state['LABELER']:
            with grpc.insecure_channel('localhost:{0}'.format(self.LABELER_PORT)) as channel:
                stub = labeler_pb2_grpc.InterPretrainerStub(channel)
                return stub.LabeledIn(request)
        return empty_pb2.Empty()

    def _handle_PretrainData(self, request_iterator, context):
        if self.service_state['LEARNER']:
            metadata = context.invocation_metadata()
            with grpc.insecure_channel('localhost:{0}'.format(self.LEARNER_PORT)) as channel:
                stub = learner_pb2_grpc.InterLearnerStub(channel)
                return stub.PretrainIn(request_iterator, metadata=metadata)
        return common_pb2.ResponseMsg(success=False, msg="not active")

    def offload(self, request, context):
        if self.service_state['PROCESSOR']:
            with grpc.insecure_channel('localhost:{0}'.format(self.PROCESSOR_PORT)) as channel:
                stub = processor_pb2_grpc.InterProcessorStub(channel)
                context_dict, metadata= util._context_dict(context)
                return stub.Offload(request, metadata=metadata)
        return common_pb2.ResponseMsg(success=False, msg="not active")

    # def _send_unsub(self, name, svc, interface, fromaddr):
    #     obj = {}
    #     obj['name'] = name
    #     ob['svc'] = svc
    #     obj['id'] = NODE_NAME
    #     msg = "UNSUB {0}".format(json.dumps(obj))
    #     self.node.egress.send_msg_to(msg, fromaddr, interface)

    def _create_sync_msg(self, api, key):
        return common_pb2.SyncMsg(api=api, key=key)

    def _create_constructed_msg(self, key, content, fromaddr):
        return common_pb2.ConstructedMsg(key=key, obj=content, sender=fromaddr)

    def _recv_chunk(self, service, hash, seq, total, content):
        if hash not in self.memo_stream_msg[service]:
            self.memo_stream_msg[service][hash] = [None] * total
        return self._chunk_in(hash, seq, content, self.memo_stream_msg[service])

    def _chunk_in(self, descriptor, seq, content, chunk_record):
        chunk_record[descriptor][seq-1] = content
        for chunk in chunk_record[descriptor]:
            if chunk is None:
                # some chunks not coming yet
                return False
        return True

    def _construct_content(self, chunklist):
        full_content = ''
        return full_content.join(chunklist)
