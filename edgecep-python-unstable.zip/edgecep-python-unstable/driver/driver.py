import sys
sys.path.append(".")
import environ_set

### Required updated grpcio
## pip install grpcio==1.22.0
## pip install grpcio-tools==1.22.0

import grpc
from grpc._channel import _Rendezvous
from concurrent import futures

import threading
import time
import ctypes

import json
import os
import importlib

from common.util import util
from common.component import Event

NODE_NAME = os.environ['BALENA_DEVICE_UUID']
POSTMAN_PORT = os.environ['POSTMAN_PORT']

ACTIVE_DRIVERS = None if 'ACTIVE_DRIVER' not in os.environ.keys() else os.environ['ACTIVE_DRIVER']


try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

class Forwarder(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self)
        self.event_queue = Queue()

    def run(self):
        count = 0
        while True:
            event = self.event_queue.get(block=True)
            send_time = util.current_timestamp()
            print(count, ':',send_time,':',send_time -event.timestamp)
            response = util.event_to_postman(event)
            if hasattr(response, 'success'):
                print('postman dies')
            count += 1

    def put(self, event):
        self.event_queue.put(event)

    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)

class BaseDriver(threading.Thread):

    def __init__(self, name, sampling_period_in_sec):
        threading.Thread.__init__(self)
        self.keep_running = True
        self.name = name
        self.sampling_period = sampling_period_in_sec
        self.fwd = Forwarder()

    def run(self):
        print('Driver {0}: start with sampling time = {1}'.format(self.name, self.sampling_period))
        self.fwd.start()
        try:
            while True:
                attribs = self.read_values()
                if not attribs:
                    break
                if self._check_valid_attribs(attribs):
                    event = self._create_event(attribs)
                    # keep trying on sending
                    self.fwd.put(event)
                else:
                    print('Driver: Invalid attribs (non-Serializable) {0}'.format(attribs))
                time.sleep(self.sampling_period)
        finally:
            print('end')
            self.fwd.deactive()
            self.close()
        print('properly closed')

    def close(self): # override this method to properly close driver
        pass

    def read_values(self): # override this method return attributes in string format
        attribs = {'a1': 'v1'}
        return attribs

    def _check_valid_attribs(self, attribs):
        try:
            json.dumps(attribs)
            return True
        except:
            return False

    def _create_event(self, attribs):
        return Event(name=self.name,
              location=util._location(),
              attribs=attribs,
              timestamp=util.current_timestamp(),
              origin=NODE_NAME
              )


DRIVER_PATH = '.'

if __name__ == "__main__":
    while not util.redis_available():
        continue
    # drivers =  util.list_names(DRIVER_PATH, 'py')
    # drivers.remove('driver')
    # for driver in drivers:
        #importlib.import_module(driver).run()
    import logging
    logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
    if os.path.exists(logfile):
        os.remove(logfile)
    logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

    if ACTIVE_DRIVERS:
        driver_list = ACTIVE_DRIVERS.split(',')
        for driver in driver_list:
            values = driver.split('_')
            module = values[0]
            args = None
            if len(values) > 0:
                args = values[1:]
            importlib.import_module(module).run(args)
