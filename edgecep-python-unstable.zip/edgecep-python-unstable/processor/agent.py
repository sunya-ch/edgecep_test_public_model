from common.component import Recipe, Event
from DBMS import DBMS

import threading
import ctypes
import os
from common.pubsub import PubSubProtocol
from common.record import Record
from common.util import util

import logging

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

import json

### on_demand,  never (process all), always(no weight, round robin)
PARTITIONER = os.environ['PARTITIONER']

ENQUEUE_FUNCTION = '{0}_enqueue'.format(PARTITIONER.lower())
OFFLOAD_FUNCTION = '{0}_offload'.format(PARTITIONER.lower())


REQUIRED_FIELD = ['location', 'timestamp']
NODE_NAME = os.environ['BALENA_DEVICE_UUID']

class Agent(threading.Thread):
    def __init__(self, recipe_value, empty_record, processor):
        threading.Thread.__init__(self)
        if isinstance(recipe_value, Recipe):
            self.recipe = recipe_value
        else:
            self.recipe = Recipe(recipe_value)
        self.processor = processor
        # handling input and sequence
        self.database_manager = DBMS(self.recipe)
        # hanling process
        size =  len(self.recipe.cases)
        self.process_arr = [None] * size
        self.timeout_arr = [None] * size
        for casei in range(0, size):
            process = self.recipe.cases[casei].content.process
            self.process_arr[casei] = process
            if process.interval > 0:
                self._reset_timeout(casei)

        self.pubsub = PubSubProtocol('Act', self.recipe.name)
        self.case_queue = Queue()
        self.event_count = 0
        self.record = empty_record

######################################################################
## Model fitting record
##
##

    def new_record(self, function_name, casei, processing_time): # called by output handler
        index = self.recipe.complexity_arr[casei]
        self.record.add_value(function_name, index, processing_time)

######################################################################

    def _reset_timeout(self, casei):
        process = self.recipe.cases[casei].content.process
        self.timeout_arr[casei] = util.current_timestamp() + process.interval

    def run(self):
        try:
            while True:
                (event, case_id_list) = self.case_queue.get(block=True)
                self.database_manager.event_in(event, case_id_list)
                logging.info('AGENT-POP-{0}: caseid:{1}'.format(self.recipe.name,case_id_list))
                self.event_count += 1
                checked = []
                for item in case_id_list:
                    casei, id = util._case_id_from_str(item)
                    if casei not in checked:
                        process = self.process_arr[casei]
                        if process.interval == 0:
                            self.task(casei)
                            self.event_count = 0
                        elif util.current_timestamp() > self.timeout_arr[casei]:
                            self.task(casei)
                            self.event_count = 0
                            self._reset_timeout(casei)
                    checked.append(casei)
        finally:
            logging.warning('AGENT-{0}: stop'.format(self.recipe.name))

    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        self.database_manager.drop()
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)

    def event_in(self, event, case_id_list):
        logging.info('AGENT-EVENTIN-{0}: caseid:{1}'.format(self.recipe.name,case_id_list))
        self.case_queue.put((event, case_id_list))

    def subscribe(self, interface_name, ip, id, svc):
        self.pubsub.subscribe(interface_name, ip, id)

    def unsubscribe_from_id(self, id, svc):
        self.pubsub.unsubscribe_from_id(id)

    def task(self, casei):
        logging.info('AGENT-PROCESS-{0}: casei:{1}'.format(self.recipe.name,casei))
        if not not self.pubsub: # has some subscribers
            predictor = self.get_predictor(casei)
            if not predictor or not predictor.is_ready():
                logging.warning('AGENT-PROCESS-{0}: casei:{1} Predictor Not Ready ,{2}'.format(self.recipe.name,casei, self.processor.orchestrator.learn_component.worker_map.keys()))
                return False, "predictor is not ready"
            results = self.database_manager.get_input(casei) #{groupstr: inputdata}
            for group_str, input_data in results.items():
                input_arr = self.process_arr[casei].get_input_arr(input_data)
                pre_output_obj = self._pre_output_obj(casei, group_str, input_data)
                start = util.current_timestamp()
                output_handler = OutputHandler(self.handle_output, self.new_record, predictor.function.name, casei, pre_output_obj, start)
                success = getattr(predictor, ENQUEUE_FUNCTION)(input_arr, output_handler.handle, start)
                if not success:
                    # delay = predictor._delay()
                    offload_success = getattr(self.processor.orchestrator, OFFLOAD_FUNCTION)(self.recipe.name, predictor.function.name, input_arr, casei, pre_output_obj, start)# try ask other
                    if not offload_success:
                        predictor.force_enqueue(input_arr, output_handler.handle)
                predictor.update_input(input_arr)
            return False, "something goes wrong"
        else:
            logging.warning('AGENT-{0}: no subscriber, do not process'.format(self.recipe.name))


    def get_predictor(self, caseid):
        function_name = self.process_arr[caseid].function
        learn_component = self.processor.orchestrator.learn_component
        if function_name in learn_component.worker_map.keys():
            return learn_component.worker_map[function_name]
        return None

    def offload(self, predictor, offload_content):
        offload_obj = json.loads(offload_content)
        casei = offload_obj["case"]
        pre_output_obj = offload_obj["pre"]
        input_arr = offload_obj["arr"]
        start = offload_obj["start"]
        output_handler = OutputHandler(self.handle_output, self.new_record, predictor.function.name, casei, pre_output_obj, start)
        predictor.force_enqueue(input_arr, output_handler.handle)

    def _pre_output_obj(self, casei, group_str, input_data):
        node_map = self._node_map()
        group_map = self._group_map(casei, group_str)
        output = self.recipe.cases[casei].content.output
        return output.get_pre_output_obj(node_map, group_map, input_data)

    def handle_output(self, casei, output_obj, output_arr):
        node_map = self._node_map()
        process_map = self._output_map(casei, output_arr)
        output = self.recipe.cases[casei].content.output
        output.update_output_obj(output_obj, process_map)

        if self.recipe.attribute_dict is not None:
            event = self.generate_event(self.recipe.name, self.recipe.attribute_dict, output_obj, node_map)
            util.event_to_postman(event)
        if self.recipe.act is not None:
            content = {'arg': output_obj, 'recipe': self.recipe.name, 'count': self.event_count, 'id': NODE_NAME}
            self.pubsub.send_to_subscriber(content, callback=self._increase_N_token, args=[NODE_NAME])

    # def handle_output(self, casei, output_arr, group_str, input_data):
    #     output_map = self._output_map(casei, output_arr)
    #     node_map = self._node_map()
    #     group_map = self._group_map(casei, group_str)
    #
    #     output = self.recipe.cases[casei].content.output
    #     out_obj = output.get_output_obj(output_map, node_map, group_map, input_data)
    #
    #     if self.recipe.attribute_dict is not None:
    #         event = self.generate_event(self.recipe.name, self.recipe.attribute_dict, out_obj, node_map)
    #         util.event_to_postman(event)
    #     if self.recipe.act is not None:
    #         content = {'arg': out_obj, 'recipe': self.recipe.name, 'count': self.event_count, 'id': NODE_NAME}
    #         self.pubsub.send_to_subscriber(content, callback=self._increase_N_token, args=[NODE_NAME])

    def _increase_N_token(self, args):
        util.increase_N_token('PROCESS', self.recipe.name, args[0], self.event_count)

    def generate_event(self, event_name, attribute_dict, out_obj, node_map):
        for field in REQUIRED_FIELD:
            if field not in out_obj.keys():
                out_obj[field] = node_map[field] # fill-up required field with node info

        location = out_obj['location']
        timestamp = out_obj['timestamp']
        forwarders = node_map['id']
        attribs = {}
        for attribute_name in attribute_dict:
            value = out_obj[attribute_name]
            attribs[attribute_name] = value

        logging.info('AGENT-EVENTOUT-{0}: attribs:{1}'.format(self.recipe.name, attribs))
        return Event(event_name, location, attribs, timestamp, forwarders)

    def _output_map(self, casei, output_arr):
        output_map = {}
        for i in range(0, len(output_arr)):
            output_name = self.recipe.output_name_arr[casei][i]
            output_map[output_name] = output_arr[i]
        return output_map

    def _group_map(self, casei, group_str):
        group_map = {}
        if group_str != "":
            group = self.recipe.cases[casei].content.group
            group_values = group_str.split("_")
            index = 1
            for col in group:
                group_map[col] = group_values[index]
                index += 1
        return group_map

    def _node_map(self):
        return {'timestamp': util.current_timestamp(), \
                'location': util._location(), \
                'id': util._id()}

class OutputHandler():
    def __init__(self, handle_function, record_function, function_name, casei, pre_output_obj, start_time):
        self.handle_function = handle_function
        self.record_function = record_function
        self.casei = casei
        self.function_name = function_name
        self.pre_output_obj = pre_output_obj.copy()
        self.start_time = start_time

    def handle(self, output_arr, process_start):
        self.handle_function(self.casei, self.pre_output_obj, output_arr)
        create_time = util.current_timestamp()
        total_time = create_time - self.start_time
        process_time = create_time - process_start
        logging.info('OUTPUT-RECORD: func:{0} total_time:{1} process_time:{2}'.format(self.function_name, total_time, process_time))
        self.record_function(self.function_name, self.casei, process_time)
