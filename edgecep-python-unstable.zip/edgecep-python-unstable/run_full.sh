redis-server /etc/redis/redis.conf&
echo "127.0.0.1       redis_db" >> /etc/hosts&
python driver/driver.py&
python processor/processor.py&
python coordinator/coordinator.py&
python actor/actor.py&
python postman/postman.py&
wait
