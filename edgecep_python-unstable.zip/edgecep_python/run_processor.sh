redis-server /etc/redis/redis.conf&
python processor/processor.py&
python actor/actor.py&
python driver/driver.py&
python postman/postman.py
