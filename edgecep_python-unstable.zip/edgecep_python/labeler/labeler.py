
import json

from common.util import util
import numpy as np
from io import BytesIO
from PIL import Image

import threading
from threading import Lock

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

from protoc_py import common_pb2

import matplotlib.pyplot as plt

import logging

import os
NODE_NAME = os.environ['BALENA_DEVICE_UUID']

label_lock = Lock()

label_num = 0
labels = []
last_hash_key = None
last_provider = None
last_key = None
label_callback = None

def clear_for_next():
    fig.clf()
    ax = plt.subplot('111')
    plt.axis("off")
    plt.text(0.5,0.5,'waiting for data ...', ha="center", fontsize=20)
    fig.canvas.draw()

def show(input_arr, hashkey, provider, cur_labels, label_text, cur_label_num, input_name, subplot_position, show_functions, callback_func):
    label_lock.acquire()

    global label_num
    global labels
    global last_hash_key
    global last_provider
    global last_key
    global label_callback

    label_num = cur_label_num
    labels = cur_labels
    last_hash_key = hashkey
    last_provider = provider
    last_key = None
    label_callback = callback_func

    fig.clf()
    fig.suptitle(label_text)
    for index in range(0, len(input_name)):
        ax = plt.subplot(subplot_position[index])
        ax.set_title(input_name[index])
        plt.axis("off")
        show_functions[index](input_arr[index])
    fig.canvas.draw()

def reset():
    clear_for_next()
    label_lock.release()

def _text(value):
    plt.text(0.5,0.5,value, ha="center", fontsize=15)

def _image(value):
    arr = np.asarray(value[0], dtype=np.uint8)
    img = Image.fromarray(arr, mode='RGB')
    plt.imshow(img)


def press(event):

    global label_num
    global labels
    global last_hash_key
    global last_provider
    global last_key
    global label_callback

    if last_key and event.key == 'enter':
        label_callback(last_key, last_hash_key, last_provider)
        reset()
    else:
        try:
            key = int(event.key)
            if key < label_num:
                print('Are you sure with {0}?[enter]'.format(labels[key]))
                last_key = key
            else:
                print('Please press valid labels [0~{0}]'.format(label_num-1))
        except:
            print('Please press valid labels [0~{0}]'.format(label_num-1))

fig=plt.figure(figsize=(10,10))
fig.canvas.mpl_connect('key_press_event', press)
clear_for_next()
plt.show(block=False)


class Labeler(threading.Thread):
    def __init__(self, name, input_names, output_names, labels):
        threading.Thread.__init__(self)
        self.name = name
        self.input_name = input_names
        self.subplot_position = self._subplot_position()
        self.output_name = output_names
        self.labels = labels
        self.label_num = len(labels)
        self.label_text = self._label_text()
        # self.last_hash_key = None
        # self.last_provider = None
        # self.last_key = None
        self.show_functions = []
        for input in input_names:
            if 'image' in input:
                self.show_functions.append(_image)
            else:
                self.show_functions.append(_text)
        self.train_data = Queue()
        self.labeled_list = []

    def _label_text(self):
        text = "Labels:"
        index = 0
        for label in self.labels:
            text += "{0}[{1}] ".format(label, index)
            index += 1
        return text

    def label_data_in(self, pretrain, label, id):
        logging.info('LABELER: {0} labeled by {1}'.format(label, id))
        self.labeled_list.append(pretrain)

    def _subplot_position(self):
        total = len(self.input_name)
        position = []
        index = 0
        for name in self.input_name:
            x = int(index/2) + 1
            y = index%2 + 1
            position.append("{0}{1}{2}".format(total, x, y))
            index += 1
        return position

    def train_data_in(self, content):
        self.train_data.put(content)

    def run(self):
        try:
            while True:
                content_str = self.train_data.get(block=True)
                obj = json.loads(content_str)
                train_data = obj['data']
                hash = obj['hash']
                provider_id = obj['id']
                get = False
                if hash in self.labeled_list:
                    #already labeled by someone
                    self.labeled_list.remove(pretrain)
                    continue
                if self.train_data.qsize() == 0:
                    self.labeled_list.clear()

                show(train_data, hash, provider_id,
                    self.labels, \
                    self.label_text,\
                    self.label_num, \
                    self.input_name, self.subplot_position, \
                    self.show_functions, self.send_label)

                # self._plot(train_data, hash, provider_id)
        finally:
            logging.info('LABELER: {0} stop'.format(self.name))
    #
    # def _plot(self, input_arr, hash, provider_id):
    #     self.last_hash_key = hash
    #     self.last_provider = provider_id
        # fig=plt.figure(figsize=(10,10))
        # fig.canvas.mpl_connect('key_press_event', self.press)
        # fig.suptitle(self.label_text)
        # for index in range(0, len(self.input_name)):
        #     ax = plt.subplot(self.subplot_position[index])
        #     ax.set_title(self.input_name[index])
        #     plt.axis("off")
        #     self.show_functions[index](input_arr[index])
        # plt.show(block=False)
        # logging.info('show!!!')


    def send_label(self, last_key, last_hash_key, last_provider):
        request =  common_pb2.PretrainMsg(key=self.name, pretrain=last_hash_key, label=str(last_key), id=NODE_NAME)
        util.call_postman('LabeledData', request)

    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)
