import sys
sys.path.append(".")
import environ_set
# grpc protocol
import grpc
from concurrent import futures
import time

from protoc_py import labeler_pb2
from protoc_py import labeler_pb2_grpc

from google.protobuf import empty_pb2
from protoc_py import common_pb2

import os
import json

from common.util import util
from common.component import Learn, Function

from labeler import Labeler

import matplotlib.pyplot as plt

import logging
logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

LABELER_PORT = os.environ['LABELER_PORT']

MAX_WORKER = int(os.environ['MAX_WORKER'])


class InterLabeler(labeler_pb2_grpc.InterLabelerServicer):
    def __init__(self):
        self.learn_component = Learn(MAX_WORKER, self._create_labeler)

    def Exists(self, request, context):
        return empty_pb2.Empty()

    def LabeledIn(self, request, context):
        function_key = request.key
        labeler_map = self.learn_component.worker_map
        if function_key in pretrain_map.keys():
            labeler_map[function_key].label_data_in(request.pretrain, request.label, request.id)
        return empty_pb2.Empty()

    def TrainDataIn(self, request_iterator, context):
        context_dict,_ =util._context_dict(context)
        function_key = context_dict['key']
        learner_map = self.learn_component.worker_map
        if function_key in learner_map.keys():
            content_str = util.read_large_msg(request_iterator)
            learner_map[function_key].train_data_in(content_str)
            return common_pb2.ResponseMsg(success=True, msg="")
        else:
            return common_pb2.ResponseMsg(success=False, msg="not active")

    def AdvIn(self, request, context):
        relevant_functions = []
        recipes = json.loads(request.str)
        for recipe in recipes:
            self.check_function_list(recipe, relevant_functions)

        if len(relevant_functions) > 0:
            return common_pb2.ResponseMsg(success=True, msg=json.dumps(relevant_functions))
        else:
            return common_pb2.ResponseMsg(success=False, msg="")

    def check_function_list(self, recipe, relevant_functions):
        content_str = util.get_recipe().hget(recipe, 'content')
        contents = json.loads(content_str)
        for content in contents:
            function = content['process']['function']
            if function not in relevant_functions and function in self.learn_component.worker_map.keys():
                relevant_functions.append(function)


    def SynchronizeAdd(self, request, context):
        self.learn_component.SynchronizeAdd(request, context)
        return empty_pb2.Empty()

    def SynchronizeRevoke(self, request, context):
        self.learn_component.SynchronizeRevoke(request, context)
        return empty_pb2.Empty()

    def _create_labeler(self, function_key):
        function_obj = util.get_function().hgetall(function_key)
        function = Function(function_obj)
        if function.learn is not None:
            labeler =  Labeler(function.name, function.input_name, function.output_name, function.labels)
            labeler.start()
            return labeler
        else:
            return None


def grpc_start():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    labeler_pb2_grpc.add_InterLabelerServicer_to_server(InterLabeler(), server)
    server.add_insecure_port('localhost:{0}'.format(LABELER_PORT))
    server.start()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        SERVICE = 'LABELER'
        print('start {0} grpc server'.format(SERVICE))
        response = util.notify_postman(SERVICE)
        plt.show()
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)
        util.notify_postman(SERVICE, active=False)

if __name__ == "__main__":
    while not util.redis_available():
        continue
    grpc_start()
