import sys
sys.path.append(".")
import environ_set
import grpc
from concurrent import futures

import os
import time
import json

from protoc_py import learner_pb2
from protoc_py import learner_pb2_grpc

from google.protobuf import empty_pb2
from protoc_py import common_pb2

from common.util import util
from common.component import Learn, Function

from learner import Learner

import logging
logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

LEARNER_PORT = os.environ['LEARNER_PORT']
MAX_WORKER = int(os.environ['MAX_WORKER'])
LEARN_TFLITE_PATH = os.environ['LEARN_TFLITE_PATH']

class InterLearner(learner_pb2_grpc.InterLearnerServicer):
    def __init__(self):
        self.learn_component = Learn(MAX_WORKER, self._create_learner)

    def Exists(self, request, context):
        return empty_pb2.Empty()

    def PretrainIn(self, request_iterator, context):
        context_dict,_ =util._context_dict(context)
        function_key = context_dict['key']
        learner_map = self.learn_component.worker_map
        if function_key in learner_map.keys():
            content_str = util.read_large_msg(request_iterator)
            learner_map[function_key].pretrain_data_in(content_str)
            return common_pb2.ResponseMsg(success=True, msg="")
        else:
            return common_pb2.ResponseMsg(success=False, msg="not active")

    def AdvIn(self, request, context):
        relevant_functions = []
        functions = json.loads(request.str)
        for function in functions:
            if function in self.learn_component.worker_map.keys():
                relevant_functions.append(function)

        if len(relevant_functions) > 0:
            return common_pb2.ResponseMsg(success=True, msg=json.dumps(relevant_functions))
        else:
            return common_pb2.ResponseMsg(success=False, msg="")


    def SynchronizeAdd(self, request, context):
        self.learn_component.SynchronizeAdd(request, context)
        return empty_pb2.Empty()

    def SynchronizeRevoke(self, request, context):
        self.learn_component.SynchronizeRevoke(request, context)
        return empty_pb2.Empty()

    def _create_learner(self, function_key):
        functions = util.get_function()
        function_obj = util.get_function().hgetall(function_key)
        function = Function(function_obj)
        if function.learn is not None:
            learner = Learner(function.name, function.accuracy, function.module_size, function.samples, function.learn, len(function.labels), function.input_name, function.output_name)
            learner.start()
            return learner
        else:
            return None


def grpc_start():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    learner_pb2_grpc.add_InterLearnerServicer_to_server(InterLearner(), server)
    server.add_insecure_port('[::]:{0}'.format(LEARNER_PORT))
    server.start()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        SERVICE = 'LEARNER'
        print('start {0} grpc server'.format(SERVICE))
        util.notify_postman(SERVICE)
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)
        util.notify_postman(SERVICE, active=False)

if __name__ == "__main__":
    while not util.redis_available():
        continue
    grpc_start()
