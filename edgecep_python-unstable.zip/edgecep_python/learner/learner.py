import tensorflow as tf
import tensorflow_hub as hub

import json

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

from common.util import util

from protoc_py import postman_pb2

import threading

import logging

import os
import os.path

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

FAKE_QUANT_OPS = ('FakeQuantWithMinMaxVars',
                  'FakeQuantWithMinMaxVarsPerChannel')

input_tensor_name = "input"
final_tensor_name = "output"

class Learner(threading.Thread):
    def __init__(self, name, accuracy, size, samples, learn, class_count, input_name, output_name):
        threading.Thread.__init__(self)
        self.name = name
        self.init_stat(accuracy, size, samples)
        self.tfhub_module = learn.tfhub_module
        self.try_load_module(self.tfhub_module)
        self.learning_rate = float(learn.learning_rate)
        # self.step = int(learn.learn_step)
        self.batch_size = int(learn.batch_size)

        self.pretrain_data = Queue()

        self.pretrain_input = []
        self.pretrain_label = []
        self.count = 0

        self.CHECKPOINT_NAME, self.summaries_dir = util._checkpoint_path(name)

        self.class_count = class_count

        self.model_file_name = util._learn_tflite_path(name)
        self.input_name = input_name
        self.output_name = output_name

    def previous_stat(self):
        path = util._learn_stat_path(self.name)
        return util._stat_from_file(path)

    def init_stat(self, base_accuracy, base_size, base_samples):
        stat = self.previous_stat()
        if  stat != None:
            self.accuracy = stat['accuracy']
            self.samples = stat['samples']
            self.size = stat['size']
        else:
            self.accuracy = float(base_accuracy)
            self.size = int(base_size)
            self.samples = int(base_samples)

    def add_to_learn(self, pretrain, label):
        self.pretrain_input.append(pretrain)
        self.pretrain_label.append(label)
        self.count += 1
        logging.info('LEARNER: count:{0}/{1}'.format(self.count, self.batch_size))

        if self.count >= self.batch_size:
            if not self.module_spec:
                if not self.try_load_module(self.tfhub_module):
                    return None
            self.learn()
            self.reset()

    def try_load_module(self, tfhub_module):
        try:
            self.module_spec = hub.load_module_spec(tfhub_module)
            self.input_height, self.input_width = hub.get_expected_image_size(self.module_spec)
            self.input_depth = hub.get_num_image_channels(self.module_spec)
            self.init_checkpoint()
        except Exception as err:
            print(err)
            logging.warning('LEARNER: cannot load module {0}'.format(self.name))
            self.module_spec = None
        return self.module_spec

    def reset(self):
        self.pretrain_input = []
        self.pretrain_label = []
        self.count = 0

    def pretrain_data_in(self, content_str):
        obj = json.loads(content_str)
        pretrain = obj['pretrain']
        label = int(obj['label'])
        id = obj['id']
        self.pretrain_data.put((pretrain, label, id))

    def run(self):
        try:
            while True:
                (pretrain, label, id) = self.pretrain_data.get(block=True)
                self.add_to_learn(pretrain, label)
        finally:
            logging.warning('LEARNER: {0} stop'.format(self.name))

    def advertise(self):
        obj = {}
        obj['type'] = 'module'
        obj['key'] = self.name
        obj['accuracy'] = self.accuracy
        obj['samples'] = self.samples
        obj['size'] = self.size
        adv_str = json.dumps(obj)
        request = postman_pb2.SimpleMsg(prefix='ADV', content=adv_str)
        util.call_postman('SelfAdv', request)


    def init_checkpoint(self):
        graph, bottleneck_tensor, decoded_image_tensor, wants_quantization, jpeg_data_tensor = (self.create_module_graph())
        with graph.as_default():
            (train_step, cross_entropy, bottleneck_input, ground_truth_input, final_tensor) = self.add_final_retrain_ops(final_tensor_name,
                                                                                                                         wants_quantization,
                                                                                                                         is_training=True,
                                                                                                                         bottleneck_tensor=bottleneck_tensor)

            evaluation_step, _ = self.add_evaluation_step(final_tensor, ground_truth_input)




        with tf.Session(graph=graph) as sess:
            init = tf.global_variables_initializer()
            train_saver = tf.train.Saver()
            sess.run(init)
            train_saver.save(sess, self.CHECKPOINT_NAME)


    def learn(self):
        bottleneck_value = self.pretrain_input
        label = self.pretrain_label

        logging.info("LEANER: labels:{0}".format(label))

        self.samples += len(bottleneck_value)

        graph, bottleneck_tensor, decoded_image_tensor, wants_quantization, jpeg_data_tensor = (self.create_module_graph())
        with graph.as_default():
            (train_step, cross_entropy, bottleneck_input, ground_truth_input, final_tensor) = self.add_final_retrain_ops(final_tensor_name,
                                                                                                                         wants_quantization,
                                                                                                                         is_training=True,
                                                                                                                         bottleneck_tensor=bottleneck_tensor)

            accuracy, prediction = self.add_evaluation_step(final_tensor, ground_truth_input)

        with tf.Session(graph=graph) as sess:
            tf.train.Saver().restore(sess, self.CHECKPOINT_NAME)

            train_saver = tf.train.Saver()
            train_writer = tf.summary.FileWriter(self.summaries_dir + '/train', sess.graph)

            merged = tf.summary.merge_all()

            train_summary, _ = sess.run([merged, train_step], feed_dict={bottleneck_input: bottleneck_value,
                                                                         ground_truth_input: label})
            train_writer.add_summary(train_summary, 0)

            train_saver.save(sess, self.CHECKPOINT_NAME)

            accuracy_value = float(accuracy.eval(feed_dict={bottleneck_input: bottleneck_value,
                                                                      ground_truth_input: label}))

            if self.accuracy < accuracy_value:
                logging.info("LEANER: save:{0}.tflite accuracy:{1}".format(self.name, accuracy_value))
                tflite_model = self.save_graph_to_file()
                self.accuracy = accuracy_value
                self.size = len(tflite_model)
                self.save_stat()
                self.advertise()
            else:
                # update only sample number
                self.save_stat()

            tf.logging.info("End session")

    def save_graph_to_file(self):
        sess, input_tensor, output_tensor = self.build_eval_session()
        graph = sess.graph

        output_graph_def = tf.graph_util.convert_variables_to_constants(sess, graph.as_graph_def(), [final_tensor_name])

        input_array = [input_tensor]
        output_array= [output_tensor]
        tflite_model = tf.contrib.lite.toco_convert(output_graph_def, input_array, output_array)
        open(self.model_file_name, "wb").write(tflite_model)
        return tflite_model

    def save_stat(self):
        obj = {'size':self.size, 'samples':self.samples, 'accuracy':self.accuracy}
        open(util._learn_stat_path(self.name), "w").write(json.dumps(obj))

    def add_final_retrain_ops(self, final_tensor_name, quantize_layer, is_training, bottleneck_tensor):

        _, bottleneck_tensor_size = bottleneck_tensor.get_shape().as_list()
        with tf.name_scope('input'):
            bottleneck_input = tf.placeholder_with_default( bottleneck_tensor, shape=[None,
                                                                                          bottleneck_tensor_size],
                                                               name='BottleneckInputPlaceholder')
            ground_truth_input = tf.placeholder(tf.int64, [None], name='GroundTruthInput')

        # Organizing the following ops so they are easier to see in TensorBoard.
        layer_name = 'final_retrain_ops'
        with tf.name_scope(layer_name):
            with tf.name_scope('weights'):
                initial_value = tf.truncated_normal([bottleneck_tensor_size, self.class_count], stddev=0.001)
                layer_weights = tf.Variable(initial_value, name='final_weights')

            with tf.name_scope('biases'):
                layer_biases = tf.Variable(tf.zeros([self.class_count]), name='final_biases')

            with tf.name_scope('Wx_plus_b'):
                logits = tf.matmul(bottleneck_input, layer_weights) + layer_biases
                tf.summary.histogram('pre_activations', logits)

        final_tensor = tf.nn.softmax(logits, name=final_tensor_name)

        if quantize_layer:
            if is_training:
                tf.contrib.quantize.create_training_graph()
            else:
                tf.contrib.quantize.create_eval_graph()

        tf.summary.histogram('activations', final_tensor)
        # tf.logging.info("final result = {0}".format(final_tensor))
        # If this is an eval graph, we don't need to add loss ops or an optimizer.
        if not is_training:
            return None, None, bottleneck_input, ground_truth_input, final_tensor

        with tf.name_scope('cross_entropy'):
            cross_entropy_mean = tf.losses.sparse_softmax_cross_entropy(
                labels=ground_truth_input, logits=logits)

            tf.summary.scalar('cross_entropy', cross_entropy_mean)
            # tf.logging.info("cross entropy = {0}".format(cross_entropy_mean))

        with tf.name_scope('train'):
            optimizer = tf.train.GradientDescentOptimizer(self.learning_rate)
            train_step = optimizer.minimize(cross_entropy_mean)



        return (train_step, cross_entropy_mean, bottleneck_input, ground_truth_input,
              final_tensor)

    def create_module_graph(self):
        with tf.Graph().as_default() as graph:
            image_list_size = tf.placeholder(tf.int32, name='image_list_size')
            jpeg_data_tensor = tf.placeholder(tf.string, shape=[None], name=input_tensor_name)
            init_jpeg = tf.gather(jpeg_data_tensor, 0)
            resized_input_tensor = self.init_jpeg_decoding(init_jpeg)
            tf.while_loop(self.loop_condition, self.jpeg_decoding, [tf.constant(1), image_list_size, jpeg_data_tensor, resized_input_tensor])
            # assert False, "{0}".format(jpeg_data_tensor)
            m = hub.Module(self.module_spec)
            bottleneck_tensor = m(resized_input_tensor)
            wants_quantization = any(node.op in FAKE_QUANT_OPS
                                     for node in graph.as_graph_def().node)
        return graph, bottleneck_tensor, resized_input_tensor, wants_quantization, jpeg_data_tensor


    def loop_condition(self, i, image_list_size, jpeg_data_tensor, resized_input_tensor):
        return i < image_list_size


    def init_jpeg_decoding(self, jpeg_data_tensor):
        decoded_image = tf.image.decode_jpeg(jpeg_data_tensor, channels=self.input_depth)
        decoded_image_as_float = tf.image.convert_image_dtype(decoded_image,
                                                            tf.float32)
        decoded_image_4d = tf.expand_dims(decoded_image_as_float, 0)
        resize_shape = tf.stack([self.input_height, self.input_width])
        resize_shape_as_int = tf.cast(resize_shape, dtype=tf.int32)
        decoded_image_tensor = tf.image.resize_bilinear(decoded_image_4d,
                                               resize_shape_as_int)
        return decoded_image_tensor

    def jpeg_decoding(self, i, image_list_size, jpeg_data_tensor, resized_input_tensor):
        jpeg_data_item = tf.gather(jpeg_data_tensor, i)
        decoded_image = tf.image.decode_jpeg(jpeg_data_item, channels=self.input_depth)
        decoded_image_as_float = tf.image.convert_image_dtype(decoded_image,
                                                            tf.float32)
        decoded_image_4d = tf.expand_dims(decoded_image_as_float, 0)
        resize_shape = tf.stack([self.input_height, self.input_width])
        resize_shape_as_int = tf.cast(resize_shape, dtype=tf.int32)
        decoded_image_tensor = tf.image.resize_bilinear(decoded_image_4d,
                                               resize_shape_as_int)
        tf.concat([resized_input_tensor, decoded_image_tensor], 0)
        return i+1, image_list_size, jpeg_data_tensor, resized_input_tensor

    def add_evaluation_step(self, result_tensor, ground_truth_tensor):
        with tf.name_scope('accuracy'):
            with tf.name_scope('correct_prediction'):
                prediction = tf.argmax(result_tensor, 1)
                correct_prediction = tf.equal(prediction, ground_truth_tensor)
        with tf.name_scope('accuracy'):
            evaluation_step = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
            tf.summary.scalar('accuracy', evaluation_step)
        return evaluation_step, prediction

    def build_eval_session(self):
        graph, bottleneck_tensor, decoded_image_tensor, wants_quantization, jpeg_data_tensor = (self.create_module_graph())


        eval_sess = tf.Session(graph=graph)

        with graph.as_default():
            (train_step, cross_entropy, bottleneck_input, ground_truth_input, final_tensor) = self.add_final_retrain_ops(final_tensor_name,
                                                                                                                         wants_quantization,
                                                                                                                         is_training=False,
                                                                                                                         bottleneck_tensor=bottleneck_tensor)

            tf.train.Saver().restore(eval_sess, self.CHECKPOINT_NAME)

            accuracy, prediction = self.add_evaluation_step(final_tensor, ground_truth_input)


        return eval_sess, decoded_image_tensor, final_tensor


    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)
