import statsmodels.api as sm
import scipy.stats as stats

import math
import os.path
import numpy as np

import pickle
import logging
from common.util import util
from common.record import Record

def model_path(name):
    return 'processor/load_model/ml_{0}.sav'.format(name)

def model(name):
    path = model_path(name)
    if os.path.exists(path):
        return pickle.load(open(path, 'rb'))
    return None

def save(name, ml_ols):
    path = model_path(name)
    with open(path, 'wb') as file:
        pickle.dump(ml_ols, file)

MIN_THRESHOLD = 5

class Model():
    def __init__(self, name, renew=True):
        self.ml = None if renew else model(name)
        self.name = name
        self.last_avg = None

    def fit(self, records):
        labels, records = self._labels(records)
        if len(labels) < MIN_THRESHOLD:
            return None
        vars = self._vars(records)
        new_ml = sm.OLS(labels, vars)
        result = new_ml.fit()
        logging.info('MODEL: name:{0} labels:{1} vars:{2}'.format(self.name, labels, vars))
        save(self.name, result)
        self.ml = result

    def record(self, records):
        total = 0
        count = 0
        for record in records:
            time = record._complexity_time(self.name)
            if time > 0:
                total += time
                count += 1
        if count > 0:
            self.last_avg = total/count

    def _vars(self, records): # (n, l) * complexity
        return [record.var() for record in records]

    def _labels(self, records):
        labels = []
        new_records = []
        for record in records:
            time = record._complexity_time(self.name)
            if time > 0:
                labels.append(time)
                new_records.append(record)
        return labels, new_records

    def predict(self, input):
        if self.name in Record.complexity and self._n(input) == 0:
            output = [0]
        elif self.ml == None:
            if self.last_avg == None:
                index = Record.complexity.index(self.name)
                default_time = Record.default_time[index]
                for complexity in Record.complexity:
                    other_index = Record.complexity.index(complexity)
                    if other_index != index:
                        default_time += input[0][other_index*2]*Record.default_influence[other_index]
                    else:
                        default_time += (input[0][other_index*2]-1)*Record.default_influence[other_index]
                output = [default_time]
            else:
                output = [self.last_avg]
        else:
            output = self.ml.predict(input)
        logging.info('MODEL: name:{0} input:{1} predict:{2}'.format(self.name, input, output))
        return output

    def _n(self, input):
        index = Record.complexity.index(self.name)
        return input[0][index*2]

# -1 = infinity
MAX_SAMPLES = 100
DISTRIBUTION = ['uniform', 'expon', 'erlang']
DIST_MODEL = ['D', 'M', 'E']


try:
    import thread as thread
except ImportError:
    import _thread as thread

from pynverse import inversefunc

class QueueModel():
    def __init__(self, is_deterministic):
        self.lock = thread.allocate_lock()
        self.prev_record = None
        self.t_record = []
        self.depart_record = []
        self.model = 'MD1'
        index = 1
        self.k = None

        if is_deterministic:
            self.model = 'DD1'
            index = 0
        self.update_dist(index)

    def set_departure_rate(self, rate, acceptable_delay):
        self.departure_rate = rate
        self.acceptable_delay = acceptable_delay
        self.compute_max_arrival()
        return self.max_arrival > 0

    def update_dist(self, index, k=None):
        # self.total_delay = getattr(self, '{0}_total_delay'.format(self.model))
        with self.lock:
            self.model = '{0}D1'.format(DIST_MODEL[index])
            self.k = k
            self.arrival_func = getattr(self, '{0}_arrival_rate'.format(self.model))

    def compute_max_arrival(self):
        self.max_arrival = getattr(self, '{0}_max_arrival_rate'.format(self.model))()


    def fit_dist(self):
        if len(self.t_record) >= MAX_SAMPLES:
            maxp = 0
            maxk = None
            maxindex = -1
            for index in range(0, len(DISTRIBUTION)):
                try:
                    name = DISTRIBUTION[index]
                    param = getattr(stats, name).fit(self.t_record)
                    _, p = stats.kstest(self.t_record, name, args=param);
                    if math.isnan(p):
                        continue
                except:
                    continue
                if p > maxp:
                    maxindex = index
                    maxp = p
                    maxk = param[0]
            if maxindex >= 0:
                self.update_dist(maxindex, maxk)
                self.compute_max_arrival()
                print('QUEUE MODEL: model:{0} k:{1} max_arrival:{2}'.format(self.model, self.k, self.max_arrival))

    def arrive(self):
        arrived_time = util.current_timestamp()
        if self.prev_record:
            interval = arrived_time - self.prev_record
            self.t_record.append(interval)
            if len(self.t_record) > MAX_SAMPLES:
                self.t_record.pop(0)
        self.prev_record = arrived_time

    def depart(self, time):
        self.depart_record.append(time)
        if len(self.depart_record) > MAX_SAMPLES:
            self.depart_record.pop(0)
        self.departure_rate = np.mean(self.depart_record)
        self.compute_max_arrival()

    def choose(self):
        if self.prev_record:
            with self.lock:
                arrived_time = util.current_timestamp()
                interval = arrived_time - self.prev_record
                try_record = self.t_record + [interval]
                arrival_rate = self.arrival_func(try_record)
            return arrival_rate <= self.max_arrival
        return True

    def busy(self):
        arrival_rate = self.arrival_rate()
        return arrival_rate > self.max_arrival

    def arrival_rate(self):
        with self.lock:
            if len(self.t_record) == 0:
                return 0
            arrival_rate = self.arrival_func(self.t_record)
            logging.info('QUEUE MODEL: arrival_mean:{0}'.format(arrival_rate))
            return arrival_rate

    # def DD1_total_delay(self):
    #     if self._utilization_rate(self.arrival_rate()) > 1:
    #         return -1
    #     else:
    #         return self.departure_rate
    #
    # def MD1_total_delay(self):
    #     arrival_rate = self.arrival_rate()
    #     logging.info('PREDICTOR-QUEUE: depart:{0} arrive:{1}'.format(self.departure_rate, arrival_rate))
    #     if arrival_rate == 0:
    #         return 1/self.departure_rate
    #     rho = self._utilization_rate(arrival_rate)
    #     if rho > 1:
    #         return -1
    #     return 1/self.departure_rate + rho/(2*self.departure_rate*(1-rho))
    #
    # def GD1_total_delay(self):
    #     arrival_rate = self.arrival_rate()
    #     logging.info('PREDICTOR-QUEUE: depart:{0} arrive:{1}'.format(self.departure_rate, arrival_rate))
    #     if arrival_rate == 0:
    #         return 1/self.departure_rate
    #     rho = self._utilization_rate(arrival_rate)
    #     if rho > 1:
    #         return -1
    #     return 1/self.departure_rate + rho/(2*self.departure_rate*(1-rho))

    # def _utilization_rate(self, arrival_rate):
    #     if self.departure_rate == 0:
    #         return arrival_rate
    #     return arrival_rate/self.departure_rate

    def DD1_arrival_rate(self, records):
        return 1/np.mean(records)

    def MD1_arrival_rate(self, records):
        return 1/np.mean(records)

    def ED1_arrival_rate(self, records):
        return self.k/np.mean(records)

    def DD1_max_arrival_rate(self):
        return self.departure_rate

    def MD1_max_arrival_rate(self):
        return max(0, (2*self.departure_rate*(self.departure_rate*self.acceptable_delay - 1))/(2*self.departure_rate*self.acceptable_delay - 1))


    def ED1_max_arrival_rate(self):
        dq = self.acceptable_delay - 1/self.departure_rate
        if dq <= 0:
            return MD1_max_arrival_rate()

        x = 2*dq*math.pow(self.departure_rate, math.sqrt(2*self.k+2))
        func = (lambda y: math.pow(y, math.sqrt(2*self.k+2)-1)/(1-y/self.departure_rate))
        y = inversefunc(func, y_values=x)
        if np.isnan(y):
            return MD1_max_arrival_rate()

        return y
