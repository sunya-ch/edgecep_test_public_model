import threading
import time
import os
import math
import random
import json



import logging

from common.component import Recipe, Function, ProcessorInfo
from common.util import util

import psutil
import timeit
import datetime

import numpy as np

from common.rrb_list import PrioritizedRoundRobin
from common.syncdb import SynchronizedDB
from common.record import Record
from common.ts import AverageWindow
from model_fitting import Model, QueueModel
from predictor import PredictorLearn, Predictor

from protoc_py import postman_pb2
from protoc_py import common_pb2


LOOSE_PERIOD = int(os.environ['LOOSE_PERIOD'])
STRICT_PERIOD = int(os.environ['STRICT_PERIOD'])

DEFAULT_FORWARD_COST = 0.02

PREDICT_OP_INDEX = 3
MAX_RECORD = 100

MB = 1024 * 1024  # 100MB

WEIGHT_OF_EXISTANCE = int(os.environ['WEIGHT_OF_EXISTANCE'])
# RESERVED_MEMORY = int(os.environ['RESERVED_MEMORY'])
RESERVED_MEMORY = psutil.virtual_memory().total*float(os.environ['RESERVED_MEMORY_PERCENT'])

SPEC_CLASS_THRESHOLD = [40, 20, 0]
SPEC_CLASS_EFF_WEIGHT = [2.4, 0.6, 0]
SPEC_INIT_MAX_COMPLEXITY = [10, 5, 3]
MAX_REPLICATION = int(os.environ['MAX_REPLICATION'])

SPEC_CLASS_NUM = len(SPEC_CLASS_THRESHOLD)
PERFORMANCE_MODEL = Model('performance', renew=False)
CPU_FREQ = psutil.cpu_freq().current/1000

###############
##
## compute plan in loose period
## record cpu in strict period
##
##############
BATCH_SIZE = 10
LINEAR_RECORD_INDEX = 1
POLY_RECORD_INDEX = 3
EXPO_RECORD_INDEX = 5


ACCEPTABLE_EFFECT = float(os.environ['ACCEPTABLE_EFFECT']) # predicted time over base time


SCORE_RATE_THESHOLD = 2
DEFAULT_LOAD = 1024

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

### on_demand,  never (process all), always(no weight, round robin)
DECOMPOSER = os.environ['DECOMPOSER']
PARTITIONER = os.environ['PARTITIONER']

POOL_FUNCTION = '{0}_task_pool'.format(DECOMPOSER.lower())
APPEND_FUNCTION = '{0}_append_and_remove'.format(DECOMPOSER.lower())

logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

class Orchestrator(threading.Thread):
    def __init__(self, processor):
        self.idle_cpu_percent =  psutil.cpu_percent()
        self.spec_score = self._spec_score()
        print(self.spec_score)
        threading.Thread.__init__(self)

        self.FORWARD_COST = DEFAULT_FORWARD_COST
        self.forward_mean = AverageWindow(window_size=STRICT_PERIOD)

        self.processor = processor

        self.recipe_dict = {} # Recipe Name --> recipe
        # self.recipe_arrival_rate_x = {}
        # self.recipe_arrival_rate_y = {}
        # self.recipe_arrival_rate = {}
        self.recipe_empty_record = {}
        self.recipe_deterministic = {}

        self.function_dict = {} # Function Name --> function

        self.active_recipe = [] # Recipe Name
        self.active_score = 0

        self.processor_info = {} # Device Name --> processor
        self.am_i_lowest = True
        self.recipe_processor_turn = {} # Recipe Name --> processor device names with turn


        self.linear_ml = Model('linear') #load index of record, batch size
        self.polynomial_ml = Model('polynomial')
        self.exponential_ml = Model('exponential')


        self.records = []

        self.latest_requirement = []
        # self.benchmark_record = []
        # self.load_in_record = []
        # self.load_out_record = []

        # self.table_name = "processor"
        # self.field_list = ['device_name', 'spec_score', 'active_recipe', 'active_score']
        # self.type_list = ['text', 'real', 'text', 'real']
        # self.key_index_list = [0]
        # self.syncdb = SynchronizedDB(table_name, field_list, type_list, key_index_list)

        self.learn_component = PredictorLearn(RESERVED_MEMORY, create_function=self._create_predictor, weight_of_existance=WEIGHT_OF_EXISTANCE)

        if PARTITIONER == 'on_demand':
            self.rrb_min_level_func = self.multi_rrb_min_level_func
            self.rrb_max_level = 3
        else:
            self.rrb_min_level_func = self.single_rrb_min_level_func
            self.rrb_max_level = 1

        self._init_module_files()
        self._init_recipe_dict()
        self._init_function_dict()
        self._update_next_compute_time()

    def _init_module_files(self):
        function_keys = self.learn_component.worker_map.keys()
        for function_name in function_keys:
            self._load_module(function_name)

    def _init_recipe_dict(self):
        recipes = util.get_recipe()
        for recipe_name in recipes.keys():
            recipe_value = util.get_recipe().hgetall(recipe_name)
            recipe = Recipe(recipe_value)
            self._update_recipe(recipe_name, recipe)
        self._update_latest_requirement()

    def _update_recipe(self, recipe_name, recipe):
        self.recipe_dict[recipe_name] = recipe

        if recipe.required:
            # self.recipe_arrival_rate_x[recipe_name] = {}
            # self.recipe_arrival_rate_y[recipe_name] = {}
            # self.recipe_arrival_rate[recipe_name] = {}
            self.recipe_empty_record[recipe_name] = Record(recipe)
            self.recipe_deterministic[recipe_name] = {}
            for function_name in recipe.function_arr:
                self.recipe_deterministic[recipe_name][function_name] = recipe.is_deterministic(function_name)
                # self.recipe_arrival_rate_x[recipe_name][function_name] = []
                # self.recipe_arrival_rate_y[recipe_name][function_name] = []
                # self.recipe_arrival_rate[recipe_name][function_name] = 0
            self.recipe_processor_turn[recipe] = PrioritizedRoundRobin(max_level=self.rrb_max_level, better_func=self.rrb_better_func, min_level_func=self.rrb_min_level_func)

    def remove_recipe(self, recipe_name):
        del self.recipe_dict[recipe_name]
        # del self.recipe_arrival_rate_x[recipe_name]
        # del self.recipe_arrival_rate_y[recipe_name]
        # del self.recipe_arrival_rate[recipe_name]
        del self.recipe_empty_record[recipe_name]
        del self.recipe_deterministic[recipe_name]
        del self.recipe_processor_turn[recipe]

    def _update_latest_requirement(self):
        required_recipe_list = self._required_recipe()
        self.latest_requirement, assigned_recipe, real_requirement,_ = self._requirement_from_higher(required_recipe_list)
        return required_recipe_list, self.latest_requirement, assigned_recipe, real_requirement

    def _init_function_dict(self):
        functions = util.get_function()
        for function in functions.keys():
            function_value = util.get_function().hgetall(function)
            self.function_dict[function] = Function(function_value)

    def _spec_class_index(self, my_spec):
        for i in range(0, len(SPEC_CLASS_THRESHOLD)):
            if my_spec < SPEC_CLASS_THRESHOLD[i]:
                continue
            return i
        return len(SPEC_CLASS_THRESHOLD)-1

    def run(self):
        logging.info('Start running Orchestrator for every {0}s'.format(LOOSE_PERIOD))
        self.compute()
        while True:
            time.sleep(STRICT_PERIOD)
            self.try_fitting_model()
            # self.compute_latest_arrival_rate()
            if util.current_timestamp() > self.next_compute_time:
                self.compute(periodic=True)
            self.learn_component.refit_queue_model()

    def _update_next_compute_time(self):
        self.next_compute_time = util.current_timestamp() + LOOSE_PERIOD

    def interrupt_by_recipe(self, added=None, removed=None):
        recompute = False
        if added != None:
            recipe_value = util.get_recipe().hgetall(added)
            recipe = Recipe(recipe_value)
            self._update_recipe(added, recipe)
            if recipe.required:
                self.processor.renew_agent(added, recipe)
                recompute = True
        if removed != None:
            if removed in self.recipe_dict:
                self.remove_recipe(removed)
                recompute = True
        required_recipe_list, latest_requirement, assigned_recipe, real_requirement = self._update_latest_requirement()
        if recompute:
            self.clear_compute()
            self.compute(required_recipe_list=required_recipe_list, requirement=latest_requirement, assigned_recipe=assigned_recipe, real_requirement=real_requirement)

    def clear_compute(self):
        self.active_recipe = [] # Recipe Name
        self.active_score = 0


    def interrupt_by_function(self, added=None, removed=None):
        if added != None:
            function_value = util.get_function().hgetall(added)
            function = Function(function_value)
            self.function_dict[added] = function_value
        if removed != None:
            del self.recipe_dict[removed]


######################################
## Agent and Recipe
##
##

    def try_fitting_model(self):
        agent_records = []
        for _, agent in self.processor.recipe_agent.items():
            agent_records.append(agent.record)
            logging.info('RECORD: agent:{0} record:{1}'.format(agent.recipe.name, agent.record.print()))
        record = Record()
        for added in agent_records:
            record.add_record(added)
        self.records.append(record)
        if len(self.records) >= BATCH_SIZE:
            for complexity in Record.complexity:
                getattr(self, "{0}_ml".format(complexity)).fit(self.records)
            self.records.pop(0) #pop the oldest one
        else:
            for complexity in Record.complexity:
                getattr(self, "{0}_ml".format(complexity)).record(self.records)

    # def compute_latest_arrival_rate(self):
    #     compute_time = util.current_timestamp()
    #     for recipe_name, agent in self.processor.recipe_agent.items():
    #         latest_rate = agent.record.pop_latest_rate(compute_time)
    #         logging.info('ORCHESTRATOR-PREDICT: recipe:{0} latest_rate:{1} compute_time:{2}'.format(recipe_name, latest_rate, compute_time))
    #         for function_name, rate in latest_rate.items():
    #             x = self.recipe_arrival_rate_x[recipe_name][function_name]
    #             y = self.recipe_arrival_rate_y[recipe_name][function_name]
    #             x.append(compute_time)
    #             y.append(rate)
    #             if len(x) >= BATCH_SIZE: #enough to learn
    #                 try:
    #                     self.recipe_arrival_rate[recipe_name][function_name] = self._predict_next_arrival_rate(x,y)
    #                 except:
    #                     logging.warning('ORCHESTRATOR-PREDICT: cannot predict for recipe:{0} func:{1}'.format(recipe_name, function_name))
    #                     self.recipe_arrival_rate[recipe_name][function_name] = rate
    #                 self.recipe_arrival_rate_x[recipe_name][function_name].pop(0)
    #                 self.recipe_arrival_rate_y[recipe_name][function_name].pop(0)
    #             else: # use the latest rate
    #                 self.recipe_arrival_rate[recipe_name][function_name] = rate
    #             logging.info('ORCHESTRATOR-PREDICT: recipe:{0} func:{1} rate:{2}'.format(recipe_name, function_name, self.recipe_arrival_rate_y[recipe_name][function_name]))

    # def _predict_next_arrival_rate(self, x, y):
    #     logging.info('ORCHESTRATOR-PREDICT: x:{0} y:{1}'.format(x,y))
    #     x, y = self._pre_process_xy(x, y)
    #     sr = Series(data=y, index=x, dtype=np.float32)
    #     result = ARIMA(sr, order=(3,0,0)).fit()
    #     next_step= result.forecast()[0][0]
    #     logging.info('ORCHESTRATOR-PREDICT: arrival_rate:{0}'.format(next_step))
    #     return next_step # return rate

    # def _pre_process_xy(self, x, y):
    #     minx = int(min(x))
    #     maxx = int(max(x))
    #     newx = range(minx,maxx,LOOSE_PERIOD)
    #     newy = []
    #     i = 1
    #     for val in newx:
    #         if i > len(x):
    #             newy.append(y[i-1])
    #             break
    #         if val < x[i]:
    #             newy.append(y[i-1])
    #         else:
    #             newy.append(y[i])
    #             i += 1
    #     return newx, newy

    def compute(self, required_recipe_list=None, requirement=None, assigned_recipe=None, real_requirement=None, periodic=False, has_equal=True):
        if not required_recipe_list:
            required_recipe_list = self._required_recipe()
            requirement, assigned_recipe, real_requirement, has_equal = self._requirement_from_higher(required_recipe_list)
        spec_class_index = self._spec_class_index(self.spec_score)
        logging.info('ORCHESTRATOR-COMPUTE: spec:{0} score={1} requirement:{2}'.format(SPEC_CLASS_EFF_WEIGHT[spec_class_index], self.spec_score, requirement))
        pool, required_pool = getattr(self, POOL_FUNCTION)(required_recipe_list, requirement, assigned_recipe, spec_class_index)
        logging.info("ORCHESTRATOR-COMPUTE: total:{0} required:{1}".format(self.count_pool(pool), self.count_pool(required_pool)))
        is_stable = self._stable(real_requirement, assigned_recipe)
        if periodic or not is_stable or self._can_improve(real_requirement, pool):
            select_result = self._select(required_recipe_list, pool, required_pool, has_equal, real_requirement)
            if select_result:
                (score, selected_recipe, selected_function, accept_time, queue_model) = select_result
                self.apply(selected_recipe, selected_function, accept_time, queue_model, score)
                logging.info("ORCHESTRATOR-COMPUTE: select:{0} score:{1} accept_time:{2} fwd_cost:{3}".format(selected_recipe, score, accept_time, self.FORWARD_COST))
                print('apply: ', selected_recipe)
        self.latest_requirement = requirement
        self._update_next_compute_time()

    def count_pool(self, pool):
        arr = np.array(pool)
        unique_elements, counts_elements = np.unique(arr, return_counts=True)
        return (np.asarray((unique_elements, counts_elements)))


    def apply(self, selected_recipe, selected_function, accept_time, queue_model, score):
        self.learn_component._update_worker_map_from_list(selected_function)
        self.learn_component.set_queue_model(accept_time, queue_model)
        self.processor.apply(selected_recipe, self.recipe_dict)
        self.active_recipe = selected_recipe
        self.active_score = score
        adv_str = self.advertise_processor()
        if adv_str != "":
            request = postman_pb2.SimpleMsg(prefix='ADV', content=adv_str)
            util.call_postman('SelfAdv', request)

    def _stable(self, requirement, removed_tasks):
        requirement_copy = requirement.copy()
        if len(requirement) == 0:
            return True

        notin = False
        for recipe in self.active_recipe:
            if recipe not in requirement_copy:
                notin = True
            try:
                requirement_copy.remove(recipe)
            except ValueError:
                pass
        if len(requirement_copy) > 0 and notin:
            logging.warning('ORCHESTRATOR-COMPUTE: not stable, requires {0}'.format(requirement_copy))
            return False
        return True

    def _can_improve(self, real_requirement, pool):
        ## stable state already checked

        if len(self.active_recipe)==0:
            # select nothing
            return True
        if len(real_requirement) == 0:
            # no real requirement
            return True
        free_select = [x for x in self.active_recipe if x not in real_requirement]
        if len(free_select) > 0:
            # some free selection
            return True
        return False

    def _select(self, required_recipe_list, pool, required_pool, has_equal, real_requirement):

        if len(real_requirement) == 0:
            required_pool = []

        self.update_forwarding_cost()

        pool_copy = list(pool)
        previous_function_list = []
        selected_recipe_list = []
        under_requirement = True
        if has_equal:
            select_method = self.opportunistic_select
        else:
            select_method = self.max_select

        if len(required_pool) == 0:
            under_requirement = False
            required_pool = pool.copy()

        accept_time = {}
        queue_model = {}
        left_memory = RESERVED_MEMORY
        while len(required_pool) > 0:
            selected = select_method(required_pool)
            left_memory, accept_time, queue_model = getattr(self, APPEND_FUNCTION)(required_recipe_list, selected, selected_recipe_list, required_pool, left_memory, previous_function_list, accept_time, queue_model)
            self._remove_all(selected, required_pool)
            self._remove_all(selected, pool)
            if selected in real_requirement:
                real_requirement.remove(selected)
                if len(real_requirement) == 0:
                    required_pool = []

            if len(required_pool) == 0:
                required_pool = pool.copy()
                select_method = self.max_select
        score = len([x for x in pool_copy if x in selected_recipe_list])
        if not under_requirement and score <= self.active_score:
            # not change
            logging.info('ORCHESTRATOR-COMPUTE: prev:{0} score:{1} try:{2} score:{3} fwd_cost:{4}'.format(self.active_recipe, self.active_score, selected_recipe_list, score, self.FORWARD_COST))
            return None

        return (score, selected_recipe_list, previous_function_list, accept_time, queue_model)


    def opportunistic_select(self, required_pool):
        recipe_name = random.sample(required_pool, 1)[0]
        return recipe_name

    def max_select(self, required_pool):
        countpool = self.count_pool(required_pool)
        index = list(countpool[1]).index(str(max(countpool[1].astype(int))))
        recipe_name = countpool[0][index]
        return recipe_name


############ for round-robin #########################################
    def rrb_better_func(self, main_name, cmp_name):
        info = self._get_processor_info(main_name)
        cmp_info = self._get_processor_info(cmp_name)
        if not cmp_info:
            return False
        if not info:
            return True
        return ProcessorInfo.better_newinfo(info, cmp_info)

    def multi_rrb_min_level_func(self, cmp_name):
        my_info = ProcessorInfo(self.spec_score, self.active_recipe, self.active_score, None)
        cmp_info = self._get_processor_info(cmp_name)
        if not cmp_info:
            return len(SPEC_CLASS_THRESHOLD)-1
        return self._spec_class_index(cmp_info.spec_score)

    def single_rrb_min_level_func(self, cmp_name):
        return 0

    def _get_processor_info(self, name):
        if not name:
            return ProcessorInfo(self.spec_score, self.active_recipe, self.active_score, None)
        if name not in self.processor_info:
            return None
        else:
            return self.processor_info[name]
########################################################################

    def _requirement_from_higher(self, required_recipe_list):
        requirement = self._full_requirement(required_recipe_list)
        real_requirement = requirement.copy()
        assigned_recipe = []
        has_equal = False
        my_info = ProcessorInfo(self.spec_score, self.active_recipe, self.active_score, None)
        for _, info in self.processor_info.items():
            if ProcessorInfo.better_newinfo(my_info, info):
                if ProcessorInfo.equal_info(my_info, info):
                    has_equal = True
                else:
                    assigned_recipe += info.active_recipe
                    for recipe in info.active_recipe:
                        try:
                            requirement.remove(recipe)
                        except ValueError:
                            pass
            for recipe in info.active_recipe:
                try:
                    real_requirement.remove(recipe)
                except ValueError:
                    pass
        real_requirement = list(dict.fromkeys(real_requirement))
        logging.info('processor info: {0}'.format(self.processor_info.keys()))
        return requirement, assigned_recipe, real_requirement, has_equal


    def _required_recipe(self):
        return [recipe for name, recipe in self.recipe_dict.items() if recipe.required]

    def _full_requirement(self, required_recipe_list):
        requirement =  []
        for recipe in required_recipe_list:
            replication_number = int(max(1, math.ceil(recipe.reliability * MAX_REPLICATION)))
            requirement += [recipe.name]*replication_number
        return requirement

    def on_demand_task_pool(self, recipe_list, requirement, assigned_recipe, spec_class_index):
        pool =  []
        required_pool = []
        spec_eff = SPEC_CLASS_EFF_WEIGHT[spec_class_index]

        for recipe in recipe_list:
            eff = recipe.efficiency
            rel = recipe.reliability
            avail = recipe.availability
            # score from qos
            score = int(math.ceil(MAX_REPLICATION * (eff * spec_eff + rel + avail)))
            # score from existance
            if recipe.name in self.active_recipe:
                score += WEIGHT_OF_EXISTANCE

            pool += [recipe.name] * score

            left_number = requirement.count(recipe.name)
            if left_number > 0:
                required_score = int(math.ceil(MAX_REPLICATION * (eff * spec_eff + avail) + left_number))
                required_pool += [recipe.name] * required_score
        # remove replications effect
        for assigned in assigned_recipe:
            count = assigned_recipe.count(assigned)
            if count > 1:
                try:
                    for _ in range(1, count):
                        pool.remove(assigned)
                except:
                    pass
        return pool, required_pool

    def always_task_pool(self, recipe_list, requirement, assigned_recipe, spec_class_index):
        pool =  []
        required_pool = []
        for recipe in recipe_list:
            pool += [recipe.name]
            if requirement.count(recipe.name) > 0:
                required_pool += [recipe.name]
        return pool, required_pool

    def never_task_pool(self, recipe_list, requirement, assigned_recipe, spec_class_index):
        return self.on_demand_task_pool(recipe_list, requirement, assigned_recipe, spec_class_index)

    def _remove_all(self, item, item_list):
        while True:
            try:
                item_list.remove(item)
            except:
                break

    def on_demand_append_and_remove(self, required_recipe_list, selected, tasks, requirement, left_memory, previous_function_list, prev_accept_time, prev_queue_model):
        if selected not in tasks:
            try_select_list = tasks.copy()
            try_select_list.append(selected)
            selected_recipe = self.recipe_dict[selected]
            mem_valid, size, new_function = self._check_memory_validity(selected_recipe, previous_function_list, left_memory)
            if mem_valid:
                success, accept_time, queue_model = self._check_time_validity(try_select_list) # check time validity
                if success:
                    if self._load_module_in_list(new_function): # try downloading new function
                        left_memory = left_memory - size
                        previous_function_list += new_function
                        tasks.append(selected)
                        return left_memory, accept_time, queue_model
        return left_memory, prev_accept_time, prev_queue_model

    def never_append_and_remove(self, required_recipe_list, selected, tasks, requirement, left_memory, previous_function_list, prev_accept_time, prev_queue_model):
        if selected not in tasks:
            try_select_list = tasks.copy()
            try_select_list.append(selected)
            selected_recipe = self.recipe_dict[selected]
            _, size, new_function = self._never_check_memory_validity(selected_recipe, previous_function_list)
            success, accept_time, queue_model = self._check_time_validity(try_select_list, instant_break=False) # check time validity
            if self._load_module_in_list(new_function): # try downloading new function
                left_memory = left_memory - size
                previous_function_list += new_function
                tasks.append(selected)
                return left_memory, accept_time, queue_model
        return left_memory, prev_accept_time, prev_queue_model

    def always_append_and_remove(self, required_recipe_list, selected, tasks, requirement, left_memory, previous_function_list, prev_accept_time, prev_queue_model):
        return self.on_demand_append_and_remove(required_recipe_list, selected, tasks, requirement, left_memory, previous_function_list, prev_accept_time, prev_queue_model)

    def _load_module_in_list(self, new_function):
        loaded = []
        success = True
        for function_name in new_function:
            if not self._load_module(function_name):
                logging.warning('ORCHESTRATOR-MODULE: fail to load {0}'.format(function_name))
                success = False
                break
            loaded.append(function_name)
        if not success:
            for load in loaded:
                self._remove_module(load)
        return success

    # def _check_time_validity(self, required_recipe_list, selected_recipe_list, last_added_recipe):
    #     n_complexity_arr = self._n_complexity(selected_recipe_list)
    #     l_complexity_arr = self._l_complexity(required_recipe_list)
    #     base = self._get_base_input(l_complexity_arr)
    #     logging.info("L: {0}, N: {1}".format(l_complexity_arr, n_complexity_arr))
    #     unlabeled = self._get_compare_input(n_complexity_arr, l_complexity_arr)
    #     if not self.test_unlabeled(selected_recipe_list, unlabeled, n_complexity_arr, base):
    #         max_degree = self._potential_degree(last_added_recipe.name)
    #         degree = max_degree
    #         best_unlabeled = None
    #         while degree > 1: # start trying from largest distribution
    #             unlabeled = self._try_scale_out(n_complexity_arr, l_complexity_arr, last_selected_recipe, degree)
    #             if unlabled is None:
    #                 break
    #             if self.test_unlabeled(selected_recipe_list, unlabled, n_complexity_arr, base):
    #                 best_unlabeled = unlabled # always larger than previous loop
    #             else:
    #                 break
    #             degree -= 1
    #         if best_unlabeled is not None:
    #             return True, True, best_unlabeled
    #         else:
    #             return False, False, None
    #     return True, False, unlabeled

    def _check_time_validity(self, selected_recipe_list,instant_break=True):
        selected_var, total_n, avg_load = self._selected_var(selected_recipe_list)
        base_vars = self._base_vars(avg_load)
        # queue_model, total_arrival_rate, complexity_function_list = self._queue_info(selected_recipe_list)
        queue_model, complexity_function_list = self._queue_info(selected_recipe_list)
        complexity_len = self._complexity_len()
        accept_time = []
        is_acceptable = True
        for i in range(0, complexity_len):
            complexity = Record.complexity[i]
            model = getattr(self, "{0}_ml".format(complexity))
            base_time = model.predict([base_vars[i]])[0]
            acceptable = max(base_time * ACCEPTABLE_EFFECT, self.FORWARD_COST + base_time)
            accept_time.append(acceptable)
            if total_n == 0:
                base_rate = self._rate_from_time(base_time)
                self.set_departure_rate(queue_model, base_rate, complexity_function_list[i], acceptable)
                continue

            predicted_time = model.predict([selected_var])[0]
            departure_rate = self._rate_from_time(predicted_time)
            # set and check queue_model
            # if self.unacceptable(queue_model, total_arrival_rate, departure_rate, complexity_function_list[i], acceptable,instant_break):
            if self.set_departure_rate(queue_model, departure_rate, complexity_function_list[i], acceptable):
                time_invalid = predicted_time > acceptable
            else:
                time_invalid = True
                logging.warning('ORCHESTRATOR-COMPUTE: zero max arrival queue')
            if time_invalid:
                is_acceptable  = False
                if instant_break:
                    break
        return is_acceptable, accept_time, queue_model

    # def unacceptable(self, queue_model, total_arrival_rate, departure_rate, function_list, acceptable, instant_break=True):
    #     unacceptable = False
    #     for function in function_list:
    #         queue_model[function].set_departure_rate(departure_rate, acceptable)
    #         total_delay = queue_model[function].total_delay(total_arrival_rate[function])
    #         if total_delay > acceptable:
    #             logging.warning("ORCHESTRATOR-COMPUTE: time over at function {0}({1} > {2})".format(function, total_delay, acceptable))
    #             unacceptable = True
    #             if instant_break:
    #                 break
    #     return unacceptable

    def set_departure_rate(self, queue_model, base_rate, function_list, acceptable):
        queue_valid = True
        for function in function_list:
            valid = queue_model[function].set_departure_rate(base_rate, acceptable)
            if not valid:
                queue_valid = False
        return queue_valid

    # def _queue_info(self, selected_recipe_list):
    #     complexity_function_list = []
    #     for _ in Record.complexity:
    #         complexity_function_list.append([])
    #     queue_model = {}
    #     total_arrival_rate = {}
    #     for recipe_name in selected_recipe_list:
    #         for function_name, arrival_rate in self.recipe_arrival_rate[recipe_name].items():
    #             if function_name not in queue_model.keys():
    #                 # new function
    #                 total_arrival_rate[function_name] = arrival_rate
    #                 queue_model[function_name] = QueueModel(self.recipe_deterministic[recipe_name][function_name])
    #                 index = self.function_dict[function_name].complexity
    #                 complexity_function_list[index].append(function_name)
    #             else:
    #                 total_arrival_rate[function_name] += arrival_rate
    #                 if queue_model[function].deterministic:
    #                     if not self.recipe_deterministic[recipe_name][function_name]: # not deterministic anymore
    #                         queue_model[function] = QueueModel(False)
    #
    #     return queue_model, total_arrival_rate, complexity_function_list

    def _queue_info(self, selected_recipe_list):
        complexity_function_list = []
        for _ in Record.complexity:
            complexity_function_list.append([])
        queue_model = {}
        for recipe_name in selected_recipe_list:
            for function_name in self.recipe_dict[recipe_name].function_arr:
                if function_name not in queue_model.keys():
                    queue_model[function_name] = QueueModel(self.recipe_deterministic[recipe_name][function_name])
                    index = self.function_dict[function_name].complexity
                    complexity_function_list[index].append(function_name)
                elif queue_model[function].deterministic \
                    and not self.recipe_deterministic[recipe_name][function_name]: # not deterministic anymore
                        queue_model[function] = QueueModel(False)
        return queue_model, complexity_function_list

    def _rate_from_time(self, time):
        return 0 if time == 0 else 1/time

    def _selected_var(self, selected_recipe_list):
        var = []
        avg_load = []
        total_ns = []
        for complexity in Record.complexity:
            total_n = 0
            total_l = 0
            for recipe in selected_recipe_list:
                record = self.recipe_empty_record[recipe]
                total_n += record._complexity_n(complexity)
                total_l += record._complexity_load(complexity)
            avg_l = 0 if total_n == 0 else total_l/total_n
            var += [total_n, avg_l]
            avg_load.append(avg_l)
            total_ns.append(total_n)
        return var, total_ns, avg_load

    def _base_vars(self, avg_load):
        base = []
        complexity_len = len(Record.complexity)
        for i in range(0, complexity_len):
            base_record = []
            for j in range(0, i):
                base_record.append(0)
                base_record.append(0)
            base_record.append(1)
            base_record.append(avg_load[i])
            for j in range(i+1, complexity_len):
                base_record.append(0)
                base_record.append(0)
            base.append(base_record)
        return base


    # def test_unlabeled(self, selected_recipe_list, unlabeled, n_complexity_arr, base):
    #     complexity_len = self._complexity_len()
    #     for i in range(0, complexity_len):
    #         n = n_complexity_arr[i]
    #         if n == 0:
    #             continue
    #         complexity = Record.complexity[i]
    #         model = getattr(self, "{0}_ml".format(complexity))
    #         predicted_time = model.predict([unlabeled])[0]
    #         base_time = model.predict([base[complexity]])[0]
    #         acceptable = base_time * ACCEPTABLE_EFFECT
    #         if predicted_time > acceptable:
    #             logging.warning("time over with {0} ({1} > {2})".format(selected_recipe_list, predicted_time, acceptable))
    #             return False
    #     logging.warning("pass time check with {0}".format(selected_recipe_list))
    #     return True

    def _check_memory_validity(self, selected_recipe, previous_function_list, left_memory):
        size = 0
        new_function = []
        for function_name in selected_recipe.function_arr:
            if function_name not in previous_function_list:
                size += PredictorLearn.get_function_size(function_name)
                new_function.append(function_name)
                if left_memory < size:
                    logging.warning("ORCHESTRATOR-COMPUTE: memory over with {0}".format(selected_recipe.name))
                    return False, 0, []
        return True, size, new_function

    def _never_check_memory_validity(self, selected_recipe, previous_function_list):
        size = 0
        new_function = []
        for function_name in selected_recipe.function_arr:
            if function_name not in previous_function_list:
                size += PredictorLearn.get_function_size(function_name)
                new_function.append(function_name)
        return True, size, new_function

    def _complexity_len(self):
        return len(Record.complexity)

    def _default_load(self, required_recipe_list):
        complexity_len = self._complexity_len()
        count = [0] * complexity_len
        output = [0] * complexity_len
        for recipe in required_recipe_list:
            added_output, added_count = self._default_load_from_recipe(recipe)
            for index in range(0, complexity_len):
                output[index] +=  added_output[index]
                count[index] += added_count[index]
        for index in range(0, complexity_len):
            if count[index] > 0:
                output[index] /= count[index]
        return output


    # def _l_complexity(self, required_recipe_list):
    #     default_load = self._default_load(required_recipe_list)
    #     output = default_load.copy()
    #     record_size = len(self.records)
    #
    #     if record_size > BATCH_SIZE:
    #         total_count = [0] * self._complexity_len()
    #         load_data = {}
    #         for complexity in Record.complexity:
    #             load_data[complexity] = []
    #
    #         for record in self.records:
    #             complexity_index = 0
    #             for complexity in Record.complexity:
    #                 value = getattr(record, complexity)
    #                 load = value[0]
    #                 count = value[2]
    #                 if count > 0:
    #                     total_count[complexity_index] += count
    #                     load_data[complexity].append(load)
    #                 else:
    #                     total_count[complexity_index] += 1
    #                     load_data[complexity].append(default_load[complexity_index])
    #                 complexity_index += 1
    #
    #         index = range(0, len(self.records))
    #         df = DataFrame(data=load_data, index=index)
    #         load_model = VAR(df)
    #         fit_model = load_model.fit(2)
    #         forecast_output = fit_model.forecast(fit_model.y, steps=1)[0]
    #
    #         for i in range(0, self._complexity_len()):
    #             output[i] = forecast_output[i]/total_count[i]
    #
    #     elif record_size > 0:
    #         complexity_index = 0
    #         for complexity in Record.complexity:
    #             value = getattr(record, complexity)
    #             load = value[0]
    #             count = value[2]
    #             if count > 0:
    #                 output[complexity_index] = load
    #             complexity += 1
    #
    #     return output

    def _get_base_input(self, l_complexity_arr):
        base = {}
        complexity_len = len(Record.complexity)
        for i in range(0, complexity_len):
            base_record = []
            for j in range(0, i):
                base_record.append(0)
                base_record.append(0)
            base_record.append(1)
            base_record.append(l_complexity_arr[i])
            for j in range(i+1, complexity_len):
                base_record.append(0)
                base_record.append(0)
            base[Record.complexity[i]] = base_record
        return base

    def _get_compare_input(self, n_complexity_arr, l_complexity_arr):
        unlabeled = []
        complexity_len = self._complexity_len()
        for i in range(0, complexity_len):
            n = n_complexity_arr[i]
            l = l_complexity_arr[i] * n
            unlabeled.append(n)
            unlabeled.append(l)
        return unlabeled


    def _default_load_from_recipe(self, recipe):
        complexity_len = self._complexity_len()
        count = [0] * complexity_len
        input_size = [0] * complexity_len
        logging.info(recipe.name)
        for i in range(0, len(recipe.function_arr)):
            size = recipe.input_size_arr[i]
            index = recipe.complexity_arr[i]
            input_size[index] += size
            count[index] += 1
        return input_size, count

    def _potential_degree(self, recipe_name):
        if recipe_name in self.recipe_processor_turn:
            return self.recipe_processor_turn[recipe_name].degree
        return 1

    # def _try_scale_out(self, n_complexity_arr, l_complexity_arr, last_selected_recipe, degree):
    #     recipe_name = last_selected_recipe.name
    #     unlabeled = []
    #     ratio = 1.0/degree
    #     complexity_len = self._complexity_len()
    #     default_load, default_count = self._default_load_from_recipe(last_selected_recipe)
    #     for i in range(0, complexity_len):
    #         n = n_complexity_arr[i]
    #         predicted_l = l_complexity_arr[i]
    #         last_n = default_count[i]
    #         assert n > last_n, "n always more than last n "
    #         limit[i] = -1
    #         if last_n > 0:
    #             input_number = predicted_l/last_n
    #             if input_number < 0:
    #                 logging.info('input number is less than 0')
    #                 return None
    #             limit_number = math.ceil(ratio*input_number)
    #             added_load =  limit_number * last_n
    #         else:
    #             added_load = 0
    #         fixed_load = predicted_l * (n - last_n)
    #         l = fixed_load + added_load
    #         unlabeled.append(n)
    #         unlabeled.append(l)
    #     return unlabeled

    # def _function_limit(self, selected_recipe_list, unlabled):
    #     function_weight = self._function_weight(selected_recipe_list)
    #     function_limit = {}
    #     for function in function_weight.keys():
    #         complexity = util.get_function().hget(function, 'meta-data.complexity')
    #         complexity_index = Record.complexity.index(complexity)
    #         expected_load = self._load_from_unlabeled(unlabled, complexity_index)
    #         function_limit[function] = function_weight[function] * expected_load
    #     logging.info('function limit: {0} from {1}'.format(function_limit, unlabled))
    #     return function_limit
    #
    # def _load_from_unlabeled(self, unlabeled, complexity_index):
    #     load_index = int(complexity_index*2 + 1)
    #     return unlabeled[load_index]
    #
    # def _function_weight(self, selected_recipe_list):
    #     function_total_input = self._function_total_input(selected_recipe_list)
    #     function_weight = {}
    #     sum_total = 0
    #     for _, size in function_total_input.items():
    #         sum_total += size
    #     for function in function_total_input.keys():
    #         function_weight[function] = function_total_input[function]/sum_total
    #     logging.info('function weight: {0}'.format(function_weight))
    #     return function_weight
    #
    # def _function_total_input(self, selected_recipe_list):
    #     function_total_input = {}
    #     for recipe_name in selected_recipe_list:
    #         recipe = self.recipe_dict[recipe_name]
    #         for i in range(0, len(recipe.function_arr)):
    #             function = recipe.function_arr[i]
    #             input_size = recipe.input_size_arr[i]
    #             if function not in function_total_input.keys():
    #                 function_total_input[function] = input_size
    #             else:
    #                 function_total_input[function] += input_size
    #     return function_total_input


##########################################
## Advertisement
## - module advertise
## - processor advertise
##
##
##
#########################################

    def _update_module_files(self, removed, added, replaced):
        for function_name in removed:
            self._remove_module(function_name)
        for function_name in added:
            self._load_module(function_name)
        for function_name in replaced:
            self._load_module(function_name)

    def _remove_module(self, function_name):
        path = util._tflite_path(function_name)
        if os.path.exists(path) or os.path.islink(path):
            stat_path= util._model_stat_path(function_name)
            os.remove(path)
            os.remove(stat_path)

    def _load_module(self, function_name):
        stat_path = util._model_stat_path(function_name)
        path = util._tflite_path(function_name)
        advs = util.get_adv()
        adv_obj = self._get_adv_obj(advs, function_name)

        if not os.path.exists(stat_path):
            logging.info('ORCHESTRATOR-MODULE: new:{0}'.format(function_name))
            # create download message
            functions = util.get_function()
            base_value = util._compute_module_value(functions, function_name, 'meta-data.accuracy', 'meta-data.samples') # base value

            success = False
            if adv_obj:
                adv_value = util._compute_module_value(advs, function_name, 'accuracy', 'samples')
                if adv_value > base_value: # load the best adv
                    success = self._load_module_from_adv(adv_obj, function_name)
            else:
                logging.warning('ORCHESTRATOR-MODULE: key:{0} no advertisement'.format(function_name))
            if not success:
                base_download = self._load_base_module(function_name, path)
                if not base_download:
                    if adv_obj: # try base or local first
                        return self._load_module_from_adv(adv_obj, function_name) # try load no matter lower value
                    return False
            return True
        else:
            logging.info('ORCHESTRATOR-MODULE: improve:{0}'.format(function_name))
            if adv_obj:

                adv_value = util._compute_module_value_raw(float(adv_obj['accuracy']), int(adv_obj['samples']), None)

                stat = util._stat_from_file(stat_path)
                cur_value = util._compute_module_value_raw(float(stat['accuracy']), int(stat['samples']), None)

                if adv_value > cur_value:
                    self._load_module_from_adv(adv_obj, function_name)
            else:
                logging.warning('ORCHESTRATOR-MODULE: key:{0} no advertisement'.format(function_name))
        return True

    def _get_adv_obj(self, advs, function_name):
        if function_name in advs.keys():
            return advs.hgetall(function_name)
        return None

    def _load_module_from_adv(self, adv_obj, function_name):
        ip = adv_obj['ip']
        logging.info('ORCHESTRATOR-MODULE: key:{0} from:{1}'.format(function_name, ip))

        if ip == "":
            return self.try_link_own_learn(function_name)
        elif ip:
            return self.load(function_name, ip, adv_obj)

    def _load_base_module(self, function_name, path):
        function = util.get_function().hgetall(function_name)
        url = function['meta-data.base_model']
        request = postman_pb2.DownloadMsg(url=url, save_path=path)
        response = util.call_postman('PullFile', request)
        if not response.success:
            logging.warning('ORCHESTRATOR-MODULE: fail to load base of {0}'.format(function_name))
            return self.try_link_own_learn(function_name)
        else:
            self.save_stat(function_name, function['meta-data.module_size'], function['meta-data.samples'], function['meta-data.accuracy'])
        return True # successfully download

    def try_link_own_learn(self, function_name):
        logging.info('try link own learn')
        learn_stat_path = util._learn_stat_path(function_name)
        learn_path = util._learn_tflite_path(function_name)
        if os.path.exists(learn_stat_path):
            tf_path = util._tflite_path(function_name)
            self._remove_module(function_name)
            os.symlink(learn_path, tf_path)
            stat = util._stat_from_file(learn_stat_path)
            self.save_stat(function_name, stat['size'], stat['samples'], stat['accuracy'])
            return True
        return False


    def _handle_adv_module(self, new_adv):
        # if new_adv["ip"] == "":
        #     new_adv["size"] = 0 # own advertisement
        # new_adv["timestamp"] = util.current_timestamp()
        # key = new_adv["key"]
        # advs = util.get_adv()
        # expired = util.current_timestamp() - STRICT_PERIOD
        #
        # if key in advs.keys():
        #     prev_adv_value = util._compute_module_value(advs, key, 'accuracy', 'samples')
        #     new_adv_values = new_adv["accuracy"] * new_adv["samples"]
        #     prev_timestamp = float(advs.hget(key, 'timestamp'))
        #     if prev_timestamp < expired:
        #         logging.info('expired')
        #         is_added = True
        #     elif prev_accuracy < new_adv_values:
        #         logging.info('lower value')
        #         is_added = True
        # else:
        #     is_added = True
        #
        # if is_added:
        #     self._save_to_db(advs, new_adv, request)

        key = new_adv["key"]
        if key in self.learn_component.worker_map.keys():
            self._load_module_from_adv(new_adv, key)
            return common_pb2.ResponseMsg(success=True, msg=key)
        return common_pb2.ResponseMsg(success=False, msg="")

    def load(self, key, ip, adv_obj):
        request = common_pb2.SimpleString(str=key)
        success, file_data = util.pull_large_msg_from_other_postman(ip, 'LoadModule', request)
        if not success:
            return False
        if file_data != "":
            tflite_path = util._tflite_path(key)
            file_data = bytearray(json.loads(file_data))
            open(tflite_path, "wb").write(file_data)
            self.save_stat(key, adv_obj['size'], adv_obj['samples'], adv_obj['accuracy'])
            return True
        return False

    def save_stat(self, key, size, samples, accuracy):
        obj = {'size': size, 'samples':samples, 'accuracy':accuracy}
        open(util._model_stat_path(key), "w").write(json.dumps(obj))


    def _save_to_db(self, advs, new_adv, interface):
        key = new_adv["key"]
        del new_adv["key"]
        new_adv["interface"] = interface
        new_adv["accuracy"] = str(new_adv["accuracy"])
        new_adv["size"] = str(new_adv["size"])
        advs.hmset(key, new_adv, ex=STRICT_PERIOD)

    def _create_predictor(self, function_key):
        predictor = Predictor(function_key)
        predictor.start()
        return predictor

############# END MODULE INFO HANDLER #########################

############# BEGIN PROCESSOR INFO HANDLER ####################

    def _spec_score(self):
        cpu_left = psutil.cpu_count() * (100 - psutil.cpu_percent(interval=0.1))/100
        return PERFORMANCE_MODEL.predict([CPU_FREQ, cpu_left])[0]

    def record_load(self, recipe_name, size):
        if recipe_name in self.recipe_dict.keys():
            self.recipe_dict[recipe_name].complexity

        instr = "in" if inbound else "out"
        record = getattr(self, 'load_{0}_record'.format(instr))
        timestamp_bucket = int(util.current_timestamp())/10 # bucket 10s
        if len(record ) > 0:
            if timestamp_bucket == record[-1][1]:
                record[-1][0] = record[-1][0] + size
                return None
        record.append([size, timestamp_bucket])

    # def record_benchmark(self, timestamp):
    #     cpu_percent = psutil.cpu_percent()
    #     benchmark = timeit.timeit(benchmark_func)
    #     if len(self.benchmark_record) >= MAX_RECORD:
    #         self.benchmark_record.pop(0)
    #     cpu_diff = 0 if cpu_percent < self.idle_cpu_percent else cpu_percent - self.idle_cpu_percent
    #     self.benchmark_record.append([cpu_diff,timestamp, benchmark])
    #
    # def predict_regression(self):
    #     nparr = np.array(self.benchmark_record)
    #     cpu_percent_ts = nparr[:, 0:2]
    #     benchmark_ts = nparr[:, 1:3]
    #     # VAR Regression
    #     # Predict when cpu_percent = 100
    #     pass
    #     return 0, 0 # benchmark, load

    def _handle_adv_processor(self, adv_obj):
        device_name = adv_obj["name"]
        spec_score = adv_obj["spec"]
        active_recipe = adv_obj["namelist"]
        active_score = adv_obj["score"]
        ip = adv_obj["ip"]
        info  = ProcessorInfo(spec_score, active_recipe, active_score, ip)
        prev_info = None
        prev_score = -1
        equal = False
        if device_name in self.processor_info:
            prev_info = self.processor_info[device_name]
            prev_score = prev_info.active_score
            better = ProcessorInfo.better_newinfo(prev_info, info)
            equal = ProcessorInfo.equal_info(prev_info, info)
            logging.info('equally {0}'.format(device_name))
            if better:
                # self.am_i_lowest = True
                self.am_i_really_lowest()

        self.processor_info[device_name] = info
        for recipe in active_recipe:
            if recipe not in self.recipe_processor_turn:
                self.recipe_processor_turn[recipe] = PrioritizedRoundRobin(max_level=self.rrb_max_level, better_func=self.rrb_better_func, min_level_func=self.rrb_min_level_func)
                self.recipe_processor_turn[recipe].insert(None)
                self.recipe_processor_turn[recipe].insert(device_name)
            else:
                self.add_processor_to_recipe(recipe, device_name)
        if prev_info:
            removed, added = util.get_removed_added(prev_info.active_recipe, active_recipe)
            for remove_item in removed:
                self.remove_processor_from_recipe(remove_item, device_name)
        # if info.spec_score < self.spec_score:
        #     self.am_i_lowest = False

        # my_info = ProcessorInfo(self.spec_score, self.active_recipe, self.active_score, None)
        logging.info('ORCHESTRATOR-PROCESSOR: new:{0} active:{1} score:{2} prev:{3}'.format(device_name, active_recipe,spec_score, prev_score))
        if not equal:
            print('{0}:{1}'.format(device_name, active_recipe))
            self.compute()
            # prev_requirement = self.latest_requirement.copy()
            # required_recipe_list, latest_requirement, assigned_recipe = self._update_latest_requirement()
            # removed, added = util.get_removed_added(prev_requirement, latest_requirement)
            # if len(removed) > 0 or len(added) > 0:
            #     self.compute(required_recipe_list=required_recipe_list, requirement=latest_requirement, assigned_recipe=assigned_recipe)


        # self.syncdb.insert_or_update([device_name, spec_score, active_recipe, active_score])
        # not pulling anything
        return common_pb2.ResponseMsg(success=False, msg="")


    def lay_off_processor(self, device_name):
        if device_name in self.processor_info:
            info = self.processor_info[device_name]
            for recipe in info.active_recipe:
                self.lay_off_from_recipe(recipe, device_name)

    def am_i_really_lowest(self):
        for _, info in self.processor_info.items():
            if info.spec_score < self.spec_score:
                self.am_i_lowest = False # someone is lower
                return False
        return True

    def remove_processor_from_recipe(self, recipe, device_name):
        success = self.recipe_processor_turn[recipe].remove(device_name)
        logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: {0} deleted from {1} - {2}'.format(device_name, recipe, success))
        return success

    def add_processor_to_recipe(self, recipe, device_name):
        success = self.recipe_processor_turn[recipe].insert(device_name)
        logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: {0} added to {1} - {2}'.format(device_name, recipe,success))
        return success

    def lay_off_from_recipe(self, recipe, device_name):
        self.recipe_processor_turn[recipe].move_to_lowest(device_name)
        logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: {0} laid off from {1}'.format(device_name, recipe))

    def offload_report(self, recipe, device_name, success):
        if success:
            self.recipe_processor_turn[recipe].success_report(device_name)
        else:
            self.recipe_processor_turn[recipe].fail_report(device_name)
        logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: {0} report for {1} - {2}'.format(device_name, recipe, success))

    def advertise_processor(self):
        if len(self.active_recipe) == 0:
            print('no active recipe')
            return ""
        obj = {}
        obj['name'] = NODE_NAME
        obj['type'] = 'processor'
        obj['spec'] = self.spec_score
        obj['namelist'] = self.active_recipe
        obj['score'] = self.active_score
        adv_str = json.dumps(obj)
        return adv_str

    def better(self, recipe_name, function_name):
        if function_name in self.learn_component.worker_map.keys():
            predictor = self.learn_component.worker_map[function_name]
            better = not predictor._busy()
            return better
        return False


    def offload_to_other(self, recipe_name, function_name, input_arr, casei, pre_output_obj, start):
        if self._potential_degree(recipe_name) == 1:
            return False
        chunklist, metadata = self.offload_chunklist_and_metadata(recipe_name, function_name, input_arr, casei, pre_output_obj, start)

        turn_success, device_name = self.recipe_processor_turn[recipe_name].get_and_update_turn()

        if device_name:
            request_iterator = util.gen_large_msg(chunklist)
            success = self.try_offload(recipe_name, device_name, request_iterator, metadata)
        else:
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: own turn func:{0}'.format(function_name))
            return False

        selected_devices = []
        while not success:
            selected_devices.append(device_name)
            turn_success, device_name = self.recipe_processor_turn[recipe_name].get_and_update_turn(skiplist=selected_devices)
            if not turn_success:
                logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: no choice for {0}'.format(recipe_name))
                break
            else:
                if not device_name:
                    logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: own turn func:{0}'.format(function_name))
                    return False
                else:
                    request_iterator = util.gen_large_msg(chunklist)
                    success = self.try_offload(recipe_name, device_name, request_iterator, metadata)

        if not success:
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: giveup on func:{0}'.format(function_name))
            return False
        return True

    def offload_chunklist_and_metadata(self, recipe_name, function_name, input_arr, casei, pre_output_obj, start):
        offload_obj = {'case': casei, "pre": pre_output_obj, "arr": input_arr,"start": start}
        metadata = [('recipe', recipe_name), ('function', function_name)]
        _, chunklist,_ = util.chunk(json.dumps(offload_obj), hash=False)
        return chunklist, metadata

    def try_offload(self, recipe_name, device_name, request_iterator, metadata):
        logging.info('ORCHESTRATOR-OFFLOAD-CALLER: try:{0}'.format(device_name))
        if device_name not in self.processor_info:
            self.remove_processor_from_recipe(recipe_name, device_name)
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: {0} no info'.format(device_name))
            return False
        ip = self.processor_info[device_name].ip
        connect, response = util.call_other_postman(ip, 'Offload', request_iterator, metadata=metadata)
        if not connect:
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: {0} not connected'.format(device_name))
            self.lay_off_processor(device_name)
            return False
        else:
            self.offload_report(recipe_name, device_name, response.success)
            if not response.success:
                return False
            return True

    ################# PARTITIONING ############

    def on_demand_offload(self, recipe_name, function_name,input_arr, casei, pre_output_obj, start):
        start_time = util.current_timestamp()
        result = self.offload_to_other(recipe_name, function_name, input_arr, casei, pre_output_obj, start)
        forward_cost = util.current_timestamp() - start_time
        self.forward_mean.new_record(forward_cost)
        return result

    def update_forwarding_cost(self):
        current_mean = self.forward_mean.mean()
        if current_mean > 0:
            self.FORWARD_COST = current_mean
        else:
            self.FORWARD_COST = DEFAULT_FORWARD_COST


    def always_offload(self, recipe_name, function_name,input_arr, casei, pre_output_obj, start):
        if self._potential_degree(recipe_name) == 1:
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: recipe:{0} no choices'.format(recipe_name))
            return False
        chunklist, metadata = self.offload_chunklist_and_metadata(recipe_name, function_name, input_arr, casei, pre_output_obj, start)

        turn_success, device_name = self.recipe_processor_turn[recipe_name].get_and_update_turn()
        request_iterator = util.gen_large_msg(chunklist)
        if device_name:
            success = self.try_offload(recipe_name, device_name, request_iterator, metadata)
            return success
        else:
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLER: own turn func:{0}'.format(function_name))
            return False

    ##########################################

    def offload(self, recipe_name, function_name, iterator_request):
        if recipe_name not in self.active_recipe or function_name not in self.learn_component.worker_map:
            logging.warning('ORCHESTRATOR-OFFLOAD-CALLEE: recipe not active')
            return False
        if PARTITIONER == 'on_demand' and not self.better(recipe_name, function_name):
            return False
        myagent = self.processor._agent(recipe_name)
        predictor = self.learn_component.worker_map[function_name]
        offload_content = util.read_large_msg(iterator_request)
        myagent.offload(predictor, offload_content)
        return True

############# END PROCESSOR INFO HANDLER ####################
