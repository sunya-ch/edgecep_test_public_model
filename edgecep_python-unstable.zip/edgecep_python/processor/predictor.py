from common.util import util
from common.pubsub import PubSubProtocol
import numpy as np
import tensorflow as tf
import tensorflow_hub as hub

from io import BytesIO
import numpy as np
from PIL import Image

import threading
import time
import ctypes
import math
import json

from common.component import Learn, Function

import logging

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

import os.path
import os

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

STRICT_PERIOD = int(os.environ['STRICT_PERIOD'])

class Sampler(threading.Thread):
    def __init__(self, name, sampling_time):
        threading.Thread.__init__(self)
        self.last_input = None
        self.name = name
        self.sampling_time = sampling_time
        self.LABELER_pubsub = PubSubProtocol('TrainData', self.name, svc='LABELER')
        self.PRETRAINER_pubsub = PubSubProtocol('TrainData', self.name, svc='PRETRAINER')

    def update_input(self, input_arr):
        self.last_input = input_arr

    def run(self):
        try:
            while True:
                if self.last_input != None:
                    msg = json.dumps(self.last_input)
                    hash = util.compute_hash(msg)
                    content = {'data': self.last_input, 'id': NODE_NAME, 'hash': hash}
                    logging.info('SAMPLER-{0}-SEND: hash:{1}'.format(self.name, hash))
                    if not self.LABELER_pubsub.is_empty() and not self.PRETRAINER_pubsub.is_empty():
                        # both subscribers must exist
                        # send to pretrainer first to keep the hash
                        self.PRETRAINER_pubsub.send_to_subscriber(content)
                        self.LABELER_pubsub.send_to_subscriber(content)
                    self.last_input = None
                time.sleep(self.sampling_time)
        finally:
            logging.warning('SAMPLER-{0}-SEND: stop'.format(self.name))

    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)


class Predictor(threading.Thread):

    def __init__(self, function_key):
        threading.Thread.__init__(self)
        self.ready = False
        self.model_file_name = util._tflite_path(function_key)
        self.function = Function(util.get_function().hgetall(function_key))
        if self.function.learn != None:
            self.sampler = Sampler(self.function.name, self.function.learn.sampling_time)
            self.sampler.start()
        else:
            self.sampler = None
        self.input_data = Queue()
        self.start_time = util.current_timestamp()
        # self.arrival_num = 0
        # self.total_delay = 0
        self.busy = False
        self.to_deactive = False
        self.computing = False
        # self.window = STRICT_PERIOD


############ for offloading decision ###############
    # def _next_timeout(self, start_time):
    #     return start_time + self.window
    #
    # def _delay(self):
    #     return self.total_delay

    def set_queue_model(self, complexity_time, model):
        self.queue_model = model
        self.acceptable_time = complexity_time[self.function.complexity]

    def refit_queue_model(self):
        self.queue_model.fit_dist()

    # def try_pop_arrival_rate(self, pop_time):
    #     # update
    #     window = pop_time  - self.start_time
    #     last_arrival_rate = self.arrival_num/window
    #     arrival_rate = last_arrival_rate
    #     total_delay = self.queue_model.total_delay(arrival_rate)
    #     # print(window, self.arrival_num)
    #     # print(arrival_rate, ' ', total_delay, ' ', self.acceptable_time)
    #     self.total_delay = total_delay
    #     self.arrival_num = 0
    #     self.start_time = pop_time
    #     self.next_timeout = self._next_timeout(pop_time)
    #
    #     logging.info('PREDICTOR-{0}: accept_delay:{1} total_delay:{2}'.format(self.function.name, self.acceptable_time, self.total_delay))
    #     if total_delay == -1 or total_delay > self.acceptable_time:
    #         self.busy = True
    #         return False
    #
    #     self.busy = False
    #     return True

    # def update_arrival_rate(self, compute_time):
    #     if self.busy or compute_time > self.next_timeout:
    #         self.try_pop_arrival_rate(compute_time)

    def _busy(self):
        return self.to_deactive or self.queue_model.busy()

    def waiting_number(self):
        return self.input_data.qsize()

    def enqueue(self, input_arr, callback, enqueue_time):
        if self.queue_model.choose():
            self.force_enqueue(input_arr, callback)
            return True
        return False


    ################# PARTITIONING ############

    def on_demand_enqueue(self, input_arr, callback, enqueue_time):
        return self.enqueue(input_arr, callback, enqueue_time)


    def always_enqueue(self, input_arr, callback, enqueue_time):
        return False

    def never_enqueue(self, input_arr, callback, enqueue_time):
        self.force_enqueue(input_arr, callback)
        return True

    ##########################################

    def force_enqueue(self, input_arr, callback):
        self.input_data.put((input_arr, callback))
        self.queue_model.arrive()


###########################################################################
    def run(self):
        try:
            while True:
                (input_arr, callback) = self.input_data.get(block=True)
                self.computing = True
                process_start = util.current_timestamp()
                model_path = self._model_path()
                interpreter = tf.lite.Interpreter(model_path=model_path)
                interpreter.allocate_tensors()
                input_details = interpreter.get_input_details()
                output_details = interpreter.get_output_details()

                for i in range(0, len(self.function.input_name)):
                    data = input_arr[i][0]
                    input = self.preprocessing(data, input_details)
                    # logging.info('input: {0} ({1})'.format(input, type(input)))
                    interpreter.set_tensor(input_details[i]['index'], input)
                interpreter.invoke()
                output_data = interpreter.get_tensor(output_details[i]['index'])[0]
                output_arr = [None] * len(self.function.output_name)
                for i in range(0, len(self.function.output_name)):
                    output_arr[i] = getattr(self, self.function.output_name[i])(output_data)
                callback(output_arr, process_start)
                self.queue_model.depart(util.current_timestamp()-process_start)
                self.computing = False
                if self.to_deactive:
                    self._deactive()
                    break
        finally:
            logging.info('PREDICTOR-{0}: stop'.format(self.function.name))


    def _model_path(self):
        if os.path.islink(self.model_file_name):
            return os.readlink(self.model_file_name)
        return self.model_file_name

############### output ##############################
    def label(self, output_data):
        max_index = np.argmax(output_data)
        return self.function.labels[max_index]


    def confidence(self, output_data):
        out_confidence = {}
        index = 0
        for label in self.function.labels:
            out_confidence[label] = float(output_data[index])
            index += 1
        return out_confidence

    def data(self, output_data):
        return output_data.tolist()
############################################################

    def preprocessing(self, data, input_details):
        input_height = input_details[0]['shape'][1]
        input_width = input_details[0]['shape'][2]
        input_depth = input_details[0]['shape'][3]

        arr = np.asarray(data, dtype=np.uint8)
        img = Image.fromarray(arr)
        with BytesIO() as output:
            img.save(output, 'jpeg')
            image_data = output.getvalue()

        jpeg_data_tensor = tf.constant(image_data)
        decoded_image = tf.image.decode_jpeg(jpeg_data_tensor, channels=input_depth)
        decoded_image_as_float = tf.image.convert_image_dtype(decoded_image,
                                                            tf.float32)
        decoded_image_4d = tf.expand_dims(decoded_image_as_float, 0)
        resize_shape = tf.stack([input_height, input_width])
        resize_shape_as_int = tf.cast(resize_shape, dtype=tf.int32)
        decoded_image_tensor = tf.image.resize_bilinear(decoded_image_4d,
                                               resize_shape_as_int)

        with tf.Session() as sess:
            sess.run(decoded_image_tensor)
            value = decoded_image_tensor.eval()
        return value


    def is_ready(self):
        return os.path.exists(self.model_file_name)

    def update_input(self, input_arr):
        if self.sampler is not None:
            self.sampler.update_input(input_arr)

    def subscribe(self, interface_name, ip, id, svc):
        if self.sampler is not None:
            pubsub = getattr(self.sampler, "{0}_pubsub".format(svc))
            pubsub.subscribe(interface_name, ip, id)

    def unsubscribe_from_id(self, id, svc):
        if self.sampler is not None:
            pubsub = getattr(self.sampler, "{0}_pubsub".format(svc))
            pubsub.unsubscribe_from_id(id)

    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        if self.sampler is not None:
            self.sampler.deactive()
        self.to_deactive = True
        if not self.computing and self.input_data.qsize() == 0:
            self._deactive()

    def _deactive(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)
        self._remove_module()

    def _agent(self, recipe_name):
        if recipe_name not in self.recipe_agent.keys():
            return None
        return self.recipe_agent[recipe_name]

    def _remove_module(self):
        model_path = self._model_path()
        if os.path.exists(model_path):
            stat_path= util._model_stat_path(self.function.name)
            os.remove(model_path)
            os.remove(stat_path)

class PredictorLearn(Learn):
    def __init__(self, reserved_memory, create_function, weight_of_existance, default_size=1000):
        self.weight_of_existance = weight_of_existance
        self.default_size = default_size
        self.forced_list = None
        super(PredictorLearn, self).__init__(reserved_memory, create_function)

    def _update_worker_map(self, replaced_function=None):
        replaced = []
        if replaced_function is not None and replaced_function in self.worker_map.keys():
            self._create(replaced_function)
            replaced = [replaced_function]
        return [], [], replaced

    def _update_worker_map_from_list(self, function_list):
        removed, added = util.get_removed_added(self.worker_map.keys(), function_list)
        for added_function in added:
            self._create(added_function)
        for removed_function in removed:
            self._remove(removed_function)
        return

    def set_queue_model(self, accept_time, queue_model):
        if len(accept_time) > 0:
            for function in self.worker_map.keys():
                queue = queue_model[function]
                self.worker_map[function].set_queue_model(accept_time, queue)
                print('func: {0} queue depart: {1} max arrival: {2}'.format(function, queue.departure_rate, queue.max_arrival))
                logging.info('PREDICTOR-QUEUE-APPLY: function:{0} departure_rate: {1} max_arrival: {2}'.format(function, queue.departure_rate, queue.max_arrival))

    def refit_queue_model(self):
        for function in self.worker_map.keys():
            self.worker_map[function].refit_queue_model()

    @staticmethod
    def get_function_size(function_name):
        try:
            if function_name in util.get_adv():
                module_size = int(util.get_adv().hget(function_name, 'size'))
            else:
                module_size = int(util.get_function().hget(function_name, 'meta-data.module_size'))
        except:
            logging.warning("PREDICTLEARN: module size is not set for function {0}".format(selected[0]))
            module_size = self.default_size
        return module_size


    def _remove(self, function_key): #override
        self.worker_map[function_key].deactive()
        del self.worker_map[function_key]
