import sys
sys.path.append(".")
import environ_set
import grpc
from concurrent import futures
import time
import os
import json

from google.protobuf import empty_pb2

from protoc_py import processor_pb2
from protoc_py import processor_pb2_grpc

from protoc_py import common_pb2

from common.util import util
from common.component import Event

from agent import Agent
from orchestrator import Orchestrator
from predictor import PredictorLearn, Predictor

from PIL import Image

from itertools import tee

import numpy as np

import logging
import absl.logging
logging.root.removeHandler(absl.logging._absl_handler)
absl.logging._warn_preinit_stderr = False

logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

PROCESSOR_PORT = os.environ['PROCESSOR_PORT']

STRICT_PERIOD = int(os.environ['STRICT_PERIOD'])


import threading

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty


class EventReader(threading.Thread):
    def __init__(self, recipe_agent):
        threading.Thread.__init__(self)
        self.content_queue = Queue()
        self.recipe_agent = recipe_agent

    def run(self):
        while True:
            (content, recipe_case_id_list) = self.content_queue.get(block=True)
            try:
                obj = json.loads(content)
            except:
                print('fail to read event')
                continue

            descriptor = obj['descriptor']
            event_obj = obj['eventobj']
            name, location, origin, timestamp = util.get_descriptor_detail(descriptor)
            attribs = event_obj['attribs']
            event = Event(name=name,
                          location=location,
                          attribs=attribs,
                          timestamp=timestamp,
                          origin=origin
                          )
            logging.info('PROCESSOR-EVENTIN: recipe_caseid:{0}'.format(recipe_case_id_list))
            for recipe_name, case_id_list in recipe_case_id_list.items():
                if recipe_name in self.recipe_agent:
                    self.recipe_agent[recipe_name].event_in(event=event,
                                                            case_id_list=case_id_list)
                    # sender = util._device_name(context)
                    # if sender == event.origin:
                    #     util.increase_token('ORIGIN', recipe_name, sender)
                    #     if sender == NODE_NAME:
                    #         util.increase_token('RECV', recipe_name, sender)
                    # else:
                    #     util.increase_token('RECV', recipe_name, sender)

    def new_content(self, content):
        self.content_queue.put(content)

class InterProcessor(processor_pb2_grpc.InterProcessorServicer):
    def __init__(self):
        self.orchestrator = Orchestrator(self)
        self.recipe_agent = {}
        self.orchestrator.start()
        self.reader = EventReader(self.recipe_agent)
        self.reader.start()

    def Exists(self, request, context):
        return empty_pb2.Empty()

    def EventIn(self, request_iterator, context):
        content = util.read_large_msg(request_iterator)
        context_dict, _ =util._context_dict(context)
        case_id = json.loads(context_dict['caseid'])
        unprocessed_recipes = [x for x in case_id.keys() if x not in self.recipe_agent]
        success = len(unprocessed_recipes) == 0
        msg = "" if success else json.dumps(unprocessed_recipes)
        self.reader.new_content((content, case_id))
        return common_pb2.ResponseMsg(success=success, msg=msg)

    def SynchronizeAdd(self, request, context):
        api = request.api.lower()
        key = request.key
        if api == 'function':
            removed, added, replaced = self.orchestrator.learn_component.SynchronizeAdd(request, context)
            self.orchestrator._update_module_files(removed, added, replaced)
        call_function = getattr(self.orchestrator, "interrupt_by_{0}".format(api))
        call_function(added=key)
        return empty_pb2.Empty()

    def SynchronizeRevoke(self, request, context):
        api = request.api.lower()
        key = request.key
        if api == 'function':
            removed, added, replaced = self.orchestrator.learn_component.SynchronizeRevoke(request, context)
            self.orchestrator._update_module_files(removed, added, replaced)
        call_function = getattr(self.orchestrator, "interrupt_by_{0}".format(api))
        call_function(removed=key)
        return empty_pb2.Empty()

    def Probe(self, request, context):
        adv_str = self.orchestrator.advertise_processor()
        return common_pb2.ResponseMsg(success= (adv_str != ""), msg=adv_str)

    def AdvIn(self, request, context):
        new_adv = json.loads(request.adv_str)
        method = "_handle_adv_{0}".format(new_adv["type"])
        new_adv["ip"] = request.ip
        new_adv["interface"] = request.interface
        return getattr(self.orchestrator, method)(new_adv)

    def Subscribe(self, request, context):
        namelist = json.loads(request.name)
        interface_name = request.interface
        ip = request.ip
        id = request.id
        svc = request.svc
        logging.info('PROCESSOR-PUBSUB: svc:{0} sub:{1} for:{2}'.format(svc, id, namelist))
        if svc == 'ACTOR':
            self._subscribe(namelist, self.recipe_agent, interface_name, ip, id, svc)
        else:
            self._subscribe(namelist, self.orchestrator.learn_component.worker_map, interface_name, ip, id, svc)
        return empty_pb2.Empty()


    def Unsubscribe(self, request, context):
        name = json.loads(request.name)
        id = request.id
        svc = request.svc
        if svc == 'ACTOR':
            self._unsubscribe(name, self.recipe_agent, id, svc)
        else:
            self._unsubscribe(namelist, self.orchestrator.learn_component.worker_map, id, svc)
        return empty_pb2.Empty()

    def Offload(self, request_iterator, context):
        context_dict, _ = util._context_dict(context)
        recipe_name = context_dict["recipe"]
        function_name = context_dict["function"]
        success = self.orchestrator.offload(recipe_name, function_name, request_iterator)
        return common_pb2.ResponseMsg(success=success, msg="")

    def _agent(self, recipe_name):
        return self.recipe_agent[recipe_name]

    def renew_agent(self, key, recipe): # called by orchestrator
        if key in self.recipe_agent.keys():
            self.deactive(key)
        agent = Agent(recipe, self.orchestrator.recipe_empty_record[key], self)
        self.recipe_agent[key] = agent
        agent.start()

    def apply(self, selected_recipe, recipe_dict):
        removed_recipe, added_recipe = util.get_removed_added(self.recipe_agent.keys(), selected_recipe)
        for recipe in removed_recipe:
            self.deactive(recipe)
        for recipe in added_recipe:
            self.active(recipe, recipe_dict[recipe])

    def active(self, key, recipe):
        if key in self.recipe_agent.keys():
            return False
        agent = Agent(recipe, self.orchestrator.recipe_empty_record[key], self)
        self.recipe_agent[key] = agent
        agent.start()


    def deactive(self, key):
        if key in self.recipe_agent.keys():
            self.recipe_agent[key].deactive()
            self.orchestrator.recipe_empty_record[key]._clear()
            del self.recipe_agent[key]
        return False

    def _subscribe(self, namelist, callee_map, interface_name, ip, id, svc):
        for name in namelist:
            try:
                callee_map[name].subscribe(interface_name, ip, id, svc)
                logging.info('PROCESSOR-SUB: key:{0} svc:{1} id:{2}'.format(name, svc, id))
            except KeyError:
                continue

    def _unsubscribe(self, name, callee_map, id, svc):
        try:
            callee_map[name].unsubscribe_from_id(id, svc)
            logging.info('PROCESSOR-UNSUB: key:{0} svc:{1} id:{2}'.format(name, svc, id))
        except:
            pass

def grpc_start():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    processor_pb2_grpc.add_InterProcessorServicer_to_server(InterProcessor(), server)
    server.add_insecure_port('localhost:{0}'.format(PROCESSOR_PORT))
    server.start()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        SERVICE = 'PROCESSOR'
        print('start {0} grpc server'.format(SERVICE))
        util.notify_postman(SERVICE)
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except:
        server.stop(0)
        util.notify_postman(SERVICE, active=False)

if __name__ == "__main__":
    while not util.redis_available():
        continue
    grpc_start()
