from common.syncdb import SynchronizedDB
from common.util import util
import pandas as pd
REQUIRED_FIELD = ['origin', 'location', 'timestamp']
import logging
import json

################################################################################
### Benchmark reference: https://github.com/box/ClusterRunner/issues/400
###
###

class DBMS(object):
    def __init__(self, recipe):
        self.case_input_manager = []
        self.case_sequence_manager = []
        for i in range(0, len(recipe.cases)):
            content = recipe.cases[i].content
            self.case_input_manager.append(InputManager(recipe.name, i, content.input, content.group, content.consume))
            self.case_sequence_manager.append(SequenceManager(recipe.name, i, content.sequence, content.group))

    def event_in(self, event, case_id_list):
        for item in case_id_list:
            casei, id = util._case_id_from_str(item)
            is_input = id[0] == 'i'
            if is_input:
                seq_manager = self.case_sequence_manager[casei]
                group_str = _group_str(event, seq_manager.group)
                ready = seq_manager.is_ready(group_str)
                if ready:
                    self.case_input_manager[casei].event_in(event, id[1:], group_str)
            else:
                self.case_sequence_manager[casei].event_in(event, id[1:], group_str)

    def get_input(self, casei):
        return self.case_input_manager[casei].select_inputs()

    def drop(self):
        for manager in self.case_input_manager:
            manager.drop()

        for manager in self.case_sequence_manager:
            manager.drop()

class InputManager():
    def __init__(self, recipe_name,caseid, input, group, consume):
        self.input = input
        self.consume = consume
        self.group = group
        self.name = "{0}_{1}".format(recipe_name, caseid)
        self.dbmap = self._init_db(recipe_name, caseid, input, consume)

    def _init_db(self, recipe_name, caseid, input, group):
        dbmap = {}
        need_wait = len(input) > 1
        for id, input in input.items():
            consume = False if self.consume is None else id in self.consume

            ref_recipe_name = input.identifier['event']
            ref_recipe_value = util.get_recipe().hgetall(ref_recipe_name)
            assert not not ref_recipe_value, "recipe not exists: {0}".format(ref_recipe_name)
            ref_attr_dict = json.loads(ref_recipe_value['attribute'])[0]

            if input.column is None:
                column = ref_attr_dict.keys()
            else:
                column = input.column + self._fill_required_field(input.column)
            type_list = [ref_attr_dict[col] for col in column]

            if self._is_now(input.select):
                dbmap[id] = NoSQL_DB(recipe_name, caseid, id, column,  type_list, consume=consume, group=self.group)
            else:
                dbmap[id] = RelationalDB(recipe_name, caseid, id, column, type_list, self.group, input.limit, input.select, input.sort, consume, need_wait)
        return dbmap

    def _fill_required_field(self, column):
        append_list = [field for field in REQUIRED_FIELD if field not in column]
        return append_list

    def _is_now(self, select):
        return select is None \
               or select["value"] == 1

    def event_in(self, event, input_name, group_str):
        try:
            success = self.dbmap[input_name].insert(event, group_str)
        except:
            logging.warning('DBMS-{0}: not available to insert'.format(self.name))
            return False
        return success

    def select_inputs(self):
        try:
            all_ready = None
            for input_name, db in self.dbmap.items():
                all_ready = db.ready if all_ready is None \
                                    else [x for x in all_ready if x in db.ready]
            result_dict = {}
            for group_str in all_ready:
                input_data = self._select_inputs(group_str)
                if input_data is not None:
                    result_dict[group_str] = input_data
            # {groupstr: input_data}
        except:
            logging.warning('DBMS-{0}: not available to select'.format(self.name))
            return {}
        return result_dict

    def _select_inputs(self, group_str):
        input_data = {}
        for input_name, db in self.dbmap.items():
            db.clean()
            data = db.select(group_str)
            if data is None:
                return None
            input_data[input_name] = data
        for _, db in self.dbmap.items():
            db._consume(group_str, data=data)
        return input_data

    def drop(self):
        for _, db in self.dbmap.items():
            db.drop()


class SequenceManager():
    def __init__(self, recipe_name, caseid, sequence, group):
        self.ready = []
        self.dbarr = []
        self.sequence = sequence
        self.no_sequence = len(self.sequence) == 0
        self.group = group
        self.name =  "{0}_{1}".format(recipe_name, caseid)
        self._init_db(recipe_name, caseid, sequence, group)

    def event_in(self, event, i_str, group_str):
        try:
            i = int(i_str)
            for prev in range(0,i):
                if not self.dbarr[prev].is_ready(group_str):
                    return None
            if i > 0:
                # check within condition
                acceptable = util.current_timestamp() - self.sequence[i-1].within
                if self.dbarr[i-1].get_time(group_str) < acceptable:
                    self.clear(group_str)
                    return None
            self.dbarr[i].insert(event, group_str)

        except:
            logging.warning('DBMS-{0}: not available to insert'.format(self.name))
            return {}

    def is_ready(self, group_str):
        if self.no_sequence:
            return True
        ready = self.dbarr[len(self.dbarr)-1].is_ready(group_str)
        timeout = self.dbarr[i-1].get_time(group_str) + self.sequence[i].within
        if util.current_timestamp() > timeout:
            self.clear(group_str)
            return False
        return True



    def _init_db(self, recipe_name, caseid, sequence, group):
        dbarr = []
        for i in range(0, len(self.sequence)):
            seq = self.sequence[i]
            ref_recipe_name = seq.identfier['event']
            assert ref_recipe_name not in util.get_recipe().keys(), "{0} recipe not exists".format(ref_recipe_name)
            ref_attr_dict = util.get_recipe().hget(ref_recipe_name, 'attribute')[0]
            dbarr.append(NoSQL_DB(recipe_name, caseid, i, ref_attr_dict, group=group))
        return dbarr

    def clear(self, group_str=""):
        for db in self.dbarr:
            db._consume(group_str)

    def drop(self):
        for db in self.dbarr:
            db.drop()

class RelationalDB(object):
    limit_TYPE = ['time', 'number']
    limit_CLEAN_FUNCTION = ['delete_outdate', 'delete_N_from']

    # select_TYPE = ['time', 'number']
    # select_EXIST_FUNCTION = ['try_select_from_time', 'try_select_from_N']
    # select_GET_FUNCTION = ['select_from_time', 'select_from_N']

    def __init__(self, recipe_name, caseid, id, column, type_list, group=None, limit=None, select=None, sort=None, consume=True, need_wait=False):
        self.recipe_name = recipe_name # dbname
        self.name = "_".join([recipe_name, str(caseid), str(id)]) # tablename
        self.column = column
        self.type_list = type_list

        key_index_list = [self.column.index(x) for x in REQUIRED_FIELD]
        self.db = SynchronizedDB(self.recipe_name, self.name, self.column, self.type_list, key_index_list, replace=True)
        if limit is not None:
            limit_index = RelationalDB.limit_TYPE.index(limit["type"])
            self.clean_function = getattr(self.db, RelationalDB.limit_CLEAN_FUNCTION[limit_index])
            self.limit_from_head = True if "from" not in limit.keys() else limit["from"] == 'head'
            self.limit_value = limit["value"]
        assert select is not None, "select never be done in relational DB"
        self.select_from_head = True if "from" not in select.keys() else select["from"] == 'head'
        self.select_value = -1 if "value" not in select.keys() else select["value"]
        self.group = group #arr of cols
        self.need_wait = need_wait
        self.consume = True if limit is None else consume
        self.limit = limit
        self.sort = sort
        if self.consume:
            self.last_selected_id = []
        if self.group is not None:
            self.group_index = [self.column.index(col) for col in group]
        self.ready = []
        self.clean()



    def insert(self, event, group_str):
        self.db.insert(self._get_value_from_event(event))
        if group_str not in self.ready:
            if self.need_wait:
                ready = self._try_select(self, group_str)
                if ready:
                    self.ready.append(group_str)
            else:
                self.ready.append(group_str)

    def is_ready(self, group_str=""):
        return group_str in self.ready

    def _try_select(self, group_str=""):
        return self.db.try_select_from_N(self.select_value, self.group_index, group_str)

    def clean(self):
        if self.limit is None:
            return None
        self.clean_function(self.limit_value, self.limit_from_head, self.group_index, self.group, self.sort)

    def select(self, group_str=""):
        success, results = self.db.select_from_N(self.select_value, self.select_from_head, self.group_index, group_str, self.sort)
        if success and len(results) > 0:
            tried_results = util.try_json_loads(results, self.type_list, rowindex=True)
            return pd.DataFrame(tried_results, columns=['rowid']+self.column)
        else:
            self.ready.remove(group_str)
            return None

    def _consume(self, group_str, data=None):
        if data is not None:
            rowids = data['rowid']
            if not self.consume:
                return None
            self.db.consume_rows(rowids)
        else:
            self.db.consume_group(self.group_index, group_str)

    def _get_value_from_event(self, event):
        return [event.attribute(column) for column in self.column]

    def drop(self):
        self.db._drop_table()

class NoSQL_DB(object):
    def __init__(self, recipe_name, caseid, id, column, type_list, consume=True, group=None):
        self.group = group
        self.name = "_".join([recipe_name, str(caseid), str(id)])
        self.consume = consume
        self.ready = []
        self.column = column
        self.type_list = type_list


    def insert(self, event, group_str):
        values = self._get_value_from_event(event)
        util.get_input_cache().hmset(self._name(group_str), values)
        if group_str not in self.ready:
            self.ready.append(group_str)

    def is_ready(self, group_str=""):
        return group_str in self.ready

    def select(self, group_str=""):
        output = util.get_input_cache().hgetall(self._name(group_str))
        result = []
        index = 0
        for col in self.column:
            value = output[col]
            type = self.type_list[index]
            if type == 'real':
                value = float(value)
            elif type == 'integer':
                value = int(value)
            index += 1
            result.append(value)
        tried_results = util.try_json_loads([result], self.type_list)
        return pd.DataFrame(tried_results, columns=self.column)

    def get_time(self, group_str=""):
        return util.get_input_cache().hget(self._name(group_str), 'timestamp')

    def _consume(self, group_str, data=None):
        if self.consume and self.is_ready(group_str):
            util.get_input_cache().delete(self._name(group_str))
            self.ready.remove(group_str)

    def clean(self):
        pass # no limit

    def _get_value_from_event(self, event):
        values = {}
        for col in self.column:
            values[col] = util._value_dumps(event.attribute(col))
        return values


    def _name(self, group_str=""):
        return "{0}{1}".format(self.name, group_str)

    def drop(self):
        for group_str in self.ready:
            util.get_input_cache().delete(self._name(group_str))

def _group_str(event, group):
    if group is None:
        return ""
    values = [str(event.attribute(col)) for col in group]
    return "_"+_group_str_from_values(values)

def _group_str_from_values(values):
    return "_".join(values)
