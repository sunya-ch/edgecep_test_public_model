import sys
sys.path.append(".")
from common.rrb_list import PrioritizedRoundRobin
import threading
import time


def rrb_better_func(main_name, cmp_name):
    return True

def rrb_min_level_func(cmp_name):
    return 0


rrb = PrioritizedRoundRobin(better_func=rrb_better_func, min_level_func=rrb_min_level_func)

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

class Tester(threading.Thread):
    def __init__(self, name, rrb):
        threading.Thread.__init__(self)
        self.rrb = rrb
        self.commands = Queue()
        self.name = name

    def new_command(self, func, value):
        self.commands.put((func, value))

    def run(self):
        try:
            while True:
                (func, value) = self.commands.get(block=True)
                #print('{0}: call {1} with {2}'.format(self.name, func, value))
                if value:
                    out = getattr(self.rrb, func)(value)
                else:
                    out = getattr(self.rrb, func)()
                if out:
                    print(out)
        finally:
            print(self.name, ' end')

if __name__ == '__main__':
    insert_tester = Tester('insert', rrb)
    get_tester = Tester('get', rrb)
    move_tester = Tester('move', rrb)
    remove_tester = Tester('remove', rrb)
    insert_tester.start()
    get_tester.start()
    move_tester.start()
    remove_tester.start()
    insert_tester.new_command('insert', 'item1')
    insert_tester.new_command('insert', 'item2')
    insert_tester.new_command('insert', 'item3')
    insert_tester.new_command('insert', 'item4')
    # insert_tester.new_command('move_to_lowest', 'item3')
    insert_tester.new_command('fail_report', 'item4')
    selected_devices = ['item1','item2', 'item3','item4']
    insert_tester.new_command('get_and_update_turn',selected_devices)
