from common.util import util

import json

import logging

import os
NODE_NAME = os.environ['BALENA_DEVICE_UUID']

class PubSubProtocol(object):
    def __init__(self, method_name, key, svc='ACTOR'):
        self.subscriber = []
        self.method_name = method_name
        self.metadata = [('svc', svc), ('key', key)]

    def is_empty(self):
        return not self.subscriber

    def subscribe(self, interface_name, ip, id):
        subscriber = self._subscriber(interface_name, ip, id)
        if subscriber not in self.subscriber:
            self.subscriber.append(subscriber)

    def unsubscribe_from_id(self, id):
        for subscriber in self.subscribers:
            if id in subscriber:
                self.unsubscribe_from_key(subscriber)

    def unsubscribe_from_key(self, key):
        try:
            self.subscriber.remove(key)
        except ValueError:
            # do not exists
            pass

    def _subscriber(self, interface_name, ip, id):
        return "{0}_{1}_{2}".format(interface_name, ip, id)

    def _detail(self, key):
        return key.split("_")


    def send_to_subscriber(self, content, callback=None, args=None):
        response_success = []
        _, chunklist,_ = util.chunk(json.dumps(content), hash=False)
        logging.info('PUBSUB-SEND: subscribers:{0}'.format(self.subscriber))
        sent_id = []
        for subscriber in self.subscriber:
            connected = True
            interface, ip, id = self._detail(subscriber)
            if id in sent_id:
                continue
            request_iterator = util.gen_large_msg(chunklist)
            if id == NODE_NAME:
                response = util.call_postman(self.method_name, request_iterator, metadata=self.metadata)
            else:
                connected, response = util.call_other_postman(ip, self.method_name, request_iterator, metadata=self.metadata)
                if not connected:
                    try:
                        ip = util.get_direct_cache().hget(id, 'ip')
                        connected, response = util.call_other_postman(ip, self.method_name, request_iterator, metadata=self.metadata)
                        self.change_ip(subscriber, interface, ip, id)
                    except:
                        connected = False

            if connected:
                final_success = response.success
                if not final_success:
                    logging.warning('PUBSUB-SEND: {0} not success, unsub'.format(subscriber))
                    self.unsubscribe_from_key(subscriber)
                elif callback is not None:
                    # successfully sent
                    sent_id.append(id)
                    callback(args)
            else:
                logging.warning('PUBSUB-SEND: {0} not connected, unsub'.format(subscriber))
                self.unsubscribe_from_key(subscriber)

    def change_ip(self, subscriber, interface, new_ip, id):
        index = self.subscriber.index(subscriber)
        self.subscriber[index] = self._subscriber(interface, new_ip, id)
