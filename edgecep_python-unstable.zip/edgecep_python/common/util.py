import redis
import json
import datetime

import grpc

try:
  basestring
except NameError:
  basestring = str

from protoc_py import postman_pb2
from protoc_py import postman_pb2_grpc
from protoc_py import common_pb2

import hashlib

import os
from os import listdir
from os.path import isfile, join


import logging
logging.getLogger().setLevel(logging.INFO)

import sys

PLATFORM = ['darwin', 'linux']

if sys.platform in PLATFORM:
    TIME_FUNCTION = ['gdate -u +%s.%9N', 'date -u +%s.%9N']
    TIME_FUNCTION = TIME_FUNCTION[PLATFORM.index(sys.platform)]
else:
    TIME_FUNCTION = None

REDIS_HOST = "redis_db"

DIRECT_INFO_DB = int(os.environ['DIRECT_INFO_DB'])
INDIRECT_INFO_DB = int(os.environ['INDIRECT_INFO_DB'])
OUTDATE_DB = int(os.environ['OUTDATE_DB'])
OUTDATE_MEMO = int(os.environ['OUTDATE_MEMO'])
REDIS_PORT = int(os.environ['REDIS_PORT'])
NODE_INFO_DB = os.environ['NODE_INFO_DB']

RECIPE_DB = int(os.environ['RECIPE_DB'])
FUNCTION_DB = int(os.environ['FUNCTION_DB'])
ACTOR_DB = int(os.environ['ACTOR_DB'])
ADV_DB = int(os.environ['ADV_DB'])

TFLITE_PATH = os.environ['TFLITE_PATH']
LEARN_TFLITE_PATH = os.environ['LEARN_TFLITE_PATH']
CHECKPOINT_PATH = os.environ['CHECKPOINT_PATH']


INPUT_CACHE = int(os.environ['INPUT_CACHE'])

POSTMAN_PORT = os.environ['POSTMAN_PORT']

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

CHUNK_SIZE = 16 * 1024 # 16 KiB

class util(object):

    @staticmethod
    def _location():
        return os.environ['LOCATION']

    @staticmethod
    def _id():
        return os.environ['BALENA_DEVICE_UUID']

    @staticmethod
    def redis_available():
        r = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=DIRECT_INFO_DB, decode_responses=True)
        try:
            r.keys()  # getting None returns None or throws an exception
        except (redis.exceptions.ConnectionError,
                redis.exceptions.BusyLoadingError):
            return False
        return True

    @staticmethod
    def get_direct_cache():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=DIRECT_INFO_DB, decode_responses=True)

    @staticmethod
    def get_indirect_cache():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=INDIRECT_INFO_DB, decode_responses=True)

    @staticmethod
    def get_outdate_cache():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=OUTDATE_DB, decode_responses=True)

    @staticmethod
    def get_memo_cache():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=OUTDATE_MEMO, decode_responses=True)

    @staticmethod
    def get_node_info():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=NODE_INFO_DB, decode_responses=True)

    @staticmethod
    def get_recipe():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=RECIPE_DB, decode_responses=True)

    @staticmethod
    def get_function():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=FUNCTION_DB, decode_responses=True)

    @staticmethod
    def get_actor():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=ACTOR_DB, decode_responses=True)

    @staticmethod
    def get_adv():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=ADV_DB, decode_responses=True)


    @staticmethod
    def get_input_cache():
        return redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=INPUT_CACHE, decode_responses=True)

############## TOKEN #######################
    @staticmethod
    def increase_token(type, recipe, device_name):
        db = int(os.environ['{0}_TOKEN'.format(type)])
        r = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=db, decode_responses=True)
        prev = 0
        device_dict = r.hgetall(recipe)
        if device_name in device_dict.keys():
            prev = int(device_dict[device_name])
        device_dict[device_name] = str(prev+1)
        r.hmset(recipe, device_dict)

    @staticmethod
    def increase_N_token(type, recipe, device_name, N=1):
        db = int(os.environ['{0}_TOKEN'.format(type)])
        r = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=db, decode_responses=True)
        prev = 0
        device_dict = r.hgetall(recipe)
        if device_name in device_dict.keys():
            prev = int(device_dict[device_name])
        device_dict[device_name] = str(prev+N)
        r.hmset(recipe, device_dict)

    @staticmethod
    def pop_token(recipe):
        types = ['ORIGIN', 'FORWARD', 'RECV', 'PROCESS','ACT']
        tokens = {}
        found = False
        for type in types:
            db = int(os.environ['{0}_TOKEN'.format(type)])
            r = redis.StrictRedis(host=REDIS_HOST, port=REDIS_PORT, db=db, decode_responses=True)
            if r.exists(recipe):
                tokens[type] = r.hgetall(recipe)
                r.delete(recipe)
                found = True
        return None if not found else tokens

###########################################################
    @staticmethod
    def get_decoded_dict(dict):
        new_dict = {}
        for key, value in dict.items():
            key_str = key.decode("utf-8")
            new_dict[key_str] = value.decode("utf-8")
        return new_dict

    @staticmethod
    def is_known(name, ip, interface_name):
        direct_cache = util.get_direct_cache()
        if name in direct_cache.keys():
            return True
        memo_key = util._memo_key(name, ip, interface_name)
        memo_cache = util.get_memo_cache()
        if memo_key in memo_cache.keys():
            return True
        return False

    @staticmethod
    def _memo_key(device_name, ip, interface):
        return  "_".join([device_name,ip,interface])

    @staticmethod
    def _compute_module_value(redis_db, function_name, accuracy_key, samples_key):
        accuracy = float(redis_db.hget(function_name, accuracy_key))
        samples = int(redis_db.hget(function_name, samples_key))
        return util._compute_module_value_raw(accuracy, samples, None)

    @staticmethod
    def _compute_module_value_raw(accuracy, samples, size):
        return accuracy * samples

    @staticmethod
    def chunk(str, hash=True):
        if hash:
            hash = util.compute_hash(str)
        chunklist = []
        while len(str) > 0:
            max_cut = min(CHUNK_SIZE, len(str))
            chunklist.append(str[0: max_cut])
            str = str[max_cut:]
        return hash, chunklist, len(chunklist)

    @staticmethod
    def get_descriptor_detail(descriptor):
        name, location, origin, timestamp = descriptor.split("_")
        return name, location, origin, timestamp

    @staticmethod
    def get_descriptor_and_chunks(eventobj):
        contentobj = eventobj.get_content()
        str = json.dumps(contentobj)
        hash, chunklist, maxsize = util.chunk(str)
        descriptor = "{0}/{1}/{2}".format(eventobj.get_descriptor(), hash, maxsize)
        return descriptor, chunklist


    @staticmethod
    def current_timestamp():
        if TIME_FUNCTION:
            try:
                return float(os.popen(TIME_FUNCTION).read().strip())
            except:
                pass
        return datetime.datetime.timestamp(datetime.datetime.now(datetime.timezone.utc)) # in second


    @staticmethod
    def get_removed_added(old, new):
        removed = [x for x in old if x not in new]
        added = [x for x in new if x not in old]
        return removed, added

    # @staticmethod
    # def get_np_type_from_name(name):
    #     if name == 'uint8':
    #         return np.uint8
    #     if name == 'float32':
    #         return np.float32
    #     if name == 'int16':
    #         return np.int16


    @staticmethod # for putting to redis db
    def obj_dumps(obj, hashcode=None):
        dump_dict = {}
        for key, value in obj.items():
            if isinstance(value, dict):
                for value_key, value_value in value.items():
                    new_key = "{0}.{1}".format(key, value_key)
                    dump_dict[new_key] = util._value_dumps(value_value)
            else:
                dump_dict[key] = util._value_dumps(value)
        if hashcode is not None:
            dump_dict['hash'] = hashcode
        return dump_dict

    @staticmethod
    def _value_dumps(value):
        if isinstance(value, basestring):
            return value
        return json.dumps(value)


    @staticmethod
    def list_names(folder, extension):
        names = [f.split(".")[0] for f in listdir(folder) if isfile(join(folder, f)) and ".{0}".format(extension) in f]
        return names

    # @staticmethod
    # def _concat_dumps(value):
    #     if isinstance(value, basestring):
    #         return value
    #     elif hasattr(value, '__len__'):
    #         if isinstance(value, dict):
    #             dumped_value = {}
    #             for value_key, value_value in value.items():
    #                 dumped_value[value_key] = util._concat_dumps(value_value)
    #         else: #array
    #             dumped_value = []
    #             for value_value in value:
    #                 dumped_value.append(util._concat_dumps(value_value))
    #         return dumped_value
    #     else:
    #         return json.dumps(value)
    #
    # @staticmethod
    # def _concat_loads(value):
    #     loaded = json.loads(value)
    #     for key, value_value in loaded.items():
    #         try:
    #             real_value = util._concat_loads(value_value)
    #         except:
    #             real_value = value_value
    #         loaded[key] = real_value
    #     return loaded

    @staticmethod
    def obj_loads(dump_str):
        load_dict = {}
        loaded = json.loads(dump_str)
        for key, value in loaded.items():
            if key.contain("."):
                outkey, inkey = key.split(".")
                if outkey not in load_dict:
                    load_dict[outkey] = {}
                load_dict[outkey][inkey] = json.loads(value)
            else:
                try:
                    load_dict[key] = json.loads(value)
                except ValueError:
                    load_dict[key] = value
        return load_dict

    @staticmethod
    def try_json_loads(results, type_list, rowindex=False):
        new_results = []
        for result in results:
            if rowindex:
                new_result = [result[0]] #rowid
                skip = 1
            else:
                new_result = []
                skip = 0
            for index in range(skip, len(result)):
                data = result[index]
                if type_list[index-skip] == 'text':
                    try:
                        data = json.loads(result[index])
                    except:
                        data = result[index]
                new_result.append(data)
            new_results.append(new_result)
        return new_results

    @staticmethod
    def _get_state(api):
        information = getattr(util, "get_{0}".format(api))()
        state_dict = {}
        for state_key in information.keys():
            state_dict[state_key] = information.hget(state_key, 'hash')
        return state_dict

    @staticmethod
    def _is_active_function_key(key, active_function_key):
        return key in active_function_key

    @staticmethod
    def create_folder(directory):
        if not os.path.exists(directory):
            os.makedirs(directory)

    @staticmethod
    def compute_hash(str):
        encoded_str = bytes(str,'UTF-8')
        return hashlib.md5(encoded_str).hexdigest()

    @staticmethod
    def _checkpoint_path(function_key):
        checkpoint = "{0}{1}_retrain_checkpoint".format(CHECKPOINT_PATH,function_key)
        summary = "{0}{1}_retrain_logs".format(CHECKPOINT_PATH,function_key)
        return checkpoint, summary


    @staticmethod
    def _graph_path(function_key):
        return "tmp/{0}.pb".format(function_key)

    @staticmethod
    def _tflite_path(function_key):
        return "{0}{1}.tflite".format(TFLITE_PATH,function_key)
    @staticmethod
    def _learn_tflite_path(function_key):
        return "{0}{1}.tflite".format(LEARN_TFLITE_PATH,function_key)

    @staticmethod
    def _learn_stat_path(function_key):
        return "{0}{1}.stat".format(LEARN_TFLITE_PATH,function_key)

    @staticmethod
    def _model_stat_path(function_key):
        return "{0}{1}.stat".format(TFLITE_PATH,function_key)

    @staticmethod
    def _stat_from_file(path):
        if os.path.exists(path):
            stat_str = open(path, "r").read()
            return json.loads(stat_str)
        return None

########## filtered recipe case id list #################
    @staticmethod
    def _case_id(case, id):
        return "_".join([str(case), id])

    @staticmethod
    def _case_id_from_str(case_id):
        value = case_id.split("_")
        return int(value[0]), value[1]

    @staticmethod
    def _input_id(input_name):
        return 'i{0}'.format(input_name)

    @staticmethod
    def _seq_id(index):
        return 's{0}'.format(index)

    @staticmethod
    def is_seq_id(id):
        return id[0] == 's'


########## sending an event via grpc #################

    @staticmethod
    def notify_postman(service_name, active=True):
        request = common_pb2.SimpleString(str=service_name)
        if active:
            util.call_postman('Connect', request)
        else:
            util.call_postman('Disconnect', request)

    @staticmethod
    def call_postman(method, request, metadata = []):
        logging.info("CALL_POSTMAN: method:{0} ".format(method))
        try:
            with grpc.insecure_channel('0.0.0.0:{0}'.format(POSTMAN_PORT)) as channel:
                stub = postman_pb2_grpc.InterPostmanStub(channel)
                response = getattr(stub, method)(request, metadata=[('name', NODE_NAME)]+metadata)
                return response
        except Exception as err:
            logging.warning("CALL_POSTMAN: cannot call {0} ".format(method))
            return common_pb2.ResponseMsg(success=False, msg="cannot connect to postman")

    @staticmethod
    def call_other_postman(hostname, method, request, metadata = None, timeout=10):
        logging.info("CALL_OTHER_POSTMAN: host:{0} method:{1} ".format(hostname, method))
        try:
            if metadata is None:
                metadata = []
            with grpc.insecure_channel('{1}:{0}'.format(POSTMAN_PORT, hostname)) as channel:
                stub = postman_pb2_grpc.InterPostmanStub(channel)
                response = getattr(stub, method)(request, metadata=[('name', NODE_NAME)]+metadata, timeout=timeout)
                logging.info('GRPC-TX: {0}'.format(sys.getsizeof(request)))
                logging.info('GRPC-RX: {0}'.format(sys.getsizeof(response)))
                return True, response
        except Exception as err:
            logging.warning('CALL_OTHER_POSTMAN: cannot call {1} at host {0}'.format(hostname, method))
            return False, None

    @staticmethod
    def pull_large_msg_from_other_postman(hostname, method, request, metadata = None):
        logging.info("CALL_OTHER_POSTMAN: host:{0} method:{1} (large msg)".format(hostname, method))
        if metadata is None:
            metadata = []
        try:
            with grpc.insecure_channel('{1}:{0}'.format(POSTMAN_PORT, hostname)) as channel:
                stub = postman_pb2_grpc.InterPostmanStub(channel)
                msg = ""
                for response in getattr(stub, method)(request, metadata=[('name', NODE_NAME)]+metadata):
                    msg += response.chunk
                logging.info('GRPC-TX: {0}'.format(sys.getsizeof(request)))
                logging.info('GRPC-RX: {0}'.format(sys.getsizeof(response)))
                return True, msg
        except Exception as err:
            logging.info('CALL_OTHER_POSTMAN: cannot call {1} at host {0}'.format(hostname, method))
            return False, None

    @staticmethod
    def selfcall(context):
        calling_device = util._device_name(context)
        return  calling_device == NODE_NAME

    @staticmethod
    def _device_name(context):
        return context.invocation_metadata()[0].value

    @staticmethod
    def _context_dict(context):
        context_dict = {}
        metadata = context.invocation_metadata()
        for item in metadata:
            context_dict[item.key] = item.value
        return context_dict, metadata


    @staticmethod
    def event_to_postman(event):
        to_postman_iterator=util.gen_event_iterator(event)
        return util.call_postman('NewEvent', to_postman_iterator)

    @staticmethod
    def gen_event_iterator(event):
        obj = {}
        obj['descriptor'] = event.get_descriptor()
        obj['eventobj'] = event.get_content()
        _, chunklist,_ = util.chunk(json.dumps(obj), hash=False)
        return util.gen_large_msg(chunklist)

    @staticmethod
    def gen_large_msg(chunklist):
        for chunk in chunklist:
            yield common_pb2.LargeMsg(chunk=chunk)

    @staticmethod
    def read_large_msg(request_iterator):
        msg = ""
        for request in request_iterator:
            msg += request.chunk
        return msg
