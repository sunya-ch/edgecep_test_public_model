import json
import logging

from common.util import util

import random

import os
NODE_NAME = os.environ['BALENA_DEVICE_UUID']

######################################
##
## Event Component
##
######################################
class Event(object):
    def __init__(self, name, location, attribs, timestamp, origin):
        self.name = name
        self.location = location
        self.origin = origin
        self.attribs = attribs
        self.timestamp = float(timestamp)
        self.identifier = self.init_identifier()

    def attribute(self, attr_name):
        if attr_name in self.attribs.keys():
            return self.attribs[attr_name]
        try:
            out = getattr(self, attr_name)
            return out
        except:
            print('not found {0}'.format(attr_name))
            return None

    def init_identifier(self):
        identifier = []
        identifier.append("{0}_{1}_{2}".format(self.name,self.location,self.origin))
        identifier.append("{0}__{1}".format(self.name, self.origin))
        identifier.append("{0}_{1}_".format(self.name,self.location))
        identifier.append("{0}__".format(self.name))
        return identifier

    def get_descriptor(self):
        return "{0}_{1}".format(self.identifier[0], self.timestamp)

    def get_content(self):
        content = {}
        content['attribs'] = self.attribs
        return content

class FilteredEvent(Event):
    # def __init__(self, name, location, attribs, timestamp, forwarders, filterer, filtered_recipe, case_id_list):
    def __init__(self, name, location, attribs, timestamp, origin, recipe_case_id_list, creater):
        super(FilteredEvent, self).__init__(name, location, attribs, timestamp, origin)
        # self.filterer = filterer
        self.recipe_case_id_list = recipe_case_id_list
        self.creater = creater

    def get_content(self):
        content = super(FilteredEvent, self).get_content()
        # content["filterer"] = self.filterer
        content['recipe_case_id_list'] = self.recipe_case_id_list
        content['creater'] = self.creater
        return content

######################################
##
## Recipe Component
##
######################################

INPUT_SIZE_DEFAULT = 1024
COMPLEXITY_DEFAULT = 'exponential'

class Recipe(object):
    def __init__(self, recipe_obj):
        self.name = recipe_obj["meta-data.name"]
        self.type = recipe_obj["meta-data.type"]
        self.version = recipe_obj["version"]
        self.act = None
        self.attribute_dict = None
        self.required = recipe_obj["required"] == 'True'
        if self.type != 'static':
            self.pk = recipe_obj["meta-data.pk"]
            content_arr = json.loads(recipe_obj["content"])
            self.cases = []
            for content in content_arr:
                self.cases.append(Case(content))
            if "act" in recipe_obj.keys():
                self.act = json.loads(recipe_obj["act"])[0]
            ## for quality control attributes
            self.availability = float(recipe_obj["qos.availability"])
            self.efficiency = float(recipe_obj["qos.efficiency"])
            self.reliability = float(recipe_obj["qos.reliability"])

            size =  len(self.cases)
            self.function_arr = [None] * size
            self.complexity_arr = [None] * size
            self.input_size_arr = [None] * size
            self.output_name_arr = [None] * size
            self.deterministic_arr = [None] * size
            for casei in range(0, size):
                process = self.cases[casei].content.process
                function_values = util.get_function().hgetall(process.function)
                function = Function(function_values)
                self.complexity_arr[casei] = function.complexity
                self.input_size_arr[casei] = function.input_size
                self.function_arr[casei] = process.function
                self.output_name_arr[casei] = function.output_name
                if process.interval == 0:
                    self.deterministic_arr[casei] = False
                else:
                    self.deterministic_arr[casei] = True

        if self.type != 'private':
            self.attribute_dict = self.init_attribute_dict(json.loads(recipe_obj["attribute"]))

    def is_deterministic(self, function):
        for i in range(0, len(self.function_arr)):
            if self.function_arr[i]  == function and not self.deterministic_arr[i]:
                return False
        return True

    def init_precondition(self):
        for case in self.cases:
            case.init_precondition()

    def init_attribute_dict(self, objlist):
        dict = {}
        for obj in objlist:
            for key, value in obj.items():
                if value == None:
                    value = 'text'
                dict[key] = value
        return dict

    def get_type(self, attribute):
        return self.attribute_dict[attribute]

class Case(object):

    def __init__(self, content):
        self.content = self._interpret(content)
        self.preconditions = None

    def _interpret(self, content_obj):
        input = content_obj['input']
        process = content_obj['process']
        output = content_obj['output']
        sequence = None if 'sequence' not in content_obj.keys() else content_obj['sequence']
        group = get_value_or_none(content_obj, 'group')
        consume = get_value_or_none(content_obj, 'consume')
        return Content(input, process, output, sequence=sequence, group=group, consume=consume)

    def init_precondition(self):
        self.preconditions = []
        for input_name, input in self.content.input.items():
            precondition = Precondition(name=util._input_id(input_name), identifier=input.identifier,
                                filter=input.filter)
            self.preconditions.append(precondition)
        index = 0
        for seq in self.content.sequence:
            precondition = Precondition(name=util._seq_id(index), identifier=seq.identifier,
                                filter=seq.filter)
            self.preconditions.append(precondition)
            index += 1

class Precondition(object):
    def __init__(self, name, identifier, filter):
        self.name = name
        self.identifier = get_identifier(identifier)
        self.and_conditions = filter.and_conditions

    def check_validity(self, valid_condition):
        if len(self.and_conditions) == 0:
            return True
        for and_condition in self.and_conditions:
            if self._check_and_condidition_validity(and_condition.conditions, valid_condition):
                return True
        return False

    def _check_and_condidition_validity(self, conditions, valid_condition):
        for condition in conditions:
            if condition.condition_str not in valid_condition:
                return False
        return True


class Content(object):

    def __init__(self, input, process, output, group=None, sequence=None, consume=None):
        self.group = group # list of common attributes
        self.input = self._interpret_input(input)
        self.process = self._interpret_process(process)
        self.output = self._interpret_output(output)
        self.sequence = self._interpret_sequence(sequence, group)
        self.consume = consume

    def _interpret_input(self, inputs):
        input_dict = {}
        for name, input in inputs.items():
            identifier = input['identifier']
            column = get_value_or_none(input, 'column')
            limit = get_value_or_none(input, 'limit')
            select = get_value_or_none(input, 'select')
            sort = get_value_or_none(input, 'sort')
            filter = get_value_or_none(input, 'filter')
            input_dict[name] = Input(identifier=identifier,
                        column=column,
                        limit=limit,
                        select=select,
                        sort=sort,
                        filter=filter)
        return input_dict

    def _interpret_process(self, process):
        function = process['function']
        input = process['input']
        interval = int(get_value_or_none(process, 'interval', default=0))
        return Process(function=function,
                        input=input,
                        interval=interval)


    def _interpret_output(self, output):
        return Output(output=output)

    def _interpret_sequence(self, sequences, group):
        if sequences is None:
            return []
        sequence_arr = []
        for sequence in sequences:
            identifier = sequence['identifier']
            within = get_value_or_none(sequence, 'within')
            filter = get_value_or_none(sequence, 'filter')
            sequence_arr.append(Sequence(identifier=identifier, filter=filter, within=within, group=group))
        return sequence_arr

class Input(object):
    def __init__(self, identifier, column=None, limit=None, select=None, sort=None, filter=None):
        self.identifier = identifier
        event_name = identifier['event']
        self.column = column
        self.limit = limit
        self.select = select
        self.sort = sort
        self.filter = Filter(event_name, [[]]) if filter == None else Filter(event_name, filter)

class Process(object):
    def __init__(self, function, input, interval):
        self.function = function
        self.input = input
        self.interval = interval

    def get_input_arr(self, input_data):
        input_arr = []
        for name_attribute in self.input:
            name, attribute = name_attribute.split(".")
            input_arr.append(input_data[name][attribute].values.tolist())
        return input_arr

class Output(object):
    def __init__(self, output):
        self.process_map = []
        self.node_map = []
        self.group_map = []
        self.input_map = []

        for key, value in output.items():
            source, attribute = value.split(".")
            if source == 'process':
                self.process_map.append((key,attribute))
            elif source == 'node':
                self.node_map.append((key,attribute))
            elif source == 'group':
                self.group_map.append((key,attribute))
            else: #from inputs
                self.input_map.append((key,source,attribute))


    def get_pre_output_obj(self, node_map, group_map, input_map):
        output_obj = {}
        for (key, attribute) in self.node_map:
            output_obj[key] = node_map[attribute]
        for (key, attribute) in self.group_map:
            output_obj[key] = group_map[attribute]
        for (key, source, attribute) in self.input_map:
            output_obj[key] = input_map[source][attribute].values[0] # force select the first values
        return output_obj

    def update_output_obj(self, output_obj, process_map):
        for (key, attribute) in self.process_map:
            output_obj[key] = process_map[attribute]

class Sequence(object):
    def __init__(self, identifier, filter=None, within=None):
        self.identifier = identifier
        event_name = identifier['event']
        self.filter = Filter(event_name, [[]]) if filter == None else Filter(event_name, filter)
        self.within = within

    def get_precondition():
        return get_identifier(self.identfier), self.filter.or_conditions

class Filter(object):
    def __init__(self, event_name, filter):
        self.and_conditions = []
        for and_condition in filter:
            self.and_conditions.append(AndCondition(event_name, and_condition))

class AndCondition(object):
    def __init__(self, event_name, conditions):
        if len(conditions) == 0:
            self.conditions = [NoneCondition()]
        else:
            self.conditions = []
            for attribute, value in conditions.items():
                self.conditions.append(Condition(event_name, attribute, value))

    def check_from_valid_conditions(self, valid_conditions):
        for condition in self.conditions:
            if condition.condition_str not in valid_conditions:
                return False
        return True

class NoneCondition(object):
    def __init__(self):
        self.condition_str = "*"

    def check(self, event):
        return True


class Condition(object):
    VALID_COMPARE_OPS = ['>=', '<=', '>', '<', '!=', '==']

    def __init__(self, event_name, attribute, value):
        self.attribute = attribute
        two_chars_op = value[0:2]
        if two_chars_op in Condition.VALID_COMPARE_OPS:
            self.op = two_chars_op
            self.value = value[2:]
        else:
            one_char_op = value[0:1]
            if one_char_op in Condition.VALID_COMPARE_OPS:
                self.op = one_char_op
                self.value = value[1:]
            else:
                self.op = "=="
                self.value = value
        self.condition_str = "{0}{1}{2}".format(self.attribute, self.op, self.value)

    def check(self, event):
        left_val = event.attribute(self.attribute)
        right_val = self.value
        return self._op(left_val, right_val)

    def _op(self, left_val, right_val):
        op = self.op
        if self.op[0] == '<':
            if float(left_val) < float(right_val):
                return True
        elif self.op[0] == '>':
            if float(left_val) > float(right_val):
                return True
        if len(op) == 1:
            return False
        equal = left_val == right_val
        if self.op[0] == '!':
            return not equal
        else:
            return equal


######################################
##
## Function Component
##
######################################
TFHUB_MODULE = 'https://tfhub.dev/google/imagenet/inception_v3/feature_vector/1'
SAMPLING_RATE = 0.05
LEARN_RATE = 0.01
STEP = 100
BATCH_SIZE = 10

COMPLEXITY_CLASS = ['linear', 'polynomial', 'exponential', 'unknown']
COMPLEXITY_WEIGHT = [1, 2, 5, 5]

DEFAULT_LOAD = 1

class Function():
    def __init__(self, function_obj):
        self.version = function_obj["version"]
        self.name = function_obj["meta-data.name"]
        self.module_size = int(function_obj["meta-data.module_size"])
        input = json.loads(function_obj["meta-data.input"])
        output = json.loads(function_obj["meta-data.output"])
        self.input_size = int(input["size"])
        self.input_name = input["name"]
        self.output_size = int(output["size"])
        self.output_name = output["name"]
        self.complexity = COMPLEXITY_CLASS.index(function_obj["meta-data.complexity"])
        self.complexity_weight = COMPLEXITY_WEIGHT[self.complexity]
        self.load = 1 #initial load
        self.labels = None if "label" not in function_obj.keys() else json.loads(function_obj["label"])
        self.learn = None if "meta-data.learn" not in function_obj.keys() else LearnData(function_obj["meta-data.learn"])
        self.accuracy = get_value_or_none(function_obj, "meta-data.accuracy")
        self.samples = get_value_or_none(function_obj, "meta-data.samples")

class LearnData():
    def __init__(self, learn_value):
        learn_obj = json.loads(learn_value)
        self.tfhub_module = get_value_or_none(learn_obj, "tfhub_module", default=TFHUB_MODULE)
        self.sampling_time = get_value_or_none(learn_obj, "sampling_time", default=SAMPLING_RATE)
        self.learning_rate = get_value_or_none(learn_obj, "learn_rate", default=LEARN_RATE)
        self.step = get_value_or_none(learn_obj, "step", default=STEP)
        self.batch_size = get_value_or_none(learn_obj, "batch_size", default=BATCH_SIZE)


def str_to_dict(dict_str):
    return json.dumps(dict_str)

def get_value_or_none(obj, key, default=None):
    return default if key not in obj.keys() else obj[key]

def get_identifier(identifier_obj):
    assert 'event' in identifier_obj, "event is not defined"
    location = '' if 'location' not in identifier_obj else identifier_obj['location']
    origin = '' if 'origin' not in identifier_obj else identifier_obj['origin']
    return "{0}_{1}_{2}".format(identifier_obj['event'],location, origin)


######################################
##
## Actor Component
##
######################################

class Actor():
    def __init__(self, actor_obj):
        self.version = actor_obj["version"]
        self.name = actor_obj["meta-data.name"][1:-1]


######################################
##
## Learn Component
##
######################################


class Learn():
    def __init__(self, max_worker, create_function):
        self.worker_map = {}
        self.max_worker = max_worker
        self.create_function = create_function
        self._update_worker_map()

    def SynchronizeAdd(self, request, context):
        replaced_function = None
        if request.api == 'function' and self._is_active_function_key(request.key):
            replaced_function = request.key
        return self._update_worker_map(replaced_function=replaced_function)

    def SynchronizeRevoke(self, request, context):
        affected = self._is_affected(request.api, request.key)
        if affected:
            return self._update_worker_map()
        return [],[],[]

    def _is_affected(self, api, key):
        affected = False
        if api == 'recipe':
            api_key = key
            content_str = util.get_recipe().hget(api_key, 'content')
            contents = json.loads(content_str)
            for content in contents:
                function_key = content['process']['function']
                if util._is_active_function_key(function_key):
                    affected = True
                    break
        else:
            affected = util._is_active_function_key(key)
        return affected

    def _is_active_function_key(self, key):
        return key in self.worker_map.keys()


    def _update_worker_map(self, replaced_function=None):
        new_active_list = self._get_new_active_list()
        previous_active_list = self.worker_map.keys()
        removed, added = util.get_removed_added(previous_active_list, new_active_list)
        for added_function in added:
            self._create(added_function)
        if replaced_function is not None and replaced_function in new_active_list:
            self._create(replaced_function)
        for removed_function in removed:
            self._remove(removed_function)
        return removed, added, replaced_function


    def _get_new_active_list(self):
        function_list = Learn.function_list()
        new_active_list = []
        left_number = self.max_worker
        while len(function_list) > 0 and left_number > 0:
            if left_number < len(function_list):
                selected = random.sample(function_list, left_number)
            else:
                selected = function_list
            selected = list(dict.fromkeys(selected))
            new_active_list = new_active_list + selected
            left_number = left_number - len(selected)
            function_list = self._remove_selected(function_list, selected)
        return new_active_list

    def _remove_selected(self, function_list, selected):
        return [x for x in function_list if x not in selected]

    def _create(self, function_key):
        worker = self.create_function(function_key)
        if worker is not None:
            self.worker_map[function_key] = worker
        else:
            logging.warning('cannot create worker for {0}'.format(function_key))

    def _remove(self, function_key):
        worker = self.worker_map[function_key]
        if hasattr(worker, 'deactive'):
            worker.deactive()
        del self.worker_map[function_key]


    @staticmethod
    def function_list():
        function_list= []
        recipes = util.get_recipe()
        total = 0
        for recipe_key in recipes.keys():
            content_str = util.get_recipe().hget(recipe_key, 'content')
            if content_str is None:
                continue
            contents = json.loads(content_str)
            for content in contents:
                function_key = content['process']['function']
                function_list.append(function_key)
        return function_list



class ProcessorInfo():
    def __init__(self, spec_score, active_recipe, active_score, ip):
        self.spec_score = spec_score
        self.active_recipe = active_recipe
        self.active_score = active_score
        self.ip = ip

    @staticmethod
    def better_newinfo(info, cmp_info):
        if info.spec_score > cmp_info.spec_score:
            return False
        if info.active_score > cmp_info.active_score:
            return False
        return True

    @staticmethod
    def equal_info(info, cmp_info):
        return info.spec_score == cmp_info.spec_score and info.active_score == cmp_info.active_score
