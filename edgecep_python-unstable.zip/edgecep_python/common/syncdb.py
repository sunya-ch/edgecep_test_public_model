from common.util import util

import sqlite3
from contextlib import closing

import numpy as np
import os
SYNC_LIMIT = 10

import logging

DB_PATH = os.environ['DB_PATH']
class SynchronizedDB():

    def __init__(self, SYNC_DB, table_name, field_list, type_list, key_index_list, replace=False):
        self.SYNC_DB = SYNC_DB
        self.key_index_list = key_index_list
        self.value_index_list = [x for x in range(0, len(field_list)) if x not in key_index_list]
        self.field_list = field_list
        self.type_list = type_list
        self.table_name = table_name.lower()
        self._init_table(replace)
        # self._show_table()


######## For command synchronization  ########
    def insert(self, arr):
        assert len(arr) == len(self.field_list), "insert must be the same range {0}->{1}".format(len(arr), len(self.field_list))
        sqlite_arr = []
        for i in range(0, len(self.field_list)):
            if self.type_list[i] == 'text':
                sqlite_arr.append("'{0}'".format(arr[i]))
            else:
                sqlite_arr.append(str(arr[i]))
        attr_str = ", ".join(sqlite_arr)
        sql = "insert into {0} values ({1})".format(self.table_name, attr_str)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)

    def update(self, keyvals, updatedindex, updatevals):
        assert len(arr) == len(self.field_list), "update must be the same range {0}->{1}".format(len(arr), len(self.field_list))
        strlist = self._get_equal_strlist(updatedindex, updatevals)
        setstr = ", ".join(strlist)
        condition_str = self._get_and_condition_str(self.key_index_list, keyvals)
        sql = "update {0} set {1} where {2}".format(self.table_name, setstr, condition_str)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)


    def insert_or_update(self, arr):
        keyvals = []
        for index in self.key_index_list:
            keyvals.append(arr[index])
        if exists(keyvals):
            updatedvals = []
            for index in self.value_index_list:
                updatedvals.append(arr[index])
            update(arr, keyvals, self.value_index_list, updatedvals)
        else:
            insert(arr)

    # def save_synchronization_state(self, api, name, op, detail, hash, timestamp):
    #     sql = "insert into {6} values ('{0}', '{1}', '{2}', '{3}', '{4}', {5})".format(api, name, op, detail, hash, timestamp, COMMAND_TABLE_NAME)
    #     util.run_sql(self.SYNC_DB, sql)

    def exists(self, keyvals):
        condition_str = self._get_and_condition_str(self.key_index_list, keyvals)
        return SynchronizedDB.is_exist_tuple(self.SYNC_DB, self.table_name, condition_str)

    # def exists(self, api, name, hash):
    #     condition_str = "api = '{0}' and name = '{1}' and hash = '{2}'".format(api, name, hash)
    #     return util.is_exist_tuple(self.SYNC_DB, COMMAND_TABLE_NAME, condition_str)

    # def get_latest_command(self, api, name):
    #     sql = "select op, detail, hash, timestamp from {2} where api = '{0}' and name = '{1}' order by timestamp desc limit 1".format(api.upper(), name, COMMAND_TABLE_NAME)
    #     rows = util.get_sql(self.SYNC_DB, sql)
    #     return rows[0]


    def select(self, index_list=None, value_list=None, order_list=None, DESC_list=None, limit=None):
        condition_str = ""
        order_str = ""
        limit_str = ""

        if index_list is not None:
            condition_str = " where {0}".format(self._get_and_condition_str(index_list, value_list))

        if order_list is not None:
            order_str_item = []
            for i in range(0, len(order_list)):
                desc = 'DESC' if DESC_list is None or DESC_list[i] else 'ASC'
                attr = order_list[i]
                order_str_item.append("{0} {1}".format(attr, desc))
            order_str = " order by {0}".format(", ".join(order_str_item))

        if limit is not None:
            limit_str = " limit {0}".format(limit)

        sql = "select * from {0}{1}{2}{3}".format(self.table_name, condition_str, order_str, limit_str)

        rows = SynchronizedDB.get_sql(self.SYNC_DB, sql)
        return rows

    def _get_and_condition_str(self, index_list, value_list):
        strlist = self._get_equal_strlist(index_list, value_list)
        condition_str = " and ".join(strlist)
        return condition_str

    def _get_equal_strlist(self, index_list, value_list):
        assert len(index_list) == len(value_list) , " index and value must be same length"
        strlist = []
        for i in range(0, len(value_list)):
            index = index_list[i]
            if self.type_list[i] is 'text':
                strlist.append("{0} = '{1}'".format(self.field_list[index], value_list[i]))
            else:
                strlist.append("{0} = {1}".format(self.field_list[index], value_list[i]))
        return strlist

    def count(self, group_value=None):
        group_str = ""
        group_select_str = ""
        if group_value is not None:
            join_value = ", ".join(group_value)
            group_str = " group by {0}".format(join_value)
            group_select_str = "{0}, ".format(join_value)
        sql = "select {2}count(*) from {0}{1}".format(self.table_name, group_str, group_select_str)
        rows = SynchronizedDB.get_sql(self.SYNC_DB, sql)
        return rows

############## Handle select ####################
    #
    # def try_select_from_time(self, timelimit, group_index=None, group_str=""):
    #     if group_str != "":
    #         group_str = "{0}".format(self._group_condition_str(group_index, group_str))
    #     return is_exist_tuple(self.SYNC_DB, self.table_name, group_str):
    #
    # def select_from_time(self, timelimit, head, group_index=None, group_str="", sort=None):
    #     sort_str = self._sort_str(sort, head)
    #     if group_str != "":
    #         group_str = " where {0}".format(self._group_condition_str(group_index, group_str))
    #     sql = "select rowid, * from {0}{1}{2}".format(self.table_name, sort_str, group_str)
    #     rows = SynchronizedDB.get_sql(self.SYNC_DB, sql)
    #     return  len(rows)>0, rows

    def try_select_from_N(self, N, group_index=None, group_str=""):
        if group_str != "":
            group_str = " where {0}".format(self._group_condition_str(group_index, group_str))
        sql = "select count(*) from {0}{1}".format(self.table_name, group_str)
        rows = SynchronizedDB.get_sql(self.SYNC_DB, sql)
        return rows[0][0]>=N

    def select_from_N(self, N, head, group_index=None, group_str="", sort=None):
        sort_str = self._sort_str(sort, head)
        if group_str != "":
            group_str = " where {0}".format(self._group_condition_str(group_index, group_str))
        limit_str = ""
        if N > 0:
            limit_str = " limit {0}".format(N)
        sql = "select rowid, * from {0}{1}{2}{3}".format(self.table_name, group_str, sort_str, limit_str)
        rows = SynchronizedDB.get_sql(self.SYNC_DB, sql)
        success = (N < 0 and len(rows) > 0) or (len(rows) >= N)
        return  success, rows

############## Handle limit ####################

    def delete_outdate(self, timelimit, head, group_index=None, group_value=None, sort=None): #head will never set
        acceptable = util.current_timestamp() - timelimit
        sql = "delete from {0} where timestamp < {1}".format(self.table_name, acceptable)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)

    def delete_N_from(self, N, head, group_index=None, group_value=None, sort=None):
        rows = self.count(group_value)
        sort_str = self._sort_str(sort, head)
        if group_value is None:
            count = rows[0][0]
            over_num = count - N
            if over_num <= 0:
                return None
            else:
                condition_str = ""
                self._delete_N_from(sort_str=sort_str, over_num=over_num)
        else:
            for row in rows:
                over_num = int(row[len(group_value)]) - N
                if over_num <= 0:
                    continue
                counted_value = [row[i] for i in range(0, len(group_value))]
                condition_str = " where {0}".format(self._get_and_condition_str(group_index, counted_value))
                self._delete_N_from(condition_str=condition_str, sort_str=sort_str, over_num=over_num)

    def _delete_N_from(self, condition_str="", sort_str="", over_num=None):
        select_sql = "select rowid from {0}{1}{2} limit {3}".format(self.table_name, condition_str, sort_str, over_num)
        sql = "delete from {0} where rowid in ({1})".format(self.table_name, select_sql)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)

    def _sort_str(self, sort, head):
        asc = "asc" if head else "desc"
        if sort is None:
            return " order by rowid "+asc
        sort_values = []
        for col in sort:
            sort_values.append("{0} {1}".format(col, asc))
        return " order by {0}".format(", ".join(sort_values))

    def _group_str(self, group):
        if group is None:
            return ""
        else:
            return " group by {0}".format(" ,".join(group))

    def _group_condition_str(self, group_index, group_str):
        return self._get_and_condition_str(group_index, group_str.split("_")[1:])

############## consume ####################
    def consume_group(self, group_index, group_str):
        if group_str != "":
            group_str = " where {0}".format(self._group_condition_str(group_index, group_str))
        sql = "delete from {0}{1}".format(self.table_name, group_str)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)

    def consume_rows(self, rowids):
        sql = "delete from {0} where rowid in ({1})".format(self.table_name, ", ".join(rowids))
        SynchronizedDB.run_sql(self.SYNC_DB, sql)


######## For processor synchronization  ########



######## ######## ######## ######## ######## ########

    def _init_table(self, replace=False):
        if replace:
            self._drop_table()
        assert len(self.type_list) == len(self.field_list), "insert must be the same range {0}->{1}".format(len(self.type_list), len(self.field_list))
        attr = []
        for i in range(0, len(self.field_list)):
            if self.type_list[i] is None:
                self.type_list[i] = 'text'
            attr.append("{0} {1}".format(self.field_list[i], self.type_list[i]))
        attr_str = ", ".join(attr)
        sql = "create table if not exists {0} ({1})".format(self.table_name, attr_str)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)

    # def _init_command_table(self):
    #     sql = "create table if not exists {0} (api text, name text, op text, detail text, hash text, timestamp real)".format(COMMAND_TABLE_NAME)
    #     util.run_sql(self.SYNC_DB, sql)
    #
    # def _init_processor_table(self):
    #     sql = "create table if not exists {0} (device_name text PRIMARY KEY, active_recipe text, active_score real)".format(PROCESSOR_TABLE_NAME)
    #     util.run_sql(self.SYNC_DB, sql)

    def _drop_table(self):
        sql = "drop table if exists {0}".format(self.table_name)
        SynchronizedDB.run_sql(self.SYNC_DB, sql)

    def _show_table(self):
        sql = "select * from {0}".format(self.table_name)
        rows = SynchronizedDB.get_sql(self.SYNC_DB, sql)
        for row in rows:
            logging.info("SYNCDB: row:{0},{1}".format(row[0], row[1]))

    @staticmethod
    def _path(db):
        return "{1}{0}.db".format(db,DB_PATH)

    @staticmethod
    def run_sql(db, sql):
        logging.info("SYNCDB-RUN: sql:{0}".format(sql[0:50]))
        db_path = SynchronizedDB._path(db)
        with closing(sqlite3.connect(db_path)) as conn:
            c = conn.cursor()
            c.execute(sql)
            conn.commit()

######## ######## ######## ######## ######## ########
    @staticmethod
    def get_sql(db, sql):
        logging.info("SYNCDB-GET: sql:{0}".format(sql))
        output = []
        db_path = SynchronizedDB._path(db)
        with closing(sqlite3.connect(db_path)) as conn:
            c = conn.cursor()
            c.execute(sql)
            for row in c:
                output.append(row)
            conn.commit()
        return np.asarray(output)

    @staticmethod
    def is_exist_tuple(db, table, condition_str):
        sql = "select rowid from {0} where {1} limit 1".format(table, condition_str)
        db_path = SynchronizedDB._path(db)
        with closing(sqlite3.connect(db_path)) as conn:
            c = conn.cursor()
            c.execute(sql)
            fetched = c.fetchone()
            if fetched is None:
                return False
            else:
                return True
            conn.commit()
        return False
