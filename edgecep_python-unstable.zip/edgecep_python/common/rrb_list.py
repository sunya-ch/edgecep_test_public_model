try:
    import thread as thread
except ImportError:
    import _thread as thread

class PrioritizedRoundRobin():
    def __init__(self, max_level=3, better_func=None, min_level_func=None):
        self.rrblist = [None]*(max_level+1)
        for level in range(0, len(self.rrblist)):
            self.rrblist[level] = RoundRobinList()
        self.max_level = max_level
        self.level_token = 0
        self.level_count = 0
        self.better_func = better_func
        self.min_level_func = min_level_func or self.default_min_level
        self.lock = thread.allocate_lock()
        self.degree = 0

    def get_list(self):
        all = []
        with self.lock:
            for level in range(0, self.max_level+1):
                all += self.rrblist[level].get_list()
        return all

    def insert(self, item):
        with self.lock:
            cur_level = self._level(item)
            prev_index = None
            new = True
            if cur_level >= 0: #exist
                prev_index = self.rrblist[cur_level]._index(item)
                if prev_index:
                    level = cur_level
            if not prev_index:
                level = self.min_level_func(item)
            else:
                new = False
            update = self._insert(item, level, prev_index=prev_index)
#            print('insert {0} to level {1} - {2}, new {3}'.format(item, level, update, new))
            if new:
                self.degree += 1
        return update

    def default_min_level(self, item):
        return 0

    def _insert(self, item, level, prev_index=None):
        update = False
        with self.rrblist[level].lock:
            if self.better_func:
                index = self._get_insert_index(level, item)
            if prev_index != index:
                if prev_index:
                    self.rrblist[level]._remove(item)

                update = self.rrblist[level]._insert(item, index)
        return update

    def _get_insert_index(self, level, item):
        curlist = self.rrblist[level].get_list()
        index = 0
        for cur in curlist:
            if not self.better_func(cur, item):
                index += 1
                continue
            break
        return index

    def remove(self, item):
        with self.lock:
            cur_level = self._level(item)
            if cur_level >= 0:
                update = self._remove(item, cur_level)
#                print('remove {0} from level {1} - {2}'.format(item, cur_level, update))
                if update:
                    self.degree -= 1

    def _remove(self, item , level):
        with self.rrblist[level].lock:
            update = self.rrblist[level]._remove(item)
        return update

    def get_and_update_turn(self, skiplist=[]):
        print('wait for lock')
        with self.lock:
            print('get lock')
            # self.print()

            success = self.start_search()
            # find start level and current turn
            if not success:
                print('not success')
                return False, None

            start_level = self.level_token
            start_turn = self.rrblist[self.level_token].turn
            print('start ', start_level, ' turn ', start_turn)
            while True:
                level = self.level_token
                success, result = self.rrblist[level].get_and_update_turn()
                if result not in skiplist:
                    return success, result
                if self.rrblist[level].turn == start_turn: # back to start point
                    if not self._level_up(): # only one level
                        return False, None
                    while self.rrblist[self.level_token].turn < 0:
                        # to next available level
                        self._level_up()
                        if self.level_token == start_level:
                            return False, None
                    start_turn = self.rrblist[self.level_token].turn

    def start_search(self):
        success = True
        start_level = self.level_token
        first_check = True
        while True:
            level = self.level_token
            if self.rrblist[level].turn == 0: # need to check count
                level_up = self._count_up()
                if level_up:
                    continue
                break # counted
            if self.rrblist[level].turn < 0: # invalid level
                self._level_up()
                if self.level_token == start_level: # loop
                    if self.rrblist[start_level].turn < 0:
                        success = False # start level also invalid
                    break
                else:
                    continue
            break
        return success


    def _count_up(self):
        self.level_count += 1
        if self.level_count > self._max_level_count():
            return self._level_up()
#        print('level: ', self.level_token, ' count up to ',self.level_count, '/', self._max_level_count())
        return False

    def _level_up(self):
        prev_level = self.level_token
        self.level_token += 1
        if self.level_token > self.max_level:
            self.level_token = 0
        self.level_count = 0
        return prev_level != self.level_token
#        print('level up to ',self.level_token)

    def move_to_lowest(self, item):
        with self.lock:
            cur_level = self._level(item)
            if cur_level >= 0: #valid level
                next_level = self.max_level
                self._move(item, cur_level, next_level)

    def fail_report(self, item):
        with self.lock:
            cur_level = self._level(item)
            if cur_level >= 0: #valid level
                next_level = cur_level + 1
                next_level = min(next_level, self.max_level)
#                print('move fail {0} from level {1} to level {2}'.format(item, cur_level, next_level))
                self._move(item, cur_level, next_level)

    def success_report(self, item):
        with self.lock:
            cur_level = self._level(item)
            if cur_level < 0:
                level = self.min_level_func(item)
                self._insert(item, level)
            else:
                next_level = cur_level - 1
                min_level = self.min_level_func(item)
                next_level = max(next_level, min_level)
                self._move(item, cur_level, next_level)

    def _move(self, item, from_level, to_level):
        if from_level != to_level:
            self._remove(item, from_level)
            self._insert(item, to_level)
#            print('move {0} from level {1} to level {2}'.format(item, from_level, to_level))

    def _level(self, item):
        for level in range(0, self.max_level+1):
#            print(level, self.rrblist[level].item_list)
            if item in self.rrblist[level].item_list:
                return level
        return -1

    def _max_level_count(self):
        return (self.max_level - self.level_token) + 1

    def print(self):
        for level in range(0, self.max_level+1):
            print('level: ', level)
            print(self.rrblist[level].item_list)

class RoundRobinList():
    def __init__(self, init_list=None):
        if init_list:
            self.item_list = init_list
            self.turn = 0
        else:
            self.item_list = []
            self.turn = -1
        self.lock = thread.allocate_lock()

    def get_list(self):
        return self.item_list.copy()

    def insert(self, item, index=None):
        with self.lock:
            self._insert(item, index)

    def _insert(self, item, index):
        update = True
        if item in self.item_list:
            if not index:
                index = len(self.item_list) - 1
            if self.item_list.index(item) != index:
                self._remove(item)
            else:
                update = False
        elif not index:
            index = len(self.item_list)
        if update:
            if index:
                self.item_list.insert(index, item)
            else:
                self.item_list.append(item)
            if self.turn < 0:
                self.turn = 0 # enable turn
            else:
                if self.turn >= index:
                    self.plus_turn()
        return update

    def plus_turn(self):
        self.turn += 1
        if self.turn >= len(self.item_list):
            self.turn = 0


    def remove(self, item):
        if item not in self.item_list:
            return False
        with self.lock:
            index = self.item_list.index(item)
            self._remove(item)

        return True

    def _remove(self, item):
        if item in self.item_list:
            index = self.item_list.index(item)
            self.item_list.remove(item)
            if len(self.item_list) == 0:
                self.turn = -1
            else:
                if self.turn > index:
                    assert self.turn > 0, "turn should not less than 1"
                    self.turn -= 1
                elif self.turn == index:
                    self.plus_turn()

    def _index(self, item):
        if item in self.item_list:
            return self.item_list.index(item)
        return None

    def get_and_update_turn(self):
        with self.lock:
            if self.turn < 0:
                success, result = False, None
            item = self.item_list[self.turn]
            self.plus_turn()
            success, result = True, item
        return success, result
