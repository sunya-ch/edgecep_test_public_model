from statsmodels.tsa.arima_model import ARIMA
from pandas import Series as Series
import numpy as np

from common.util import util
import math
import logging

try:
    import thread as thread
except ImportError:
    import _thread as thread

class AverageWindow:
    def __init__(self, window_size):
        self.window_size = window_size
        self.record = [None]*window_size
        for i in range(0,window_size):
            self.record[i] = []
        self.time0 = None
        self.lock = thread.allocate_lock()

    def new_record(self, value):
        with self.lock:
            i = self.get_current_i()
            self.record[i].append(value)

    def get_current_i(self):
        time = math.floor(util.current_timestamp())
        if not self.time0:
            self.time0 = time
        i = time - self.time0
        while i >= self.window_size:
            if np.size(self.record) > 0:
                # remove oldest and shift down
                self.record = np.delete(self.record, 0).tolist()
                self.record.append([])
                self.time0 += 1
                i -= 1
            else:
                # reset all
                self.time0 = time
                i = 0
        return i

    def mean(self):
        with self.lock:
            self.get_current_i()
            mean = np.mean(sum(self.record, []))
        return mean
