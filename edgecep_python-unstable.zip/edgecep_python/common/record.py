from common.util import util

import logging
class Record():

    complexity = ['linear', 'polynomial', 'exponential']
    default_time = [1, 1.5, 2]
    default_influence = [0.3, 0.4, 0.5]

    def __init__(self, recipe=None):

        for complexity in Record.complexity:
            complexity_time = "{0}_time".format(complexity)
            complexity_load = "{0}_load".format(complexity)
            complexity_n = "{0}_n".format(complexity)
            setattr(self, complexity_n, 0)
            setattr(self, complexity_load, 0)
            setattr(self, complexity_time, 0)

        if recipe:
            self._init_from_recipe(recipe.complexity_arr, recipe.input_size_arr)
            self.arrival_record = {} # predictor name -> arrival_number
            for function in recipe.function_arr:
                self.arrival_record[function] = 0
            self.start_time = util.current_timestamp()

    def _clear(self):
        for complexity in Record.complexity:
            complexity_time = "{0}_time".format(complexity)
            setattr(self, complexity_time, 0)

    def _init_from_recipe(self, complexity_arr, input_size_arr):
        self.str_list = []
        for index in complexity_arr:
            complexity_n = "{0}_n".format(Record.complexity[index])
            value = complexity_arr.count(index)
            setattr(self, complexity_n, value)
            self.str_list.append("{0}:{1}".format(complexity_n, value))

        i = 0
        for index in complexity_arr:
            complexity_load = "{0}_load".format(Record.complexity[index])
            added_load =  getattr(self, complexity_load) + input_size_arr[i]
            setattr(self, complexity_load, added_load)
            self.str_list.append("{0}:{1}".format(complexity_load, added_load))
            i += 1

    def add_value(self, function_name, index, processing_time):
        complexity_time = "{0}_time".format(Record.complexity[index])
        max_time = getattr(self, complexity_time)
        if max_time > 0 and not (processing_time > (2*max_time)):
            # not outliner
            max_time = max(max_time, processing_time)
            setattr(self, complexity_time, max_time)
        if function_name is not None:
            self.arrival_record[function_name] += 1

    def add_record(self, record):
        index = 0
        for complexity in Record.complexity:
            complexity_n = "{0}_n".format(complexity)
            complexity_load = "{0}_load".format(complexity)
            complexity_time = "{0}_time".format(complexity)
            setattr(self, complexity_load, getattr(self,complexity_load) + getattr(record, complexity_load))
            setattr(self, complexity_n, getattr(self,complexity_n) + getattr(record, complexity_n))
            self.add_value(None, index, getattr(record, complexity_time))
            index += 1

    def _complexity_avg_load(self, complexity):
        complexity_n = self._complexity_n(complexity)
        complexity_load = self._complexity_load(complexity)
        return 0 if complexity_n == 0 else complexity_load/complexity_n

    def _complexity_time(self, complexity):
        return getattr(self, "{0}_time".format(complexity))

    def _complexity_load(self, complexity):
        return getattr(self, "{0}_load".format(complexity))

    def _complexity_n(self, complexity):
        return getattr(self, "{0}_n".format(complexity))

    def var(self): # (n, l) * complexity
        var = []
        for complexity in Record.complexity:
            n = self._complexity_n(complexity)
            l = self._complexity_avg_load(complexity)
            var += [n, l]
        return var

    def pop_latest_rate(self, compute_time):
        latest_rate = {}
        window = compute_time - self.start_time
        for function_name,  arrival in self.arrival_record.items():
            latest_rate[function_name] = arrival/window
            self.arrival_record[function_name] = 0
            logging.info('RECORD: func:{3} rate:{0} window:{1} arrival:{2}'.format(latest_rate[function_name], window, arrival, function_name))
        self.start_time = util.current_timestamp()
        return latest_rate

    def print(self):
        assert hasattr(self, 'arrival_record'), "printing is available for agent record only"
        str_list = self.str_list.copy()
        for complexity in Record.complexity:
            complexity_time = "{0}_time".format(complexity)
            value = getattr(self, complexity_time)
            str_list.append("{0}:{1}".format(complexity_time, value))
        printout = " ".join(str_list)
        printout += " {0}".format(self.arrival_record)
        return printout

    # def __init__(self):
    #     self.linear = (0,0,0) # load, time , count
    #     self.polynomial = (0,0,0) # load, time , count
    #     self.exponential = (0,0,0) # load, time , count
    #
    #
    # def add_value(self, complexity, input_size, processing_time, in_count=1):
    #     sum_size, max_time, count = getattr(self, complexity)
    #     sum_size += input_size
    #     max_time = max(max_time, processing_time)
    #     count += in_count
    #     print(sum_size)
    #     setattr(self, complexity, (sum_size, max_time, count))
    #
    # def add_record(self, record):
    #     for complexity in Record.complexity:
    #         value = getattr(record, complexity)
    #         print(value)
    #         self.add_value(complexity, value[0], value[1], in_count=value[2])
