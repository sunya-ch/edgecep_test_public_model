"""Handler based on https://github.com/pirate/mesh-networking/tree/master/examples/mesh-botnet"""
import sys
sys.path.append(".")
import environ_set
import grpc
from concurrent import futures
import time

from protoc_py import postman_pb2
from protoc_py import postman_pb2_grpc

from protoc_py import common_pb2
from google.protobuf import empty_pb2



from localmesh.links import UDPLink
from localmesh.node import Node
from localmesh.programs import BaseProgram, RoutedProgram, R
from localmesh.filters import UniqueFilter

import json
import requests

from keeper import InterKeeper


from common.util import util

import os

import logging
logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

retries = 3

class IngressPostman(RoutedProgram):
    router = RoutedProgram.router

    def __init__(self, node):
        super(IngressPostman, self).__init__(node)

###### communication for topology keeper ######

    @router.route(R('^HEY'))
    def heard(self, packet, interface, fromaddr): # to-update code
        state_str = self.splitKey(packet, "HEY")
        state = json.loads(state_str)
        logging.info('KEEPER-RCV-HEY: ip:{0}'.format(fromaddr))
        self.send_all_info(interface, fromaddr)
        self.node.grpc_client.call_hash_in(state, fromaddr, interface.name)

        # ip = fromaddr
        # state_str = self.splitKey(packet, "HEY")
        # sp = state_str.split("}_")
        # if len(sp) > 1:
        #     state_str = sp[0]+"}"
        #     ip  = sp[1]
        # else:
        #     self.node.egress.repeat_hey(state_str, fromaddr, interface.name)
        # state = json.loads(state_str)
        # logging.info('KEEPER-RCV-HEY: ip:{0}'.format(ip))
        # self.node.grpc_client.call_hash_in(state, ip, interface.name)
        # self.send_all_info(interface, ip)

    @router.route(R('^HELLO'))
    def recv_hello(self, packet, interface, fromaddr):
        hello_str = self.splitKey(packet, "HELLO")
        jsonobj = json.loads(hello_str)
        name = jsonobj["name"]
        interface_name = interface.name
        if not util.is_known(name, fromaddr, interface_name):
            logging.info("POSTMAN-NEW_HELLO: device:{0}".format(name))
            self.send_all_info(interface, fromaddr)
        InterKeeper.update_from_hello(hello_str, fromaddr, interface_name, name)

    def send_all_info(self, interface, fromaddr):
        self.node.egress.send_hello_pkg_to(fromaddr, interface)
        for publisher in ['PROCESSOR', 'PRETRAINER']:
            self.node.grpc_client.probe_in(publisher)
        self.node.grpc_client.probe_modules()

    @router.route(R('^PING')) # PING [SENDER_IP]_[SEQ]
    def pong(self, packet, interface, fromaddr):
        seq = self.splitKey(packet, "PING")
        self.node.egress.pong(fromaddr, seq, interface)

    @router.route(R('^PONG'))
    def recv_pong(self, packet, interface, fromaddr):
        device_name, seq = self.splitKey(packet, "PONG").split('/')
        interface_name = interface.name
        InterKeeper.update_from_pong(device_name, fromaddr, interface_name, seq)

###### communication for filter ######

    # @router.route(R('^EVENT')) # large message
    # def recv_event(self, packet, interface, fromaddr):
    #     event_str = self.splitKey(packet, "EVENT")
    #     jsonobj = json.loads(event_str)
    #     descriptor = jsonobj["descriptor"]
    #     seq = jsonobj["seq"]
    #     content = jsonobj["content"]
    #     self.node.filterer.recv_event_chunk(descriptor, seq, content)

    # @router.route(R('^FILTERED')) # large message
    # def recv_filtered_event(self, packet, interface, fromaddr):
    #     event_str = self.splitKey(packet, "FILTERED")
    #     jsonobj = json.loads(event_str)
    #     descriptor = jsonobj["descriptor"]
    #     seq = jsonobj["seq"]
    #     content = jsonobj["content"]
    #     self.node.filterer.recv_filtered_event_chunk(descriptor, seq, content, fromaddr)

###### communication for api synchronization ######

    @router.route(R('^RECIPE')) # op = ADD,REPLACE,REVOKE
    def recv_recipe_packet(self, packet, interface, fromaddr):
        api = 'RECIPE'
        self.call_synchronizer(api, packet, interface.name, fromaddr)

    @router.route(R('^FUNCTION')) # op = ADD,REPLACE,REVOKE/ ADV / PULL/ MODULE
    def recv_function_packet(self, packet, interface, fromaddr):
        api = 'FUNCTION'
        self.call_synchronizer(api, packet, interface.name, fromaddr)

    @router.route(R('^ACTOR')) # op = ADD,REPLACE,REVOKE
    def recv_actor_packet(self, packet, interface, fromaddr):
        api = 'ACTOR'
        self.call_synchronizer(api, packet, interface.name, fromaddr)

##### Client RPC ######

    @router.route(R('^CHECK'))
    def recv_check(self, packet, interface, fromaddr):
        service = self.splitKey(packet, 'CHECK')
        if self.node.grpc_client.exists(service):
            service_lowercase = service.lower()
            if service_lowercase in ['actor', 'processor']:
                content = getattr(self.node.grpc_client, 'get_{0}_content'.format(service_lowercase))()
                if content is not None:
                    self.node.egress.servifce_ack(service, interface, content=content, fromaddr=fromaddr)
            else:
                self.node.egress.service_ack(service, interface, fromaddr=fromaddr)

    @router.route(R('^GET')) # recipe function actor
    def recv_get_api(self, packet, interface, fromaddr):
        api = self.splitKey(packet, 'GET')
        self.node.egress.api_ack(api, interface, fromaddr)

    @router.route(R('^TKREQ'))
    def recv_token_probe(self, packet, interface, fromaddr):
        recipe = self.splitKey(packet, 'TKREQ')
        signed_token = self.node.token_handler.signed_token(recipe)
        if signed_token is not None:
            self.node.egress.token_rep(signed_token, interface, fromaddr)

##### For Processing ######

    # @router.route(R('^TrainData|^LabeledData|^PretrainData|^TFLITE')) # train data is large message
    # def recv_learn_call(self, packet, interface, fromaddr):
    #     service = packet.split(' ')[0]
    #     obj_str = packet[len(service)+1:]
    #     self.node.grpc_client.learn_msg_in(service, obj_str, interface, fromaddr)


    @router.route(R('^LabeledData'))
    def recv_pretrain_data(self, packet, interface, fromaddr):
        content = self.splitKey(packet, 'LabeledData')
        obj = json.loads(content)
        key = obj['key']
        hash = obj['pretrain']
        label = obj['label']
        id = obj['id']
        request = common_pb2.PretrainMsg(key=key, pretrain=hash, label=label, id=id)
        self.node.grpc_client._handle_LabeledData(request)
        self.node.grpc_client._update_LabeledData(request)


    @router.route(R('^ADV'))
    def recv_adv(self, packet, interface, fromaddr):
        adv_str =  self.splitKey(packet, 'ADV')
        self.node.grpc_client.adv_msg_in(adv_str, interface, fromaddr)

    # @router.route(R('^PULL')) # get request for tflite model
    # def recv_pull_request(self, packet, interface, fromaddr):
    #     key = self.splitKey(packet, 'PULL')
    #     path = util._tflite_path(key)
    #     if os.path.exists(path):
    #         logging.info("tflite file exists.... now sending")
    #         data = open(path, "rb").read().decode('utf8').replace("'", '"')
    #         _, chunklist,_ = util.chunk(data, hash=False)
    #         request_iterator = util.gen_large_msg(chunklist)
    #         if not util.call_other_postman(fromaddr, 'TFLITE', request_iterator):
    #             logging.warning("fail to send tflite file")
    #         # self.node.egress.send_large_obj_to('TFLITE', key, data, fromaddr, interface)

    @router.route(R('^SUB'))
    def recv_subscription(self, packet, interface, fromaddr):
        str = self.splitKey(packet, 'SUB')
        obj = json.loads(str)
        namelist = obj['namelist']
        id = obj['id']
        publisher = obj['publisher']
        svc = obj['svc']
        self.node.grpc_client.sub_in(publisher, namelist, interface.name, fromaddr, id, svc)

    # @router.route(R('^UNSUB'))
    # def recv_subscription(self, packet, interface, fromaddr):
    #     str = self.splitKey(packet, 'UNSUB')
    #     obj = json.loads(str)
    #     name = obj['name']
    #     id = obj['id']
    #     svc = obj['svc']
    #     self.node.grpc_client.unsub_in(name, id, svc)

# ##### Actor call ######
#
#     @router.route(R('^ACT')) # large message
#     def recv_act_call(self, packet, interface, fromaddr):
#         self.node.grpc_client.act_msg_in(packet, interface, fromaddr)

#######################

    def splitKey(self, packet, key):
        return packet.split("{0} ".format(key))[-1]

    def call_synchronizer(self, api, packet, interface_name, fromaddr):
        content = self.splitKey(packet, api)
        content_obj = json.loads(content)
        self.node.synchronizer.rest_perform(api, content_obj, interface_name, fromaddr)

##################
##  GRPC SERVICE
##  Connect/Disconnect called by service when grpc start and stop
##  New

class InterPostman(postman_pb2_grpc.InterPostmanServicer):

    def __init__(self, node):
        self.node = node

############ limit to self-calling ##################
    def Connect(self, request, context):
        if util.selfcall(context):
            self.node.grpc_client.activate(request.str)
            self.node.egress.hey() # to get probe on other
        else:
            logging.warning('wrong call')
        return empty_pb2.Empty()

    def Disconnect(self, request, context):
        if util.selfcall(context):
            self.node.grpc_client.deactivate(request.str)
        return empty_pb2.Empty()

#####################################################

    def Synchronize(self, request_iterator, context):
        id = util._device_name(context)
        for request in request_iterator:
            self.node.synchronizer.grpc_perform(request, id)
        return empty_pb2.Empty()

    def NewEvent(self, request_iterator, context): # LargeMsg(chunk)
        if util.selfcall(context):
          # put to filter
            msg = util.read_large_msg(request_iterator)
            obj = json.loads(msg)
            descriptor = obj['descriptor']
            eventobj = obj['eventobj']
            self.node.filterer.myevent(descriptor, eventobj)
        return empty_pb2.Empty()

    def SelfAdv(self, request, context): # SimpleMsg(prefix, content)
        if util.selfcall(context):
            self.node.egress.broadcast(prefix=request.prefix, content=request.content)
            return self.node.grpc_client.adv_msg_in(request.content, None, "")
        return common_pb2.ResponseMsg(success=False,msg="permission denied")

    def SimpleBroadcast(self, request, context): # SimpleMsg(prefix, content)
        if util.selfcall(context):
            self.node.egress.broadcast(prefix=request.prefix, content=request.content)
            return common_pb2.ResponseMsg(success=True, msg="")
        return common_pb2.ResponseMsg(success=False,msg="permission denied")

    def PullFile(self, request, context): # DownloadMsg (url, save_path)
        if util.selfcall(context):
            try:
                r= requests.get(request.url, allow_redirects=True)
                open(request.save_path, 'wb').write(r.content)
                return common_pb2.ResponseMsg(success=True, msg='')
            except Exception as err:
                logging.error('cannot download: {0} ({1})'.format(request.url, err))
                return common_pb2.ResponseMsg(success=False, msg='')
        return common_pb2.ResponseMsg(success=False, msg="permission denied")

######################### END CALL LIMIT TO ITSELF ############################

    def FilteredEvent(self, request_iterator, context):
        metadata = context.invocation_metadata()
        return self.node.grpc_client.call_event_in(request_iterator, metadata)

    def TrainData(self, request_iterator, context): # LargeMsg(chunk)
        context_dict, metadata =util._context_dict(context)
        svc = context_dict['svc']
        return self.node.grpc_client._handle_TrainData(request_iterator, metadata, svc)

    def LabeledData(self, request, context):
        if util.selfcall(context):
            prefix = "LabeledData"
            content = {'key': request.key, 'pretrain': request.pretrain, 'label': request.label, 'id': request.id}
            self.node.egress.broadcast(prefix=prefix, content=json.dumps(content))
            return self.node.grpc_client._handle_LabeledData(request)
        return empty_pb2.Empty()

    def PretrainData(self, request_iterator, context):
        return self.node.grpc_client._handle_PretrainData(request_iterator, context)

    def LoadModule(self, request, context):
        key = request.str
        path = util._learn_tflite_path(key)
        if os.path.exists(path):

            # data = open(path, "rb").read().decode('utf8').replace("'", '"')
            data = open(path, 'rb').read()
            data = json.dumps(list(data))
            logging.info("POSTMAN-SEND_TFLITE: key:{0}".format(key))
            while len(data) > 0:
                max_cut = min(1000000, len(data))
                yield common_pb2.LargeMsg(chunk=data[0: max_cut])
                data = data[max_cut:]
        else:
            logging.warning("POSTMAN-SEND_TFLITE: key:{0} file not exists".format(key))
            yield common_pb2.LargeMsg(chunk="")


    def Offload(self, request, context):
        return self.node.grpc_client.offload(request, context)

    # def TFLITE(self, request_iterator, context):
    #     context_dict = util._context_dict(context)
    #     file_data = read_large_msg(request_iterator)
    #     tflite_path = util._tflite_path(context_dict['name'])
    #     open(tflite_path, "wb").write(encode(file_data))
    #     return empty_pb2.Empty()

    def Act(self, request_iterator, context): # LargeMsg(chunk)
        return self.node.grpc_client.call_act(request_iterator, context)

    # def SendTo(self, request, context): # DestinatedMsg(prefix, obj, ip, interface)
    #     interface = self.node.find_interface(request.interface)
    #     msg = "{0} {1}".format(request.prefix, request.obj)
    #     self.node.egress.send_msg_to(msg, request.ip, interface)
    #     return empty_pb2.Empty()

    # def LargeSendTo(self, request_iterator, context): # LargeMsg(chunk)
    #     msg = ""
    #     for request in request_iterator:
    #         msg = msg + request.chunk
    #     obj = json.loads(msg)
    #     ip = obj['ip']
    #     interface = self.node.find_interface(obj['interface'])
    #     prefix = obj['prefix']
    #     key = obj['key']
    #     str = json.dumps(obj['content'])
    #     success = self.node.egress._send_large_obj_to(prefix, key, str, ip, interface)
    #     return empty_pb2.Empty()


def grpc_start(node):
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    postman_pb2_grpc.add_InterPostmanServicer_to_server(InterPostman(node), server)
    server.add_insecure_port('0.0.0.0:{0}'.format(node.POSTMAN_PORT))
    server.start()
    node.first_greet()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        print('start grpc POSTMAN server')
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        print('grpc stop')
        server.stop(0)

class Postman(object):
    def __init__(self):
        self.links = UDPLink.get_available_ip_interfaces(recv_port=int(os.environ['RECV_PORT']), suppress_kw=['vbox','docker'])
        #self.node = Node(interfaces=self.links, Filters=(UniqueFilter,), Program=IngressPostman)
        self.node = Node(interfaces=self.links, Program=IngressPostman)
        self.register_node_info()

    def run(self):
        self.node.start()
        InterKeeper.run_keeper_loop(self.node.egress)

    def register_node_info(self):
        cache = util.get_node_info()
        cache.set('name', self.node.name)
        cache.set('mac', self.node.mac_addr)

def lookup(node, device_name): #device name in bytes
     cache = util.get_direct_cache()
     if device_name not in cache.keys():
        return None, None
     device = cache.hgetall(device_name)
     interface_name = device["interface"]
     ip = device["ip"]
     interface = node.find_interface(interface_name)
     return ip, interface


def flushalldb():
    r = util.get_node_info()
    r.flushdb()
    r = util.get_direct_cache()
    r.flushdb()
    r = util.get_memo_cache()
    r.flushdb()
    r = util.get_outdate_cache()
    r.flushdb()
    # r = util.get_adv()
    # r.flushdb()
    # r = util.get_recipe()
    # r.flushdb()
    # r = util.get_function()
    # r.flushdb()

def showdb():
    # r = util.get_direct_cache()
    # print(r.keys())
    # r = util.get_memo_cache()
    # print(r.keys())
    # r = util.get_outdate_cache()
    # print(r.keys())
    r = util.get_recipe()
    logging.info('RECIPES: {0}'.format(r.keys()))

    # for key in r.keys():
    #     value = r.hgetall(key)
    #     from common.component import Recipe
    #     recipe = Recipe(value)

    r = util.get_function()
    logging.info('FUNCTIONS: {0}'.format(r.keys()))

    # for key in r.keys():
    #     value = r.hgetall(key)
    #     from common.component import Function
    #     function = Function(value)


if __name__ == "__main__":
    while not util.redis_available():
        continue

    flushalldb()
    showdb()
    postman = Postman()
    postman.run()
    grpc_start(postman.node)
