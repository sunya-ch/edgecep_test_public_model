import json


# import datetime
from common.util import util

CLIENT_RECV_PORT = 3050

import os

import logging


NODE_NAME = os.environ['BALENA_DEVICE_UUID']

####################
## hello (broadcast, specific ip) with topologies, nodeinfo
## ping-pong
## hey with hash
## service_ack (CHECK ACK), api_ack(GET RET)
##

## select one device (highest seen index)

def encode(str):
    return bytes(str,'UTF-8')

class EgressPostman():
    def __init__(self, node):
        self.node = node

### External Communication

    def broadcast_hello(self, interfaces=None):
        print('broadcast hello called')
        if interfaces is None:
            interfaces = self.node.interfaces
        out_packet = self.get_hello_packet()
        self.node.send(packet=encode(out_packet), interfaces=interfaces)

    def send_hello_pkg_to(self, ip, interface):
        msg = self.get_hello_packet()
        self.send_msg_to(msg, ip, interface)

    def ping(self, ip, interface_name, seq):
        interface = self.node.find_interface(interface_name)
        msg = "PING {0}".format(seq)
        self.send_msg_to(msg, ip, interface)

    def pong(self, ip, seq, interface):
        msg = 'PONG {0}/{1}'.format(NODE_NAME, seq)
        self.send_msg_to(msg, ip, interface)

    def hey(self, interfaces=None):
        state_obj = self.get_hash_obj()
        self.broadcast_obj('HEY', state_obj, interfaces)

    def send_hey_to(self, ip, interface):
        state_obj = self.get_hash_obj()
        dumped_obj =  json.dumps(state_obj)
        msg = 'HEY {0}'.format(dumped_obj)
        self.send_msg_to(msg, ip, interface)

    # def repeat_hey(self, state_str, fromaddr, from_interface_name):
    #     hey_msg = state_str+"_"+fromaddr
    #     #other_interfaces = [interface for interface in self.node.interfaces if interface.name != from_interface_name]
    #     other_interfaces = [interface for interface in self.node.interfaces]
    #     self.broadcast('HEY', hey_msg, other_interfaces)

    def get_hash_obj(self):
        hash_obj = {}
        hash_obj["recipe"] = util._get_state('recipe')
        hash_obj["function"] = util._get_state('function')
        hash_obj["actor"] = util._get_state('actor')
        return hash_obj


#################### client reply ####################

    def service_ack(self, service, interface, content="", fromaddr=""):
        msg = "ACK {0}/{1}/{2}".format(service, interface.ip, content)
        self.send_msg_to(msg, fromaddr, interface, port=CLIENT_RECV_PORT)
        # self.send_msg_to(msg, interface.broadcast_addr, interface, port=CLIENT_RECV_PORT)

    def api_ack(self, api, interface, fromaddr):
        information = getattr(util, "get_{0}".format(api.lower()))()
        msg = "RET {0}{1}".format(api, json.dumps(information))
        self.send_msg_to(msg, fromaddr, interface)

    def token_rep(self, signed_token, interface, fromaddr):
        msg = "TKREP {0}".format(signed_token)
        self.send_msg_to(msg, fromaddr, interface)
#
# #################### forward filtered event ####################
#
#     def forward_filtered_event(self, device_name, eventobj):
#         ip, interface = lookup(self.node, device_name)
#         if interface == None:
#            print('cannot found')
#            return None
#         descriptor, content_list = util.get_descriptor_and_chunks(eventobj)
#         self._send_large_msg_to("FILTERED", descriptor, content_list, ip, interface)

#################### topology ####################

    def topologies(self):
        topologies = []
        cache = util.get_direct_cache()
        for mac_addr in cache.keys():
            dictobj = cache.hgetall(mac_addr)
            del dictobj["first_seen"]
            del dictobj["seen_count"]
            del dictobj["transmit_time"]
            del dictobj["strict"]
            topologies.append(dictobj)
        return topologies

    def get_hello_packet(self):
        info_packet = self.node_info()
        jsonstr = json.dumps(info_packet)
        out_packet = "HELLO {0}".format(jsonstr)
        return out_packet

    def node_info(self):
        info = {}
        cache = util.get_node_info()
        for key in cache.scan_iter():
            info[key] = cache.get(key)
        info['time'] = str(util.current_timestamp())
        return info


########## for simple object ################

    def broadcast_obj(self, prefix, obj, interfaces=None):
        dumped_obj =  json.dumps(obj)
        self.broadcast(prefix, dumped_obj, interfaces)

    def broadcast(self, prefix, content, interfaces=None):
        if interfaces is None:
            interfaces = self.node.interfaces
        msg = "{0} {1}".format(prefix, content)
        for interface in interfaces:
            logging.info("REST-SEND: {0} to bcast {1}".format(msg, interface))
            self.node.send(packet=encode(msg), interfaces=[interface])

    def send_msg_to(self, msg, ip, interface, port=None):
        logging.info("REST-SEND: {0} to {1} {2}".format(msg, ip, interface))
        self.node.send(packet=encode(msg), ip=ip, interfaces=[interface], port=port)

########## for large  object ################

    # def broadcast_large_obj(self, prefix, key, str):
    #     for interface in self.node.interfaces:
    #         self._send_large_obj_to(prefix, key, str, interface.broadcast_addr, interface)

    # def send_large_obj_to(self, prefix, key, str, ip, interface):
    #     hash, content_list, maxsize = util.chunk(str)
    #     descriptor = "{0}/{1}/{2}".format(key, hash, maxsize)
    #     return self._send_large_msg_to(prefix, descriptor, content_list, ip, interface)

    # def _send_large_msg_to(self, prefix, descriptor, content_list, ip, interface):
    #     i = 0
    #     for content in content_list:
    #         content_obj = {
    #                    'descriptor': descriptor,
    #                    'seq': i,
    #                    'content': content}
    #         packet = "{1} {0}".format(json.dumps(content_obj), prefix)
    #         i = i + 1
    #         return self.node.send(packet=encode(packet), ip=ip, interfaces=[interface])
