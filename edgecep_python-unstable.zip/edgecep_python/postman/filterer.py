import json

import math

from common.util import util
from common.component import Recipe, Precondition, FilteredEvent, Event, ProcessorInfo
from common.rrb_list import PrioritizedRoundRobin
from keeper import InterKeeper

import threading

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

import os

import logging

NODE_NAME = os.environ['BALENA_DEVICE_UUID']
MAX_REPLICATION = int(os.environ['MAX_REPLICATION'])

class InterFilter(threading.Thread):
    def __init__(self, egress):
        threading.Thread.__init__(self)
        self.filtered_chunk_record = {}
        # self.chunk_record = {}
        # self.unwanted_chunk = {}

        self.egress = egress
        self.new_mapper()
        self.event_queue = Queue()

    def init_forwarder(self, call_event_in_func):
        self.forwarder = Forwarder(self.mapper.reassign, call_event_in_func, self.mapper.forwarder_report, self.mapper.lay_off_processor)
        self.forwarder.start()

    def run(self):
        while not hasattr(self, 'forwarder'):
            pass
        while True:
            event = self.event_queue.get(block=True)
            result = self.mapper.assign(event)
            if result:
                (processor_fwd, egress_fwd, seq_processor_fwd, seq_egress_fwd, previous_assignment, empty_assignment) = result
                self.forwarder._handle_decision(event, processor_fwd, egress_fwd, seq_processor_fwd, seq_egress_fwd, previous_assignment, empty_assignment)


    def myevent(self, descriptor, eventobj, stop=False):
        name, location, origin, timestamp = util.get_descriptor_detail(descriptor)
        event = Event(name=name,
                      location=location,
                      attribs=eventobj['attribs'],
                      timestamp=timestamp,
                      origin=origin)
        self.event_queue.put(event)

    def new_mapper(self):
        self.mapper = Mapper()
        keys = util.get_recipe().keys()
        for key in keys:
            self.add_recipe(key)

    def processor_adv_in(self, adv, ip, interface):
        self.mapper.processor_adv_in(adv, ip, interface)


    def add_recipe(self, key):
        recipes = util.get_recipe()
        recipe_value = recipes.hgetall(key)
        if recipe_value["required"] == 'True':
            recipe = Recipe(recipe_value)
            recipe.init_precondition()
            self.mapper.activate(key, recipe)

    def revoke_recipe(self, key): # remove recipe from filtering
        self.mapper.deactivate(key)

############################################
    # def report_origin(self, processor_fwd, egress_fwd, caller=NODE_NAME):
    #     for device_name, key_recipe in egress_fwd.items():
    #         for recipe in key_recipe.keys():
    #             util.increase_token('ORIGIN', recipe, device_name)
    #             self.report_forward(recipe, device_name)
    #
    #     for recipe in processor_fwd.keys():
    #         util.increase_token('ORIGIN', recipe, caller)
    #     self.report_recv(processor_fwd, caller)


    # def _handle_decision(self, name, location, attribs, timestamp, origin, processor_fwd, egress_fwd):
    #     failed_recipes = []
    #     banned_list = []
    #     if len(processor_fwd) > 0:
    #         event = self._gen_filtered_event(name,location,attribs, timestamp, origin, processor_fwd)
    #         to_processor_iterator = util.gen_event_iterator(event)
    #         response = self._to_processor(to_processor_iterator)
    #         if not response.success:
    #             failed_recipes += json.loads(response.msg)
    #
    #     for device_name in forward_recipe_case_id_list:
    #         event = self._gen_filtered_event(name, location, attribs, timestamp, origin, egress_fwd[device_name])
    #         to_processor_iterator = util.gen_event_iterator(event)
    #         unprocessed_recipe_caseid = self._to_other_processor(device_name, to_processor_iterator)
    #         if not response.success:
    #             failed_recipes += json.loads(response.msg)


    # def recv_filtered_event_chunk(self, descriptor, seq, content, fromaddr):
    #     if self._recv_filtered_event_chunk(descriptor, seq, content):
    #         self._restore_filtered_event(descriptor, self.filtered_chunk_record[descriptor], fromaddr)
    #         del self.filtered_chunk_record[descriptor]
    #
    #
    # def _recv_filtered_event_chunk(self, descriptor, seq, content):
    #     if descriptor not in self.filtered_chunk_record:
    #        _, _, _, _, maxsize = util.get_descriptor_detail(descriptor)
    #        maxsize = int(maxsize)
    #        self.filtered_chunk_record[descriptor] = [None] * maxsize
    #        return self._chunk_in(descriptor, seq, content, self.filtered_chunk_record)
    #     else:
    #        return self._chunk_in(descriptor, seq, content, self.filtered_chunk_record)
    #
    # def _chunk_in(self, descriptor, seq, content, chunk_record):
    #     chunk_record[descriptor][seq-1] = content
    #     for chunk in chunk_record[descriptor]:
    #         if chunk is None:
    #             # some chunks not coming yet
    #             return False
    #     return True

    # def _restore_filtered_event(self, descriptor, chunklist, fromaddr):
    #     name, location, origin, timestamp, eventobj = self._restore_eventobj(descriptor, chunklist)
    #
    #     recipe_case_id_list = eventobj['recipe_case_id_list']
    #     keys = recipe_case_id_list.keys()
    #     attribs = eventobj['attribs']
    #     creater = eventobj['creater']
    #     if creater == origin:
    #         self.report_origin(recipe_case_id_list, {}, caller=origin)
    #     else:
    #         self.report_recv(recipe_case_id_list, creater)
    #
    #     forward_recipe_case_id_list = {}
    #
    #     for key in keys:
    #         if not self.mapper.is_active(key):
    #             if self.mapper.is_to_forward(key):
    #                 device_name = self.mapper.forward_name[key]
    #                 if device_name not in forward_recipe_case_id_list.keys():
    #                     forward_recipe_case_id_list[device_name] = {}
    #                 forward_recipe_case_id_list[device_name][key] = recipe_case_id_list[key].copy()
    #                 self.report_forward(key, device_name)
    #             else:
    #                 logging.warning('drop {0}'.format(key))
    #             del recipe_case_id_list[key]
    #     self._handle_decision(name, location, attribs, timestamp, origin, recipe_case_id_list, forward_recipe_case_id_list)

    # def _restore_eventobj(self, descriptor, chunklist):
    #     name, location, origin, timestamp, _ = util.get_descriptor_detail(descriptor)
    #     full_content = ''.join(chunklist)
    #     return name, location, origin, timestamp, json.loads(full_content)


MAX_TRY = 3
class Forwarder(threading.Thread):
    def __init__(self, reassign_function, call_event_in, report_func, layoff_func):
        threading.Thread.__init__(self)
        self.filtered_event_queue = Queue()
        self.reassign = reassign_function
        self.call_event_in = call_event_in
        self.report = report_func
        self.layoff = layoff_func
        self.dropcount = 0


    def run(self):
        while True:
            (event, failed_recipes, recipe_case_id_list, previous_assignment, cur_try) = self.filtered_event_queue.get(block=True)
            logging.info('FORWARDER-REASSIGN: event:{0} recipe:{1} prev:{2} try:{3}'.format(event.name, failed_recipes, previous_assignment, cur_try))
            processor_fwd, egress_fwd, empty_assignment = self.reassign(event, failed_recipes, recipe_case_id_list, previous_assignment)
            self._handle_decision(event, processor_fwd, egress_fwd, {}, {}, previous_assignment, empty_assignment=empty_assignment, cur_try=cur_try)

    def try_later(self, event, failed_recipe, recipe_case_id_list, previous_assignment, cur_try):
        if cur_try < MAX_TRY:
            cache = (event, \
                    failed_recipe.copy(), \
                    recipe_case_id_list.copy(), \
                    previous_assignment.copy() , \
                    cur_try)
            self.filtered_event_queue.put(cache)
        else:
            self.dropcount += 1
            print('drop: ',self.dropcount)
            logging.warning('FORWARER-DROP: name:{0}'.format(event.name))

    def _gen_filtered_event(self, name, location, attribs, timestamp, origin):
        return FilteredEvent( name=name,
                              location=location,
                              attribs=attribs,
                              timestamp=timestamp,
                              origin=origin,
                              creater=NODE_NAME)


    def _handle_decision(self, event, processor_fwd, egress_fwd, seq_processor_fwd, seq_egress_fwd, previous_assignment, empty_assignment=None, cur_try=0):
        start = util.current_timestamp()
        recipe_case_id_list = {}
        success_recipes = []
        failed_recipes = []
        if len(processor_fwd) > 0:
            response = self._to_processor(event, processor_fwd)
            self._add_failed_recipe_and_update_reference(response, processor_fwd, failed_recipes, success_recipes, recipe_case_id_list)

        for device_name in egress_fwd.keys():
            response = self._to_other_processor(device_name, event, egress_fwd[device_name])
            self._add_failed_recipe_and_update_reference(response, egress_fwd[device_name], failed_recipes, success_recipes, recipe_case_id_list, device_name=device_name)
            # increase origin token for success sending
            self.report_origin_of_forwarders(egress_fwd[device_name].keys(), failed_recipes, device_name)


        if len(seq_processor_fwd) > 0:
            self._to_processor(event, seq_processor_fwd)

        for device_name in seq_egress_fwd.keys():
            self._to_other_processor(device_name, event, egress_fwd[device_name])

        if empty_assignment is not None:
            for key, idlist in empty_assignment.items():
                previous_assignment[key] = []
                recipe_case_id_list[key] = idlist
                failed_recipes.append(key)

        failed_recipes = [x for x in failed_recipes if x not in success_recipes]
        print(processor_fwd)
        print(egress_fwd)
        print('success recipe: ', success_recipes)
        print('filter delay :', util.current_timestamp()-start)
        if len(failed_recipes) > 0:
            self.try_later(event, failed_recipes, recipe_case_id_list, previous_assignment, cur_try+1)

    def _add_failed_recipe_and_update_reference(self, response, reference_list, failed_recipes, success_recipes, recipe_case_id_list, device_name=None):
        if not response or not response.success:
            if not response or response.msg == "": #not active
                load_msg = reference_list.keys()
                if device_name:
                    self.layoff(device_name)
            else:
                print('fail reciped error: ', response.msg)
                load_msg = json.loads(response.msg) # failed name list
                if device_name:
                    for recipe_name in load_msg:
                        self.report(recipe_name, device_name, False)
                    success_list = [x for x in reference_list.keys() if x not in load_msg]
                    for recipe_name in success_list:
                        self.report(recipe_name, device_name, True)
                    success_recipes += success_list
            failed_recipes += load_msg # name list
            recipe_case_id_list.update(reference_list) # for reference
        else:
            success_recipes += reference_list.keys()

    def report_origin_of_forwarders(self, sending_recipe, failed_recipe, recv_device):
        success_sending = [x for x in sending_recipe if x not in failed_recipe]
        for recipe in success_sending:
            util.increase_token('ORIGIN', recipe, recv_device)

    def _to_processor(self, event, recipe_case_id):
        filtered_event = self._gen_filtered_event(event.name, event.location, event.attribs, event.timestamp, event.origin)
        to_processor_iterator = util.gen_event_iterator(filtered_event)

        metadata=[('caseid', json.dumps(recipe_case_id))]
        return self.call_event_in(to_processor_iterator, metadata)

    def _to_other_processor(self, device_name, event, recipe_case_id):
        filtered_event = self._gen_filtered_event(event.name, event.location, event.attribs, event.timestamp, event.origin)
        to_processor_iterator = util.gen_event_iterator(filtered_event)

        direct_cache = util.get_direct_cache()
        hostname = direct_cache.hget(device_name, 'ip')
        metadata=[('caseid', json.dumps(recipe_case_id))]
        _, response = util.call_other_postman(hostname, 'FilteredEvent', to_processor_iterator, metadata=metadata)
        return response

    # def _to_egress(self, device_name, event):
    #     self.egress.forward_filtered_event(device_name, filtered_event)

class Mapper(object):
    def __init__(self):
        self.activating_recipe = {}

        self.active_recipe = [] # recipe_key --> active recipe
        self.processor_info_map = {}
        self.processor_recipe_map = {} # device_name --> recipe_list

        self.recipe_processor_turn = {} # recipe_name --> device_list

        # self.forward_recipe = [] # recipe_key --> to-forward recipe
        # self.forward_name = {} # recipe_name --> device_name

        self.identifier_map = {} # identifier --> condition_str --> condition
        self.refer_map = {} # identifier --> condition_str --> referring_recipe_name

    def activate(self, key, recipe):
        if key in self.activating_recipe.keys():
            self.deactivate(key)
        self.activating_recipe[key] = recipe
        self.recipe_processor_turn[key] = PrioritizedRoundRobin(better_func=self.rrb_better_func, min_level_func=self.rrb_min_level_func)
        for case in recipe.cases:
            for precondition in case.preconditions:
                # active identifier in mapper if not active yet
                self.combine_precondition(precondition, key)
        logging.info('MAPPER-ACTIVATE: new:{0} map:{1}'.format(key, self.identifier_map))

    def lay_off_processor(self, device_name):
        if device_name in self.processor_recipe_map.keys():
            recipes = self.processor_recipe_map[device_name]
            for recipe in recipes:
                self.recipe_processor_turn[recipe].move_to_lowest(device_name)

    def forwarder_report(self, recipe, device_name, success):
        if success:
            self.recipe_processor_turn[recipe].success_report(device_name)
        else:
            self.recipe_processor_turn[recipe].fail_report(device_name)
        logging.warning('MAPPER-FORWARD: {0} report for {1} - {2}'.format(device_name, recipe, success))

    def rrb_better_func(self, main_name, cmp_name):
        return True

    def rrb_min_level_func(self, cmp_name):
        return 0

    def deactivate(self, key):
        try:
            del self.activating_recipe[key]
            del self.recipe_processor_turn[key]
            if key in self.active_recipe:
                self.active_recipe.remove(key)

            to_delete = []
            for identifier, conditions in self.refer_map.items():
                for condition, keylist in conditions.items():
                    # if this key is referring, remove reference
                    if key in keylist:
                        to_delete.append((identifier, condition))

            for (identifier, condition) in to_delete:
                # remove reference
                self.refer_map[identifier][condition].remove(key)
                # if no more reference on this condition, deactive condition
                if len(self.refer_map[identifier][condition]) == 0:
                    del self.refer_map[identifier][condition]
                    del self.identifier_map[identifier][condition]
                # if no more reference on this identifier, deactive identifier
                if len(self.refer_map[identifier]) == 0:
                    del self.refer_map[identifier]
                    del self.identifier_map[identifier]

            logging.warning('MAPPER-DEACTIVATE: recipe:{0}'.format(key, self.identifier_map))
        except KeyError:
            print('cannot deactive')
            pass

    def processor_adv_in(self, adv, ip, interface):
        device_name = adv['name']
        if device_name != NODE_NAME: # not self-adv
            spec_score = adv["spec"]
            active_score = adv["score"]
            recipes =  adv['namelist']
            info  = ProcessorInfo(spec_score, recipes, active_score, ip)
            self.processor_info_map[device_name] = info
            if device_name in self.processor_recipe_map: # existing device
                removed, added = util.get_removed_added(self.processor_recipe_map[device_name], recipes)
                for recipe in removed:
                    if recipe in self.processor_recipe_map[device_name]:
                        self.processor_recipe_map[device_name].remove(recipe)
                    self.recipe_processor_turn[recipe].remove(device_name)
                for recipe in added:
                    if recipe not in self.recipe_processor_turn: # recipe never exists
                        self.recipe_processor_turn[recipe] = PrioritizedRoundRobin(better_func=self.rrb_better_func, min_level_func=self.rrb_min_level_func)
                    self.processor_recipe_map[device_name].append(recipe)
                    self.recipe_processor_turn[recipe].insert(device_name)
                if len(removed) > 0 or len(added) > 0:
                    print('MAPPER-EXIST: device:{0} removed:{1} added:{2}'.format(device_name, removed, added))
            else: # new device
                self.processor_recipe_map[device_name] = recipes
                for recipe in recipes:
                    if recipe not in self.recipe_processor_turn: # recipe never exists
                        self.recipe_processor_turn[recipe] = PrioritizedRoundRobin(better_func=self.rrb_better_func, min_level_func=self.rrb_min_level_func)
                    self.recipe_processor_turn[recipe].insert(device_name)
                    print('MAPPER-RRB: recipe:{0} devices:{1}'.format(recipe, self.recipe_processor_turn[recipe].get_list()))
                print('MAPPER-NEW: device:{0} recipes:{1}'.format(device_name, recipes))
            self.keep_strict(device_name, ip, interface)

            logging.info('MAPPER-UPDATE: device:{0} recipes:{1}'.format(device_name, recipes))
        else:
            self.active_recipe = adv['namelist']

    def keep_strict(self, device_name, ip, interface):
        direct_cache = util.get_direct_cache()
        if device_name not in direct_cache.keys():
            logging.warning('KEEPER-CACHE: not found {0}'.format(device_name))
            InterKeeper.init_strict_blank(device_name, ip, interface.name)
        else:
            logging.info("KEEPER-CACHE: strict:{0}".format(device_name))
            prev_info = direct_cache.hgetall(device_name)
            prev_info["strict"] = ""
            direct_cache.hmset(device_name, prev_info)




    def is_active(self, key):
        return key in self.active_recipe

    def combine_precondition(self, precondition, key):
        # activate identifier
        if precondition.identifier not in self.identifier_map.keys():
            self.identifier_map[precondition.identifier] = {}
            self.refer_map[precondition.identifier] = {}

        map_id = self.identifier_map[precondition.identifier]
        map_refer = self.refer_map[precondition.identifier]
        for and_condition in precondition.and_conditions:
            for condition in and_condition.conditions:
                ## recipe refer this condition
                # active condition in mapper if not active yet, else no change to identifier_map but add reference key
                if condition.condition_str not in map_id.keys():
                    self.identifier_map[precondition.identifier][condition.condition_str] = condition
                    self.refer_map[precondition.identifier][condition.condition_str] = [key]
                else:
                    self.refer_map[precondition.identifier][condition.condition_str].append(key)

    def valid_id_list(self, event):
        valid_id_list = {}
        for identifier in event.identifier:
            self.add_mapping_valid_id(event, identifier, valid_id_list)
        return valid_id_list

    def add_mapping_valid_id(self, event, identifier, valid_id_list):
        if identifier in self.identifier_map:
            valid_id_list[identifier] = []
            for condition_key in self.identifier_map[identifier]:
                condition = self.identifier_map[identifier][condition_key]
                if condition.check(event):
                    valid_id_list[identifier].append(condition.condition_str)

    def assign(self, event):
        valid_id_list = self.valid_id_list(event)
        if len(valid_id_list) == 0:
            logging.warning('MAPPER-ASSIGN: filter_drop:{0}'.format(event.name))
            return None
        egress_fwd = {}
        processor_fwd = {}
        seq_processor_fwd = {}
        seq_egress_fwd = {}
        previous_assignment = {}
        empty_assignment = {}

        for key, recipe in self.activating_recipe.items():
            replication_number = self._replication_number(recipe)
            recipe_case_id_list, seq_recipe_case_id_list = self.recipe_case_id_list(event, recipe.cases, valid_id_list)
            if len(recipe_case_id_list) == 0 and len(seq_recipe_case_id_list) == 0:
                # not relevant
                continue
            selected_device = self._assign(event, key, recipe_case_id_list, seq_recipe_case_id_list, processor_fwd, egress_fwd, seq_processor_fwd, seq_egress_fwd, replication_number)
            previous_assignment[key] = selected_device
            if len(selected_device) == 0:
                empty_assignment[key] = recipe_case_id_list
        logging.info('MAPPER-ASSIGN: processor_fwd:{0} egress_fwd:{1}'.format(processor_fwd, egress_fwd))
        logging.info('MAPPER-ASSIGN: seq_processor_fwd:{0} seq_egress_fwd:{1}'.format(seq_processor_fwd, seq_egress_fwd))
        return (processor_fwd, egress_fwd, seq_processor_fwd, seq_egress_fwd, previous_assignment, empty_assignment)

    def reassign(self, event, failed_recipes, recipe_case_id_list, previous_assignment):
        egress_fwd = {}
        processor_fwd = {}

        empty_assignment = {}
        while len(failed_recipes) > 0:
            key = failed_recipes.pop()
            selected_device = previous_assignment[key]
            if len(selected_device) > 0: # else never be assigned, never mind
                replication_number = failed_recipes.count(key)
                self._assign(event, key, recipe_case_id_list[key], [], processor_fwd, egress_fwd, {}, {}, replication_number, selected_device=selected_device)
            # remove all key from failed recipe list
            else:
                empty_assignment[key] = recipe_case_id_list[key]
            while key in failed_recipes:
                failed_recipes.remove(key)
        logging.info('MAPPER-REASSIGN: processor_fwd:{0}'.format(processor_fwd))
        logging.info('MAPPER-REASSIGN: egress_fwd:{0}'.format(egress_fwd))
        return processor_fwd, egress_fwd, empty_assignment


    def _assign(self, event, key, recipe_case_id_list, seq_recipe_case_id_list, processor_fwd, egress_fwd, seq_processor_fwd, seq_egress_fwd, replication_number, selected_device=None):
        if not selected_device:
            selected_device = []

        if len(recipe_case_id_list) > 0:
            if key in self.active_recipe:
                if None not in selected_device:
                    processor_fwd[key] = recipe_case_id_list
                    selected_device.append(None)
                    replication_number -= 1

            while replication_number > 0:
                device_name = self.get_forwarder(key, selected_device)
                if device_name is None: # no node to forward
                    logging.warning('MAPPER-ASSIGN: no more node to forward: {0}'.format(self.recipe_processor_turn[key].get_list()))
                    break

                if device_name not in egress_fwd:
                    egress_fwd[device_name] = {}
                egress_fwd[device_name][key] = recipe_case_id_list
                selected_device.append(device_name)
                replication_number -= 1

        if len(seq_recipe_case_id_list) > 0: # assign to all
            if key in self.active_recipe:
                seq_processor_fwd[key] = seq_recipe_case_id_list
            device_list = self.recipe_processor_turn[key].get_list()
            for device_name in device_list:
                if device_name not in seq_egress_fwd.keys():
                    seq_egress_fwd[device_name] = {}
                seq_egress_fwd[device_name][key] = seq_recipe_case_id_list
        return selected_device

    def first_check_valid_identifier(self, name, location, origin):
        if not self.valid_identifier("{0}__".format(name)) and \
        not self.valid_identifier("{0}_{1}_".format(name, location)) and \
        not self.valid_identifier("{0}__{1}".format(name, origin)) and \
        not self.valid_identifier("{0}_{1}_{2}".format(name, location, origin)):
            return False
        return True

    def valid_identifier(self, identifier):
        return identifier in self.identifier_map

    def recipe_case_id_list(self, event, cases, valid_id_list):
        recipe_case_id_list = []
        seq_recipe_case_id_list = []
        case_count = 0
        for case in cases:
            for precondition in case.preconditions:
                self._check_and_append_valid_case_id(case_count, precondition, recipe_case_id_list, seq_recipe_case_id_list, valid_id_list)
            case_count = case_count + 1
        return recipe_case_id_list, seq_recipe_case_id_list

    def _check_and_append_valid_case_id(self, case, precondition, recipe_case_id_list, seq_recipe_case_id_list, valid_id_list):
        if precondition.identifier not in valid_id_list.keys():
            return None
        if precondition.check_validity(valid_id_list[precondition.identifier]):
            case_id = util._case_id(case, precondition.name)
            if util.is_seq_id(precondition.name):
                related_list = seq_recipe_case_id_list
            else:
                related_list = recipe_case_id_list

            if case_id not in related_list:
                related_list.append(case_id)

    def _replication_number(self, recipe):
        return int(max(1, math.ceil(recipe.reliability * MAX_REPLICATION)))

    def get_forwarder(self, key, selected_devices): #RRB
        turn_success, device_name = self.recipe_processor_turn[key].get_and_update_turn(skiplist=selected_devices)
        if turn_success:
            return device_name
        else:
            return None

    # def get_forwarder_from_best_value(self, key, selected_devices):
    #     max_search = 5
    #     round = 1
    #     best_device_info = None
    #     best_device = None
    #     max_value = -2
    #     device_list = self.recipe_processor_turn[key].get_list()
    #     device_list = [x for x in device_list if x not in selected_devices]
    #     logging.info('MAPPER-FORWARDER: list:{0}'.format(device_list))
    #     for key in device_list:
    #         if round == max_search:
    #             break
    #         round += 1
    #         if key in self.processor_info_map:
    #             info = self.processor_info_map[key]
    #             if best_device is None or ProcessorInfo.better_newinfo(best_device_info, info):
    #                 best_device_info = info
    #                 best_device = key
    #         else: # info not exist
    #             self.delete_processor(key)
    #     if best_device:
    #         logging.info('MAPPER-FORWARDER: device:{0} score:{1}'.format(best_device, best_device_info.active_score))
    #     return best_device
