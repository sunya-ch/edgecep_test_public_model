from common.util import util
import json
import logging


class Synchronizer():
    def __init__(self, egress, grpc_client):
        self.egress = egress
        self.grpc_client = grpc_client

    def grpc_perform(self, request, id):
        api = request.api
        op = request.op
        detail = json.loads(request.detail)
        hashcode = request.hash
        timestamp = request.timestamp
        ip = id
        interface = ""
        self._perform(api, op, detail, hashcode, timestamp, ip, interface)

    def rest_perform(self, api, content_obj, interface_name, fromaddr):
        op = content_obj['op']
        detail = content_obj['detail']
        hashcode = content_obj['hash']
        timestamp = content_obj['timestamp']
        self._perform(api, op, detail, hashcode, timestamp, fromaddr, interface_name)

    def _perform(self, api, op, detail, hashcode, timestamp, ip, interface):
        logging.info('SYNCHRONIZER: api:{0} op:{1}'.format(api, op))
        if api == 'RECIPE':
            db = util.get_recipe()
        elif api == 'FUNCTION':
            db = util.get_function()
        elif api == 'ACTOR':
            db = util.get_actor()
        else:
            return False, "unknown api"

        if op == 'ADD':
            self._add(api, db, detail, hashcode)
        elif op == 'REPLACE':
            self._replace(api, db, detail, hashcode)
        elif op == 'REVOKE':
            self._revoke(api, db, detail)
        else:
            return False, "unknown op"

        if self.grpc_client.exists('COORDINATOR'):
            name = detail['meta-data']['name']
            self.grpc_client.call_command_in(api, name, op, detail, hashcode, timestamp, ip, interface)

    def collect_file_chunk(self, detail):
        hash = detail['hash']
        seq = int(detail['seq'])
        total = int(detail['total'])
        content = detail['content']
        return False, ""

    def _add(self, api, db, detail, hashcode):
        name = detail['meta-data']['name']
        if name in db.keys():
            return False, "duplicated name: {0}".format(name)
        return self._replace(api, db, detail, hashcode)

    def _revoke(self, api, db, detail):
        name = detail['meta-data']['name']
        db.delete(name)
        if api != 'actor':
            self.grpc_client.sync_function_recipe(api, name, False)
        return True, "{0} revoked".format(name)

    def _replace(self, api, db, detail, hashcode):
        name = detail['meta-data']['name']
        new_obj = util.obj_dumps(detail, hashcode) # dump and add hashcode ['hash'] key
        if api == 'RECIPE':
            # update whether the recipe is required for being processed
            self._update_requirement(new_obj)
        db.hmset(name, new_obj)
        if api != 'ACTOR':
            self.grpc_client.sync_function_recipe(api, name, True)
        return True, "new {0}".format(name)


    def _update_requirement(self, recipe_obj):
        if 'act' in recipe_obj.keys():
            recipe_obj['required'] = 'True'
            success = self._update_dependent_requirement(recipe_obj)
            return success
        else:
            recipe_obj['required'] = 'False'
            return True


    def _update_dependent_requirement(self, recipe_obj):
        try:
            if "content" in recipe_obj.keys():
                content_arr = json.loads(recipe_obj["content"])
                for content in content_arr:
                    for _,input in content["input"].items():
                        recipe_name = input["identifier"]["event"]
                        dependent_recipe = util.get_recipe().hgetall(recipe_name)
                        if dependent_recipe['metadata.type'] == 'static':
                            continue
                        if dependent_recipe['required'] == 'False':
                            self._activate_recipe(recipe_name)
                            if not self._update_dependent_requirement(dependent_recipe):
                                return False
            return True
        except:
            return False

    def _activate_recipe(self, recipe_name):
        recipe = util.get_recipe()
        info = recipe.hgetall(recipe_name)
        info['required'] = 'True'
        recipe.hmset(recipe_name, info)
