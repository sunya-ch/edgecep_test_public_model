import json
import os
from common.util import util

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

class TokenHandler():
    def __init__(self):
        # pk sk
        pass

    def signed_token(self, recipe):
        token_from_db = util.pop_token(recipe)
        if token_from_db is not None:
            msg = json.dumps()
            token_obj = {'id': NODE_NAME, 'pk': None, 'token': cipher_encode(msg)}
            # TO-DO: certified before sending
            return json.dumps(token_obj)
        return None

    def cipher_encode(self, msg):
        return msg



PAYMENT_INDEX  = ['ORIGIN', 'FORWARD', 'PROCESS']
PRICE = 100
PROCESSOR_RATIO = 0.5
ORIGIN_RATIO = 0.3
FORWARD_RATIO = 0.2
TRUSTWORTHY_DICT = {}


FORWARD_TOTAL = 0
ORIGIN_TOTAL = 0
COST_TOTAL = 0
PAYMENT_LIST = {}

import math

def probe_for_invoice(recipe):
    msg = 'TKREQ {0}'.format(recipe)
    tokenlist = wait_for_('TKREP ')
    left_token_dict, token_dict = self.verify_token(recipe, tokenlist)

def verify_token(recipe, tokenlist):
    start_list = []
    token_dict = {}
    for token_str in tokenlist:
         token_outer = json.loads(token_str)
         id = token_outer['id']
         decoded_msg = cipher_decode(pk, token_outer['token'])
         if decoded_msg != None:
             token = json.loads(decoded_msg)
             token_dict[id] = token
             if len(token['ACT']) >0:
                 if token_outer['pk'] in TRUSTWORTHY_DICT.keys():
                     start_list.append(id)
    for id in start_list:
        act_token = token_dict[id]['ACT']
        for device, num in act_token.items():
            PAYMENT_LIST = {}
            FORWARD_TOTAL = 0
            ORIGIN_TOTAL = 0
            output_num = int(num)
            try:
                process_num = int(token_dict[id]['PROCESS'][device])
                validate, ratio = validate_process_value(recipe, process_num, output_num)
                if not validate:
                    continue
                cross_check_process_num = token_dict[device]['PROCESS'][id]
                prepare_payment(device, 'PROCESS', process_num) #add only one time per payment calculation
                if process_num != cross_check_process_num:
                    print('warning process number detected from actor is not equal to that from processor ({0}, {1})'.format(process_num, cross_check_process_num))
                COST_TOTAL = PRICE * verified_process_value / ratio
                pay()
            except:
                # cannot verified
                continue
    return left_token_dict, token_dict

def verify_recv_and_origin_token(start_id):
    recv_token = token_dict[start_id]['RECV']
    verify_recv_token(start_id, recv_token)
    origin_token = token_dict[start_id]['ORIGIN']
    verify_origin_token(start_id, origin_token)


def verify_recv_token(start_id, recv_token):
    for device, num in recv_token.items():
        recv_num = int(num)
        try:
            cross_check_recv_num = token_dict[device]['FORWARD'][start_id]
            if device == start_id:
                print('warning cannot forward from itself: {0}'.format(device))
                continue
            verified_value = math.min(recv_num, cross_check_recv_num)
            prepare_payment(device, 'FORWARD', verified_value)
            verify_recv_and_origin_token(device)
        except:
            # cannot verified
            continue

def verify_origin_token(start_id, origin_token):
    for device, num in recv_token.items():
        origin_num = int(num)
        try:
            cross_check_origin_num = token_dict[device]['ORIGIN'][start_id]
            verified_value = math.min(origin_num, cross_check_origin_num)
            prepare_payment(device, 'ORIGIN', verified_value)
        except:
            # cannot verified
            continue


def validate_overprocessed(recipe, process_num, output_num):
    process_per_output = process_num/output_num #check overprocessed processor
    return True, process_per_output

def cipher_decode(pk, content):
    # verified with pk and decode with self sk
    return content


def prepare_payment(device, type, value):
    index = PAYMENT_INDEX.index(type)
    if device not in PAYMENT_LIST:
        PAYMENT_LIST[device] = [0, 0, 0]
    PAYMENT_LIST[device][index] += value
    if index == 0:
        ORIGIN_TOTAL += value
    if index == 1:
        FORWARD_TOTAL += value

def pay():
    for device, [origin, forward, process] in PAYMENT_LIST.items():
        process_cost = 0 if process == 0 else COST_TOTAL * PROCESSOR_RATIO
        forward_cost = forward / FORWARD_TOTAL * COST_TOTAL * FORWARD_RATIO
        origin_cost = origin / ORIGIN_TATAL * ORIGIN_TOTAL * ORIGIN_RATIO
        total_payment = process_cost + forward_cost + origin_cost
        transaction('pay', total_payment, device)

def transaction(op, amount, to):
    print('{0} {1} to {2}'.format(op, amount, to))
