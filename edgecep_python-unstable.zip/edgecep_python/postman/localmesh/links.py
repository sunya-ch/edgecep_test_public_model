import threading

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

from time import sleep
from random import randint
from collections import defaultdict

import select
from socket import socket, AF_INET, SOCK_DGRAM, SOCK_STREAM, SOL_SOCKET, SO_REUSEADDR, SO_BROADCAST

try:
    # needed for BSD systems like macOS
    from socket import SO_REUSEPORT
    IS_BSD = True
except:
    # not needed on non-BSD systems (e.g. linux)
    IS_BSD = False

import netifaces as ni

class VirtualLink:
    """A Link represents a network link between Nodes.
    Nodes.interfaces is a list of the [Link]s that it's connected to.
    Some links are BROADCAST (all connected nodes get a copy of all packets),
    others are UNICAST (you only see packets directed to you), or
    MULTICAST (you can send packets to several people at once).
    Some links are virtual, others actually send the traffic over UDP or IRC.
    Give two nodes the same VirtualLink() object to simulate connecting them with a cable."""
    broadcast_addr = "00:00:00:00:00:00:00"

    def __init__(self, name="vlan1", ip="127.0.0.1"):
        self.name = name
        self.ip = ip
        self.keep_listening = True
        # buffer for receiving incoming packets
        self.inq = defaultdict(Queue)  # mac_addr: [packet1, packet2, ...]
        self.inq[self.broadcast_addr] = Queue()

    ### Utilities

    def __repr__(self):
        return "<%s>" % self.name

    def __str__(self):
        return self.__repr__()

    def __len__(self):
        """number of nodes listening for packets on this link"""
        return len(self.inq)

    def log(self, *args):
        """stdout and stderr for the link"""
        print("%s %s" % (str(self).ljust(8), " ".join([str(x) for x in args])))

    ### Runloop

    def start(self):
        """all links need to have a start() method because threaded ones use it start their runloops"""
        self.log("ready.")
        return True

    def stop(self):
        """all links also need stop() to stop their runloops"""
        self.keep_listening = False
        # if threaded, kill threads before going down
        if hasattr(self, 'join'):
            self.join()
        self.log("Went down.")
        return True

    ### IO

    def recv(self, mac_addr=None, timeout=0):
        """read packet off the recv queue for a given address, optional timeout to block and wait for packet"""
        # recv on the broadcast address "00:..:00" will give you all packets (for promiscuous mode)
        if mac_addr == None:
            mac_addr = self.broadcast_addr
        if self.keep_listening:
            try:
                return self.inq[str(mac_addr)].get(timeout=timeout)
            except Empty:
                return "", ""
        else:
            self.log("is down.")

    def send(self, packet, mac_addr=None, port=None):
        """place sent packets directly into the reciever's queues (as if they are connected by wire)"""
        if mac_addr == None:
            mac_addr = self.broadcast_addr
        if self.keep_listening:
            if mac_addr == self.broadcast_addr:
                for addr, recv_queue in self.inq.items():
                    recv_queue.put(packet)
            else: # include itself
                self.inq[mac_addr].put(packet)
                self.inq[self.broadcast_addr].put(packet)
        else:
            self.log("is down.")


class UDPLink(threading.Thread, VirtualLink):
    """This link sends all traffic as BROADCAST UDP packets on all physical ifaces.
    Connect nodes on two different laptops to a UDPLink() with the same port and they will talk over wifi or ethernet.
    """

    def __init__(self, name, ip="127.0.0.1", port=2016, broadcast_ip='255.255.255.255'):
        # UDPLinks have to be run in a seperate thread
        # they rely on the infinite run() loop to read packets out of the socket, which would block the main thread
        threading.Thread.__init__(self)
        VirtualLink.__init__(self, name=name, ip=ip)
        self.port = port
        # self.log("starting...")
        self.broadcast_addr = broadcast_ip
        self._initsocket()

    def __repr__(self):
        return "<" + self.name + ">"

    def _initsocket(self):
        """bind to the datagram socket (UDP), and enable BROADCAST mode"""
        self.send_socket = socket(AF_INET, SOCK_DGRAM)
        self.send_socket.setblocking(0)
        self.send_socket.setsockopt(SOL_SOCKET, SO_BROADCAST, 1)

        self.recv_socket = socket(AF_INET, SOCK_DGRAM)
        self.recv_socket.setblocking(0)
        if IS_BSD:
            self.recv_socket.setsockopt(SOL_SOCKET, SO_REUSEPORT, 1)  # requires sudo
        self.recv_socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)  # allows multiple UDPLinks to all listen for UDP packets
        self.recv_socket.bind((self.ip, self.port))

        self.broadcast_recv_socket = socket(AF_INET, SOCK_DGRAM)
        self.broadcast_recv_socket.setblocking(0)
        if IS_BSD:
            self.broadcast_recv_socket.setsockopt(SOL_SOCKET, SO_REUSEPORT, 1)  # requires sudo
        self.broadcast_recv_socket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)  # allows multiple UDPLinks to all listen for UDP packets
        self.broadcast_recv_socket.bind((self.broadcast_addr, self.port))

    @staticmethod
    def get_available_ip_interfaces(recv_port, suppress_kw=None):
        interfaces = ni.interfaces()
        links = []
        for ifname in interfaces:
            content = ni.ifaddresses(ifname)
            if AF_INET in content and 'addr' in content[AF_INET][0] and 'broadcast' in content[AF_INET][0]:
                ip = content[AF_INET][0]['addr']
                broadcast_ip = content[AF_INET][0]['broadcast']
                suppressed = False
                if suppress_kw:
                    for kw in suppress_kw:
                        if kw in ifname:
                            suppressed = True
                if not suppressed:
                    links.append(UDPLink(name=ifname, ip=ip, port=recv_port,broadcast_ip=broadcast_ip))
        return links

    ### Runloop

    def run(self):
        """runloop that reads incoming packets off the interface into the inq buffer"""
        # self.log("ready to receive.")
        # we use a runloop instead of synchronous recv so stopping the node mid-recv is possible
        read_ready = None
        while self.keep_listening:
            try:
                read_ready, w, x = select.select([self.recv_socket, self.broadcast_recv_socket], [], [], 0.01)
            except Exception:
                # print(" catch timeouts ")
                pass

            if read_ready:
                packet, addr = read_ready[0].recvfrom(4096) # receive packet from [ip: port]
                if addr[0] != self.ip:
                    for mac_addr, recv_queue in self.inq.items():
                        recv_queue.put([packet, addr[0]])  # put packet in node's recv queue


    ### IO
    def send(self, packet, retry=True, ip=None, port=None):
        """send a packet down the line to the inteface"""

        if ip == None:
            ip = self.broadcast_addr
        if port == None:
            port = self.port
        addr = (ip, port)  # 255. is the broadcast IP for UDP
        # print('sending ... {0} to {1}:{2}'.format(packet, ip, port))
        try: # donot include itself
            self.send_socket.sendto(packet, addr)
        except Exception as e:
            self.log("Link failed to send packet over socket %s" % e)
            sleep(0.2)
            if retry:
                self.send(packet, retry=False)
