import json

import threading
import time

from common.util import util

# import datetime
#
# from datetime import timedelta as td
import os

import logging

import numpy as np


STRICT_PERIOD = int(os.environ['STRICT_PERIOD'])
LOOSE_PERIOD = int(os.environ['LOOSE_PERIOD'])
MAX_PING = int(os.environ['MAX_PING'])

class KeeperLoop(threading.Thread):
    def __init__(self, time, strict_condition, need_send_hey, egress):
        threading.Thread.__init__(self)
        self.time = time
        self.time_in_milli = time * 1000
        self.strict_condition = strict_condition
        self.need_send_hey = need_send_hey
        self.egress = egress

    def run(self):
        # print('Keeper Loop start listening (refresh every {0}ms)'.format(self.time_in_milli))
        while True:
            # There will be a first greet
            time.sleep(self.time)

            if self.need_send_hey: # HEY
                self.send_hey()
            else: # PING
                direct_cache = util.get_direct_cache()
                names = []
                devicelist = []
                for device_name in direct_cache.keys():
                    info = direct_cache.hgetall(device_name)
                    if info["strict"] != self.strict_condition:
                        continue
                    devicelist.append((device_name, info))
                    names.append(device_name)
                if len(names) == 0:
                    continue
                outdate_cache = util.get_outdate_cache()
                memo_cache = util.get_memo_cache()
                ping_time = str(util.current_timestamp())

                for key in memo_cache.keys():
                    # devices require ping update and already ping
                    seq = int(memo_cache.get(key)) + 1 # increase sequence
                    if seq > MAX_PING:
                        delete_outdate(key)
                        continue
                    device_name, ip, interface = key.split("_")
                    self.call_ping(ip, interface, seq)
                    memo_cache.set(key, seq)
                    prev_key = "{0}/{1}".format(key, seq-1) # previous key in outdate_cache
                    key_seq = "{0}/{1}".format(key, seq) # new key for outdate_cache
                    info = outdate_cache.hgetall(prev_key) # refer to previous key
                    info["ping_send_time"] = ping_time # add new ping time
                    outdate_cache.hmset(key_seq, info)
                for device_name, info in devicelist:
                    # device newly require ping
                    if info["strict"] != self.strict_condition:
                        continue #not related
                    now = util.current_timestamp()

                    timediff = time_different(info["last_seen"], now)
                    if(timediff > self.time_in_milli):
                        # add ping time --> Move from direct to outdate/memo --> call ping
                        info["ping_send_time"] = ping_time
                        seq = 1
                        ip = info["ip"]
                        interface = info["interface"]
                        memo_key = util._memo_key(device_name, ip, interface)
                        memo_cache.set(memo_key, seq) # add new key
                        key_seq = "{0}/{1}".format(memo_key, seq)
                        outdate_cache.hmset(key_seq, info)
                        self.call_ping(ip, interface, seq)

    def call_ping(self, ip, interface, seq):
        self.egress.ping(ip, interface, seq)

    def is_no_one_around(self):
        direct_cache = util.get_direct_cache()
        memo_cache = util.get_memo_cache()
        return len(direct_cache.keys()) == 0 and len(memo_cache.keys()) == 0

    def send_hey(self):
        self.egress.hey()



class InterKeeper():
    @staticmethod
    def run_keeper_loop(egress):
        KeeperLoop(STRICT_PERIOD, "strict", False, egress).start()
        KeeperLoop(LOOSE_PERIOD, "loose", True, egress).start()

    @staticmethod
    def update_from_hello(hello_str, ip, interface, key):
        new_info = json.loads(hello_str)
        new_info["last_seen"] = str(util.current_timestamp())
        transmit_time = time_different(new_info["time"],new_info["last_seen"])
        new_info["transmit_time"] = str(transmit_time)
        new_info["ip"] = ip
        new_info["interface"] = interface

        # update direct cache
        direct_cache = util.get_direct_cache()
        if direct_cache.exists(key):
            info = direct_cache.hgetall(key)
            new_info["first_seen"] = info["first_seen"]
            new_info["seen_count"] = str(int(info["seen_count"])+1)
            time_pass = time_different(new_info["first_seen"], new_info["last_seen"])
            new_info["seen_index"] = str(float(new_info["seen_count"])/time_pass)
            direct_cache.hmset(key, new_info)
            return None

        new_info["first_seen"] = new_info["last_seen"]
        new_info["seen_count"] = '1'
        new_info["seen_index"] = '-1'
        new_info["strict"] = "loose"
        logging.info('KEEPER-UPDATE-HELLO: info:{0}'.format(new_info))
        direct_cache.hmset(key, new_info)

        # # update indirect cache
        # new_indirect = jsonobj["indirect"]
        # indirect_cache = util.get_indirect_cache()
        # for indirect in new_indirect:
        #     indirect_key = indirect["name"]
        #     indirect_str = json.dumps(new_indirect)
        #     indirect_cache.hset(indirect_key, key, indirect_str)

    @staticmethod
    def update_from_pong(device_name, ip, interface, seq):
        memo_key = util._memo_key(device_name, ip, interface)
        key = "{0}/{1}".format(memo_key, seq)
        outdate_cache = util.get_outdate_cache()
        direct_cache = util.get_direct_cache()
        if not outdate_cache.exists(key):
           ## already removed
           return None

        last_seen = util.current_timestamp()

        info = outdate_cache.hgetall(key)
        info["last_seen"] = str(last_seen)
        info["seen_count"] = str(int(info["seen_count"])+1)
        time_pass = time_different(info["first_seen"], info["last_seen"])
        info["seen_index"] = str(float(info["seen_count"])/time_pass)
        ping_send_time = info["ping_send_time"]
        transmit_time = time_different(ping_send_time, last_seen)
        info["transmit_time"] = str(transmit_time)

        del info["ping_send_time"]
        logging.info('KEEPER-UPDATE-PONG: info:{0}'.format(info))
        direct_cache.hmset(info["name"], info)
        delete_outdate(key.split("/")[0])


    @staticmethod
    def init_strict_blank(device_name, ip, interface):
        new_info = {'name': device_name, 'mac': '', 'time': ''}
        new_info["last_seen"] = str(util.current_timestamp())
        new_info["transmit_time"] = '-1'
        new_info["ip"] = ip
        new_info["interface"] = interface

        new_info["first_seen"] = new_info["last_seen"]
        new_info["seen_count"] = '1'
        new_info["seen_index"] = '-1'
        new_info["strict"] = "strict"
        logging.info('KEEPER-UPDATE-BLANK: info:{0}'.format(new_info))
        direct_cache = util.get_direct_cache()
        direct_cache.hmset(device_name, new_info)

def time_different(start, end):
    return float(end) - float(start)
#     if not isinstance(start, datetime.datetime):
#         start = str_to_time(start)
#     if not isinstance(end, datetime.datetime):
#         end = str_to_time(end)
#     td = end - start
#     return total_milli(td)
#
# def total_milli(td):
#     return (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10**6) / 10**3
#
# def str_to_time(time_str):
#     return datetime.datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S.%f%z')

def str_to_array(arr_str, dtype):
    return np.fromstring(arr_str.tostring(), dtype)

def delete_outdate(key):
    outdate_cache = util.get_outdate_cache()
    direct_cache = util.get_direct_cache()
    for related_key in outdate_cache.keys(pattern="{0}*".format(key)):
        outdate_cache.delete(related_key)
    util.get_memo_cache().delete(key)
    device_name, _, _ = key.split("_")
    direct_cache.delete(device_name)
    logging.info('KEEPER-DELETE: name:{0}'.format(device_name))
