import sys
sys.path.append(".")
import environ_set
import grpc

from concurrent import futures
import os
import time
import json

from protoc_py import pretrainer_pb2
from protoc_py import pretrainer_pb2_grpc

from google.protobuf import empty_pb2
from protoc_py import common_pb2

from common.util import util
from common.component import Learn, Function


from pretrainer import Pretrainer

import logging
logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

PRETRAINER_PORT = os.environ['PRETRAINER_PORT']

MAX_WORKER = int(os.environ['MAX_WORKER'])

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

class InterPretrainer(pretrainer_pb2_grpc.InterPretrainerServicer):
    def __init__(self):
        self.learn_component = Learn(MAX_WORKER, self._create_pretrainer)

    def Exists(self, request, context):
        return empty_pb2.Empty()

    def LabelIn(self, request, context):
        function_key = request.key
        pretrain_map = self.learn_component.worker_map
        if function_key in pretrain_map.keys():
            pretrain_map[function_key].label_data_in(request.pretrain, request.label, request.id)
        return empty_pb2.Empty()

    def TrainDataIn(self, request_iterator, context):
        context_dict,_ =util._context_dict(context)
        function_key = context_dict['key']
        learner_map = self.learn_component.worker_map
        if function_key in learner_map.keys():
            content_str = util.read_large_msg(request_iterator)
            learner_map[function_key].train_data_in(content_str)
            return common_pb2.ResponseMsg(success=True, msg="")
        else:
            return common_pb2.ResponseMsg(success=False, msg="not active")

    def AdvIn(self, request, context):
        relevant_functions = []
        recipes = json.loads(request.str)
        for recipe in recipes:
            self.check_function_list(recipe, relevant_functions)

        if len(relevant_functions) > 0:
            return common_pb2.ResponseMsg(success=True, msg=json.dumps(relevant_functions))
        else:
            return common_pb2.ResponseMsg(success=False, msg="")

    def check_function_list(self, recipe, relevant_functions):
        content_str = util.get_recipe().hget(recipe, 'content')
        contents = json.loads(content_str)
        for content in contents:
            function = content['process']['function']
            if function not in relevant_functions and function in self.learn_component.worker_map.keys():
                relevant_functions.append(function)

    def SynchronizeAdd(self, request, context):
        self.learn_component.SynchronizeAdd(request, context)
        return empty_pb2.Empty()

    def SynchronizeRevoke(self, request, context):
        self.learn_component.SynchronizeRevoke(request, context)
        return empty_pb2.Empty()

    def Probe(self, request, context):
        if len(self.learn_component.worker_map) == 0:
            adv_str = ""
        else:
            obj = {}
            obj['name'] = NODE_NAME
            obj['type'] = 'pretrainer'
            obj['namelist'] = list(self.learn_component.worker_map.keys())
            adv_str = json.dumps(obj)
        return common_pb2.ResponseMsg(success= (adv_str != ""), msg=adv_str)

    def Subscribe(self, request, context):
        namelist = json.loads(request.name)
        interface_name = request.interface
        ip = request.ip
        id = request.id
        for name in namelist:
            if name in self.learn_component.worker_map.keys():
                self.learn_component.worker_map[name].subscribe(interface_name, ip, id)
        return empty_pb2.Empty()

    def Unsubscribe(self, request, context):
        name = json.loads(request.name)
        id = request.id
        for name in namelist:
            if name in self.learn_component.worker_map.keys():
                self.learn_component.worker_map[name].unsubscribe_from_id(id)
        return empty_pb2.Empty()

    def _create_pretrainer(self, function_key):
        functions = util.get_function()
        function_obj = util.get_function().hgetall(function_key)
        function = Function(function_obj)
        if function.learn is not None:
            pretrainer = Pretrainer(function.name, function.input_name, function.output_name, function.learn)
            pretrainer.start()
            return pretrainer
        else:
            return None

def grpc_start():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    pretrainer_pb2_grpc.add_InterPretrainerServicer_to_server(InterPretrainer(), server)
    server.add_insecure_port('localhost:{0}'.format(PRETRAINER_PORT))
    server.start()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        SERVICE = 'PRETRAINER'
        print('start {0} grpc server'.format(SERVICE))
        util.notify_postman(SERVICE)
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)
        util.notify_postman(SERVICE, active=False)

if __name__ == "__main__":
    while not util.redis_available():
        continue
    grpc_start()
