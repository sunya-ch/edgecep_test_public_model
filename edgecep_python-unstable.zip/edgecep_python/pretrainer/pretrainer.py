import json

from common.util import util
from common.pubsub import PubSubProtocol

from io import BytesIO
import numpy as np
from PIL import Image

import tensorflow as tf
import tensorflow_hub as hub

from protoc_py import common_pb2

try:
    from queue import Queue, Empty
except ImportError:
    from Queue import Queue, Empty

import threading

import logging

import os
NODE_NAME = os.environ['BALENA_DEVICE_UUID']

FAKE_QUANT_OPS = ('FakeQuantWithMinMaxVars',
                  'FakeQuantWithMinMaxVarsPerChannel')

class Pretrainer(threading.Thread):
    def __init__(self, name, input_name, output_name, learn):
        threading.Thread.__init__(self)
        self.name = name
        self.tfhub_module = learn.tfhub_module
        self.try_load_module(self.tfhub_module)
        self.hash_map = {}
        self.label_data = Queue()
        self.LEARNER_pubsub = PubSubProtocol('PretrainData', self.name, svc='LEARNER')

    def try_load_module(self, tfhub_module):
        try:
            self.module_spec = hub.load_module_spec(tfhub_module)
            self.input_height, self.input_width = hub.get_expected_image_size(self.module_spec)
            self.input_depth = hub.get_num_image_channels(self.module_spec)
        except:
            logging.warning('PRETRAINER: cannot load module {0}'.format(self.name))
            self.module_spec = None
        return self.module_spec


    def pretrain(self, input_arr, label, labeler_id):
        arr = np.asarray(input_arr[0], dtype=np.uint8)
        img = Image.fromarray(arr)
        with BytesIO() as output:
            img.save(output, 'jpeg')
            image_data = output.getvalue()
        pretrain_arr = self._pretrain(image_data).tolist()
        self.send_pretrain_data(pretrain_arr, label, labeler_id)

    def train_data_in(self, content_str):
        obj = json.loads(content_str)
        hash = obj['hash']
        provider_id = obj['id']
        self.hash_map[hash] = obj['data'][0]

    def label_data_in(self, pretrain, label, id):
        self.label_data.put((pretrain, label, id))

    def run(self):
        try:
            while True:
                (pretrain, label, id) = self.label_data.get(block=True)
                if self.LEARNER_pubsub.is_empty():
                    # no subscribers just put back
                    self.label_data.put((pretrain, label, id))
                    continue
                if not self.module_spec:
                    if not self.try_load_module(self.tfhub_module):
                        continue
                hash = pretrain
                if hash in self.hash_map.keys():
                    self.pretrain(self.hash_map[hash], label, id)
                    del self.hash_map[hash]
        finally:
            logging.info('PRETRAINER: {0} stop'.format(self.name))

    def subscribe(self, interface_name, ip, id):
        self.LEARNER_pubsub.subscribe(interface_name, ip, id)

    def unsubscribe_from_id(self, id):
        self.LEARNER_pubsub.unsubscribe_from_id(id)


    # def send_pretrain_data(self, pretrain_arr, label): # maybe not need use the same grpc session
    #     content = {'key': self.name, 'pretrain': json.dumps(pretrain_arr), 'label': label, 'id': NODE_NAME}
    #     request = postman_pb2.SimpleMsg(prefix='PretrainData', content=json.dumps(content))
    #     util.call_postman('SimpleBroadcast', request)

    def send_pretrain_data(self, pretrain_arr, label, last_provider):
        content = {'pretrain': list(pretrain_arr), 'label': label, 'id': NODE_NAME}
        if not self.LEARNER_pubsub.is_empty():
            self.LEARNER_pubsub.send_to_subscriber(content)

    def _pretrain(self, image_data):
        graph, bottleneck_tensor, decoded_image_tensor, wants_quantization, jpeg_data_tensor = (self.create_module_graph())
        bottleneck_values = None
        with tf.Session(graph=graph) as sess:
        # Initialize all weights: for the module to their pretrained values,
        # and for the newly added retraining layer to random initial values.
            init = tf.global_variables_initializer()
            sess.run(init)
            bottleneck_values = self.run_bottleneck_on_image(sess, image_data, jpeg_data_tensor,
                                                            bottleneck_tensor)
        return bottleneck_values

    def create_module_graph(self):
        with tf.Graph().as_default() as graph:
            jpeg_data_tensor, decoded_image_tensor = self.add_jpeg_decoding()
            m = hub.Module(self.module_spec)
            bottleneck_tensor = m(decoded_image_tensor)
            wants_quantization = any(node.op in FAKE_QUANT_OPS
                                     for node in graph.as_graph_def().node)
        return graph, bottleneck_tensor, decoded_image_tensor, wants_quantization, jpeg_data_tensor

    def add_jpeg_decoding(self):
        jpeg_data_tensor = tf.placeholder(tf.string, name='DecodeInput')
        decoded_image = tf.image.decode_jpeg(jpeg_data_tensor, channels=self.input_depth)
        decoded_image_as_float = tf.image.convert_image_dtype(image=decoded_image, dtype=tf.float32)
        decoded_image_4d = tf.expand_dims(decoded_image_as_float, 0)
        resize_shape = tf.stack([self.input_height, self.input_width])
        resize_shape_as_int = tf.cast(resize_shape, dtype=tf.int32)
        decoded_image_tensor = tf.image.resize_bilinear(decoded_image_4d,
                                               resize_shape_as_int)
        # tf.logging.info("resized type = {0}".format(decoded_image_tensor.dtype))
        return jpeg_data_tensor, decoded_image_tensor


    def run_bottleneck_on_image(self, sess, image_data, image_data_tensor,
                            bottleneck_tensor):

        bottleneck_value = sess.run(bottleneck_tensor,
                                   {image_data_tensor: image_data})

        bottleneck_value = np.squeeze(bottleneck_value)

        return bottleneck_value

    def get_id(self):
        if hasattr(self, '_thread_id'):
            return self._thread_id
        for id, thread in threading._active.items():
            if thread is self:
                return id

    def deactive(self):
        thread_id = self.get_id()
        res = ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id,
              ctypes.py_object(SystemExit))
        if res > 1:
            ctypes.pythonapi.PyThreadState_SetAsyncExc(thread_id, 0)
