from common.util import util

import logging

def light_on(data):
    arrival_time = util.current_timestamp()
    event_time = float(data['timestamp'])
    logging.info('ACTOR-LIGHT: total_time:{0} timestamp:{1} origin:{2}'.format(arrival_time-event_time, event_time, data['origin']))
    print('light on : ', data)
