import sys
sys.path.append(".")
import environ_set

import grpc
from concurrent import futures
import time

from common.util import util
import os
import json


from protoc_py import actor_pb2
from protoc_py import actor_pb2_grpc
from protoc_py import common_pb2


from google.protobuf import empty_pb2

import importlib

import logging
import absl.logging
logging.root.removeHandler(absl.logging._absl_handler)
absl.logging._warn_preinit_stderr = False

logfile = '{0}{1}.log'.format(os.environ['LOG_PATH'], os.path.basename(__file__).split('.')[0])
if os.path.exists(logfile):
    os.remove(logfile)
logging.basicConfig(filename=logfile, filemode='w', format='%(name)s - %(levelname)s - %(message)s', level=logging.INFO)

ACTOR_PORT = os.environ['ACTOR_PORT']
ACTIVE_ACTORS = None if 'ACTIVE_ACTOR' not in os.environ.keys() else os.environ['ACTIVE_ACTOR']

class InterActor(actor_pb2_grpc.InterActorServicer):
    def __init__(self):
        self.available_actor = {}
        self.recipe_act = {} # recipe --> act
        # actors = util.list_names(ACTOR_PATH, 'py')
        # actors.remove('actor')
        actor_list = ACTIVE_ACTORS.split(',')
        for actor in actor_list:
            self.available_actor[actor] = importlib.import_module(actor)
        self.init_actions()
        logging.info('ACTOR-INIT: {0}'.format(self.available_actor))
        self.count = 0

    def Exists(self, request, context):
        return empty_pb2.Empty()

    def init_actions(self):
        recipes = util.get_recipe()
        for recipe in recipes.keys():
            self.new_action(recipe)

    def SynchronizeAdd(self, request, context): # syncmsg
        self.new_action(request.key)
        return empty_pb2.Empty()

    def SynchronizeRevoke(self, request, context): # syncmsg
        if request.key in self.recipe_act:
            del self.recipe_act[request.key]
        return empty_pb2.Empty()

    def new_action(self, recipe):
        actions = []
        act_data = util.get_recipe().hget(recipe, 'act')
        if not not act_data:
            act = json.loads(act_data)[0]
            for actor, function in act.items():
                if actor in self.available_actor.keys():
                    actions.append(getattr(self.available_actor[actor], function))
            if len(actions) > 0:
                self.recipe_act[recipe] = actions


    def AdvIn(self, request, context):
        recipes = json.loads(request.str)
        relevant_recipes = [recipe for recipe in self.recipe_act.keys() if recipe in recipes]
        if len(relevant_recipes) > 0:
            return common_pb2.ResponseMsg(success=True, msg=json.dumps(relevant_recipes))
        else:
            return common_pb2.ResponseMsg(success=False, msg="")

    def Act(self, request_iterator, context):
        msg = util.read_large_msg(request_iterator)
        try:
            obj = json.loads(msg)
            # try:
            recipe = obj['recipe']
            actions = self.recipe_act[recipe]
            for action in actions:
                action(obj['arg'])
            count = obj['count']
            processor = obj['id']
            self.count += 1
            print('count: ', self.count)
            util.increase_N_token('PROCESS', recipe, processor, count)
            util.increase_N_token('ACT', recipe, processor)
            return common_pb2.ResponseMsg(success=True, msg="")
        except:
            logging.warning('ACTOR: FAIL TO RUN ACTION FOR {0} FROM {1}'.format(msg, util._device_name(context)))
            return common_pb2.ResponseMsg(success=False, msg="")

        # except:
        #     logging.warning("fail to run {0} with ({1})".format(obj['recipe'], obj['arg']))
        #     return common_pb2.ResponseMsg(success=False, msg="")


def grpc_start():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=5))
    actor_pb2_grpc.add_InterActorServicer_to_server(InterActor(), server)
    server.add_insecure_port('[::]:{0}'.format(ACTOR_PORT))
    server.start()

    _ONE_DAY_IN_SECONDS = 60 * 60 * 24
    try:
        SERVICE = 'ACTOR'
        logging.info('start {0} grpc server'.format(SERVICE))
        util.notify_postman(SERVICE)
        while True:
            time.sleep(_ONE_DAY_IN_SECONDS)
    except KeyboardInterrupt:
        server.stop(0)
        util.notify_postman(SERVICE, active=False)

if __name__ == "__main__":
    while not util.redis_available():
        continue
    if ACTIVE_ACTORS:
        grpc_start()
