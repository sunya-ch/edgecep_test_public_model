from common.util import util

import logging

def call_police(data):
    arrival_time = util.current_timestamp()
    event_time = float(data['timestamp'])
    logging.info('ACTOR-PHONE: total_time:{0} timestamp:{1} origin:{2}'.format(arrival_time-event_time, event_time, data['origin']))
    print('call police: ', data)
