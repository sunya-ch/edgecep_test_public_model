import os

def make_dir_if_not_exist(path):
    if not os.path.exists(path):
        try:
            os.makedirs(path)
        except FileExistsError:
            pass

def set_if_not_define(env, value):
    if env not in os.environ:
        os.environ[env] = str(value)


#### PORT SET
## INTERNAL PORTs
os.environ['POSTMAN_PORT'] = '50051'
os.environ['PROCESSOR_PORT'] = '50052'

os.environ['PRETRAINER_PORT'] = '50053'
os.environ['LEARNER_PORT'] = '50054'
os.environ['LABELER_PORT'] = '50055'
os.environ['ACTOR_PORT'] = '50056'

os.environ['COORDINATOR_PORT'] = '50057'

## EXTERNAL PORTs
os.environ['RECV_PORT'] = '3030'
os.environ['REDIS_PORT'] = '6379'

#### REDIS DB CODE SET
os.environ['NODE_INFO_DB'] = '1'
os.environ['DIRECT_INFO_DB'] = '2'
os.environ['INDIRECT_INFO_DB'] = '3'
os.environ['OUTDATE_DB'] = '4'
os.environ['OUTDATE_MEMO'] = '5'
os.environ['RECIPE_DB'] = '6'
os.environ['FUNCTION_DB'] = '7'
os.environ['ACTOR_DB'] = '8'
os.environ['ADV_DB'] = '9'

os.environ['INPUT_CACHE'] = '10'

os.environ['ORIGIN_TOKEN'] = '11'
os.environ['FORWARD_TOKEN'] = '12'
os.environ['RECV_TOKEN'] = '13'
os.environ['PROCESS_TOKEN'] = '14'
os.environ['ACT_TOKEN'] = '15'


#### LEARN PATH
os.environ['CHECKPOINT_PATH'] = '/tmp/edgecep/learn_info/checkpoint/'
os.environ['TFLITE_PATH'] = '/tmp/edgecep/learn_info/tflite/'
os.environ['LEARN_TFLITE_PATH'] = '/tmp/edgecep/learn_info/learn_tflite/'

os.environ['DB_PATH'] = '/tmp/edgecep/db/'

pow_resolver = '/etc/resolver/dev'
if os.path.exists(pow_resolver):
    os.remove(pow_resolver)

set_if_not_define('BALENA_DEVICE_UUID', '5883ac44916b11e995f410ddb1c5aa2b')
set_if_not_define('WEIGHT_OF_EXISTANCE', 0) #add opportunity to be selected
set_if_not_define('RESERVED_MEMORY_PERCENT', 0.2)
set_if_not_define('ACCEPTABLE_EFFECT', 2)
set_if_not_define('MAX_WORKER', 3)
set_if_not_define('MAX_REPLICATION', 10)
set_if_not_define('STRICT_PERIOD',20)
set_if_not_define('LOOSE_PERIOD',60)
set_if_not_define('MAX_PING',3)
set_if_not_define('PARTITIONER', 'on_demand')
set_if_not_define('DECOMPOSER', 'on_demand')
set_if_not_define('VIDEO_SAMPLING_TIME', 10)

os.environ['LOG_PATH'] = '/tmp/edgecep/log/{0}_d{1}_p{2}_s{3}/'.format(os.environ['BALENA_DEVICE_UUID'], os.environ['DECOMPOSER'], os.environ['PARTITIONER'], os.environ['VIDEO_SAMPLING_TIME'])

make_dir_if_not_exist(os.environ['CHECKPOINT_PATH'])
make_dir_if_not_exist(os.environ['TFLITE_PATH'])
make_dir_if_not_exist(os.environ['LEARN_TFLITE_PATH'])
make_dir_if_not_exist(os.environ['LOG_PATH'])
make_dir_if_not_exist(os.environ['DB_PATH'])

# ################### For Testing ##################

###### UUID NOTE ####################################
## Earth Darwin Kernel Version 16.7.0 (core i5, 2.9GHz, 16GB, 750GB): 5883ac44916b11e995f410ddb1c5aa2b
## sagittarius Darwin Kernel Version 16.7.0 (core i7, 2.7 GHz, 16GB, 500GB): 7be41b3d1da90dd158702b41039b6f72
## Linux OR78 4.16.0-edison-standard (Genuine Intel(R) 2 core, CPU, 500 MHz, 1GB): a99bdb5e9fce819aa62b6a2da09453d7
## ARMv7 Processor rev 4 (v7l, 2 cores, )

earth = '5883ac44916b11e995f410ddb1c5aa2b'
sagittarius = '7be41b3d1da90dd158702b41039b6f72'
or78 = '2095d4fac0cde3b176b586d8402bb2cf'
isot = 'a96e3abe615160c11a2dfd665fbff0bb'
iszb = 'af6dffb67ddf3aadfc9de3facd7ef37e'
ivmh = 'be18fc6684f02b2cb5f4c88a1852946b'
isuk = '3dddc514d0113800337789e7db4dadc1'
opxv = '318355afa0e33133171829134d8899a5'
oq4c = ''
opxw = ''
edge01 = 'a332a4f9db645bac467015b917ada407'
edge02 = 'a5f65d2794303cc5829cb60e4b92b9a2'
dev = '5883ac44916b11e995f410ddb1c5aa2p'
dev1 = '5883ac44916b11e995f410ddb1c5aa2q'
dev2 = '5883ac44916b11e995f410ddb1c5aa2r'
dev3 = '5883ac44916b11e995f410ddb1c5aa2s'

NODE_NAME = os.environ['BALENA_DEVICE_UUID']

if NODE_NAME == sagittarius:
    os.environ['LOCATION'] = 'living'

if NODE_NAME == earth:
    set_if_not_define('ACTIVE_ACTOR', 'light,phone,air')
    # set_if_not_define('LOCATION', 'office')
    set_if_not_define('ACTIVE_DRIVER', 'video_park0')
    set_if_not_define('LOCATION', 'park')
elif NODE_NAME == dev:
    set_if_not_define('ACTIVE_DRIVER', 'video_kitchen')
    set_if_not_define('LOCATION', 'kitchen')
elif NODE_NAME == dev1:
    set_if_not_define('ACTIVE_DRIVER', 'video_gym0')
    set_if_not_define('LOCATION', 'gym')
elif NODE_NAME == dev2:
    set_if_not_define('ACTIVE_DRIVER', 'video_gym1')
    set_if_not_define('LOCATION', 'gym')
elif NODE_NAME == dev3:
    set_if_not_define('ACTIVE_ACTOR', 'air')
    set_if_not_define('LOCATION', 'gym')
elif NODE_NAME == isot:
    set_if_not_define('ACTIVE_DRIVER', 'video_park0')
    set_if_not_define('LOCATION', 'park')
elif NODE_NAME == iszb:
    set_if_not_define('ACTIVE_DRIVER', 'video_park1')
    set_if_not_define('LOCATION', 'park')
elif NODE_NAME == ivmh:
    set_if_not_define('ACTIVE_DRIVER', 'video_park2')
    set_if_not_define('LOCATION', 'park')
elif NODE_NAME == isuk:
    set_if_not_define('ACTIVE_ACTOR', 'phone')
    set_if_not_define('LOCATION', 'park')
elif NODE_NAME == or78 or NODE_NAME == opxv:
    set_if_not_define('ACTIVE_ACTOR', 'light')
    set_if_not_define('LOCATION', 'kitchen')

#
# if NODE_NAME == edge01: # not active
#     os.environ['ACTIVE_ACTOR'] = 'air'
#     os.environ['LOCATION'] = 'gym'
# elif NODE_NAME == edge02: # not active
#     os.environ['ACTIVE_DRIVER'] = 'video_kitchen'
#     os.environ['LOCATION'] = 'kitchen'
# elif NODE_NAME == isot:
#     os.environ['ACTIVE_DRIVER'] = 'video_park0'
#     os.environ['LOCATION'] = 'park'
# elif NODE_NAME == iszb:
#     os.environ['ACTIVE_DRIVER'] = 'video_park1'
#     os.environ['ACTIVE_ACTOR'] = 'phone'
#     os.environ['LOCATION'] = 'park'
# elif NODE_NAME == ivmh:
#     os.environ['ACTIVE_DRIVER'] = 'video_gym0'
#     os.environ['LOCATION'] = 'gym'
# elif NODE_NAME == isuk:
#     os.environ['ACTIVE_DRIVER'] = 'video_gym1'
#     os.environ['LOCATION'] = 'gym'
# elif NODE_NAME == or78 or NODE_NAME == opxv:
#     os.environ['ACTIVE_ACTOR'] = 'light'
#     os.environ['LOCATION'] = 'kitchen'
# else:
#     os.environ['LOCATION'] = 'gym'
