redis-server /etc/redis/redis.conf&
echo "127.0.0.1       redis_db" >> /etc/hosts&
wait
