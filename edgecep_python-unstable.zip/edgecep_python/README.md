# edgecep-python

test with 
```
cd postman
python postman.py
```
