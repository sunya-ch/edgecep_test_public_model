redis-server /etc/redis/redis.conf&
echo "127.0.0.1       redis_db" >> /etc/hosts&
python processor/processor.py&
python actor/actor.py&
python driver/driver.py&
python postman/postman.py
