from driver import BaseDriver

import cv2
import numpy as np
import os.path
import urllib
from smb.SMBHandler import SMBHandler

import time

import logging

VIDEO_PATH = "/tmp/video/"
USER = 'c-pang'
PWD = 'tl521641'
HOSTIP = '192.168.147.22'

SMB_PATH = 'smb://{0}:{1}@{2}/c-pang/Research/gen_videos/'.format(USER, PWD, HOSTIP)

sampling_time = float(os.environ['VIDEO_SAMPLING_TIME'])

if not os.path.exists(VIDEO_PATH):
    os.makedirs(VIDEO_PATH)

def run(args):
    FrameDriverFromVideo("frame", sampling_time, args[0]).start()

class FrameDriverFromVideo(BaseDriver):
    def __init__(self, name, sampling_period_in_sec, video_name):
        super(FrameDriverFromVideo, self).__init__(name, sampling_period_in_sec)
        self.file_name = self.download_smb_if_not_exists(video_name)
        self.cap = cv2.VideoCapture(self.file_name)
        self.fps = self.cap.get(cv2.CAP_PROP_FPS)
        logging.info('DRIVER-SAMPLING: name:{0} time:{1}'.format(self.name, self.sampling_period))

    def download_smb_if_not_exists(self, video_name):
        file_name = '{0}{1}.avi'.format(VIDEO_PATH, video_name)
        if not os.path.exists(file_name):
            opener = urllib.request.build_opener(SMBHandler)
            while True:
                try:
                    fh = opener.open('{0}{1}.avi'.format(SMB_PATH, video_name))
                    local_file = open(file_name, "wb")
                    local_file.write(fh.read())
                    break
                except:
                    time.sleep(1)
                    logging.info('DRIVER: try download video again {0}'.format(video_name))
        return file_name

    def read_values(self):
        attribs = {}
        ret, frame = self.cap.read()
        if ret == False:
            self.cap.release()
            cv2.destroyAllWindows()
            return None
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_data = np.array(frame).tolist()

        attribs['data'] = frame_data

        resolution = 1
        for dimval in frame.shape:
            resolution = resolution * dimval
        attribs['resolution'] = resolution
        attribs['sampling_rate'] = 1/self.sampling_period
        self.skip_frame()
        return attribs

    def skip_frame(self):
        max_skip = int(self.fps * self.sampling_period)
        count = 0
#         print('skipping {0}'.format(max_skip))
        while True:
            ret, frame = self.cap.read()
            count = count + 1
            if ret == False or count > max_skip:
                break

    def close(self):
        logging.info('CLOSE')
        # os.remove(self.file_name)
