from driver import BaseDriver
import cv2

import numpy as np

def run(args):
    FrameDriverFromCamera("frame", .5).start()

class FrameDriverFromCamera(BaseDriver):
    def __init__(self, name, sampling_period_in_sec):
        super(FrameDriverFromVideo, self).__init__(name, sampling_period_in_sec)
        self.cap = cv2.VideoCapture(0)

    def read_values(self):
        attribs = {}
        ret, frame = self.cap.read()
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame_data = np.array(frame).tolist()

        attribs['data'] = frame_data


        resolution = 1
        for dimval in frame.shape:
            resolution = resolution * dimval
        attribs['resolution'] = resolution
        attribs['sampling_rate'] = 1/self.sampling_period
        return attribs

    def stop(self):
        self.cap.release()
        cv2.destroyAllWindows()
        super(BaseDriver, self).stop()
